import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BellIcon, UserIcon, SettingsIcon, HelpCircleIcon, LogOutIcon } from 'lucide-react';
export function DeveloperDashboardHeader() {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const toggleProfileMenu = () => {
    setShowProfileMenu(!showProfileMenu);
    if (showNotifications) setShowNotifications(false);
  };
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
    if (showProfileMenu) setShowProfileMenu(false);
  };
  return <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
      <div className="px-6 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Link to="/developer/dashboard" className="flex items-center">
            <span className="text-2xl font-bold text-blue-600">
              AI<span className="text-gray-900">+</span>
            </span>
            <span className="ml-2 text-sm font-semibold bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
              Developer
            </span>
          </Link>
        </div>
        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full relative" onClick={toggleNotifications}>
            <BellIcon className="h-5 w-5" />
            <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
          </button>
          <div className="relative">
            <button className="flex items-center space-x-2 text-gray-700 hover:text-gray-900" onClick={toggleProfileMenu}>
              <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-medium">
                AI
              </div>
              <span className="hidden md:inline-block font-medium">
                AI Lab Tunisia
              </span>
            </button>
            {showProfileMenu && <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
                <Link to="/developer/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                  <UserIcon className="h-4 w-4 mr-2" />
                  Mon profil
                </Link>
                <Link to="/developer/settings" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                  <SettingsIcon className="h-4 w-4 mr-2" />
                  Paramètres
                </Link>
                <Link to="/developer/support" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                  <HelpCircleIcon className="h-4 w-4 mr-2" />
                  Support
                </Link>
                <div className="border-t border-gray-200 my-1"></div>
                <Link to="/logout" className="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center">
                  <LogOutIcon className="h-4 w-4 mr-2" />
                  Déconnexion
                </Link>
              </div>}
          </div>
        </div>
        {showNotifications && <div className="absolute right-6 mt-12 w-80 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
            <div className="px-4 py-2 border-b border-gray-200 flex justify-between items-center">
              <h3 className="font-medium text-gray-900">Notifications</h3>
              <button className="text-xs text-blue-600 hover:text-blue-800">
                Marquer tout comme lu
              </button>
            </div>
            <div className="max-h-96 overflow-y-auto">
              <div className="px-4 py-3 hover:bg-gray-50 border-l-4 border-blue-500">
                <p className="text-sm font-medium text-gray-900">
                  Nouvel abonnement
                </p>
                <p className="text-xs text-gray-500">
                  Un utilisateur s'est abonné à ArabicBERT
                </p>
                <p className="text-xs text-gray-400 mt-1">Il y a 5 minutes</p>
              </div>
              <div className="px-4 py-3 hover:bg-gray-50">
                <p className="text-sm font-medium text-gray-900">
                  Nouvelle évaluation
                </p>
                <p className="text-xs text-gray-500">
                  TunBERT a reçu une évaluation 5 étoiles
                </p>
                <p className="text-xs text-gray-400 mt-1">Il y a 2 heures</p>
              </div>
              <div className="px-4 py-3 hover:bg-gray-50">
                <p className="text-sm font-medium text-gray-900">
                  Paiement reçu
                </p>
                <p className="text-xs text-gray-500">
                  Vous avez reçu un paiement de 450 TND
                </p>
                <p className="text-xs text-gray-400 mt-1">Il y a 1 jour</p>
              </div>
            </div>
            <div className="px-4 py-2 border-t border-gray-200">
              <Link to="/developer/notifications" className="text-xs text-blue-600 hover:text-blue-800">
                Voir toutes les notifications
              </Link>
            </div>
          </div>}
      </div>
    </header>;
}