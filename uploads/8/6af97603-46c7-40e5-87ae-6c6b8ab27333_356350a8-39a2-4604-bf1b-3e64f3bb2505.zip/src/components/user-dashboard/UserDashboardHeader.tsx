import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Bell, User, LogOut, Settings, ChevronDown, Info, AlertTriangle, CheckCircle, AlertCircle, X } from 'lucide-react';
import { Notification } from '../../pages/UserDashboardPage';
interface UserDashboardHeaderProps {
  user: {
    id: number;
    name: string;
    email: string;
    avatar?: string;
  };
  notifications: Notification[];
  onMarkAsRead: (notificationId: number) => void;
}
export function UserDashboardHeader({
  user,
  notifications,
  onMarkAsRead
}: UserDashboardHeaderProps) {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);
  const unreadNotificationsCount = notifications.filter(n => !n.read).length;
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'INFO':
        return <Info className="h-5 w-5 text-blue-500" />;
      case 'WARNING':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'SUCCESS':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'ERROR':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays === 0) {
      const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
      if (diffHours === 0) {
        const diffMinutes = Math.floor(diffTime / (1000 * 60));
        return `Il y a ${diffMinutes} minute${diffMinutes > 1 ? 's' : ''}`;
      }
      return `Il y a ${diffHours} heure${diffHours > 1 ? 's' : ''}`;
    } else if (diffDays === 1) {
      return 'Hier';
    } else if (diffDays < 7) {
      return `Il y a ${diffDays} jour${diffDays > 1 ? 's' : ''}`;
    } else {
      return date.toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'short'
      });
    }
  };
  return <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0">
              <span className="text-2xl font-bold text-blue-600">
                AI
                <span className="text-2xl font-bold text-gray-900">+</span>
              </span>
            </Link>
            <span className="ml-4 text-gray-500">|</span>
            <span className="ml-4 text-gray-700 font-medium">
              Tableau de bord
            </span>
          </div>
          {/* User menu and notifications */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <div className="relative" ref={notificationsRef}>
              <button onClick={() => setShowNotifications(!showNotifications)} className="p-2 rounded-full hover:bg-gray-100 relative">
                <Bell className="h-5 w-5 text-gray-600" />
                {unreadNotificationsCount > 0 && <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />}
              </button>
              {showNotifications && <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-1 z-10 max-h-96 overflow-y-auto">
                  <div className="px-4 py-2 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-medium text-gray-900">Notifications</h3>
                    <span className="text-xs text-gray-500">
                      {unreadNotificationsCount} non lues
                    </span>
                  </div>
                  {notifications.length === 0 ? <div className="px-4 py-3 text-sm text-gray-500 text-center">
                      Aucune notification
                    </div> : <div>
                      {notifications.map(notification => <div key={notification.id} className={`px-4 py-3 hover:bg-gray-50 ${!notification.read ? 'bg-blue-50' : ''}`}>
                          <div className="flex">
                            <div className="flex-shrink-0 mr-3">
                              {getNotificationIcon(notification.type)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <Link to={notification.link || '#'} className="block" onClick={() => onMarkAsRead(notification.id)}>
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {notification.title}
                                </p>
                                <p className="text-sm text-gray-500 truncate">
                                  {notification.message}
                                </p>
                                <p className="text-xs text-gray-400 mt-1">
                                  {formatDate(notification.date)}
                                </p>
                              </Link>
                            </div>
                            {!notification.read && <button className="ml-2 text-gray-400 hover:text-gray-600" onClick={() => onMarkAsRead(notification.id)}>
                                <X className="h-4 w-4" />
                              </button>}
                          </div>
                        </div>)}
                      <div className="px-4 py-2 border-t border-gray-100">
                        <Link to="/user/notifications" className="block text-center text-sm text-blue-600 hover:text-blue-800">
                          Voir toutes les notifications
                        </Link>
                      </div>
                    </div>}
                </div>}
            </div>
            {/* User menu */}
            <div className="relative" ref={userMenuRef}>
              <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center space-x-2 p-2 rounded-full hover:bg-gray-100">
                <div className="flex items-center space-x-2">
                  {user.avatar ? <img src={user.avatar} alt={user.name} className="h-8 w-8 rounded-full" /> : <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-medium">
                      {user.name.charAt(0)}
                    </div>}
                  <span className="hidden md:block text-sm font-medium text-gray-700">
                    {user.name}
                  </span>
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </div>
              </button>
              {showUserMenu && <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-10">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium text-gray-900">
                      {user.name}
                    </p>
                    <p className="text-sm text-gray-500 truncate">
                      {user.email}
                    </p>
                  </div>
                  <Link to="/user/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    Mon profil
                  </Link>
                  <Link to="/user/settings" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                    <Settings className="h-4 w-4 mr-2" />
                    Paramètres
                  </Link>
                  <div className="border-t border-gray-100">
                    <Link to="/logout" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                      <LogOut className="h-4 w-4 mr-2" />
                      Déconnexion
                    </Link>
                  </div>
                </div>}
            </div>
          </div>
        </div>
      </div>
    </header>;
}