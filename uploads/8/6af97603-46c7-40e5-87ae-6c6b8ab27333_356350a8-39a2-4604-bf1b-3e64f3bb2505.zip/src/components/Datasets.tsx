import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Database, FileText, Image, MessageSquare, ArrowRight } from 'lucide-react';
export const Datasets = () => {
  const datasetCategories = [{
    icon: <MessageSquare className="h-8 w-8" />,
    title: 'Texte & NLP',
    count: '120+ datasets',
    description: 'Corpus de textes en arabe et dialecte tunisien',
    color: 'from-blue-500 to-cyan-500'
  }, {
    icon: <Image className="h-8 w-8" />,
    title: 'Images',
    count: '85+ datasets',
    description: "Collections d'images annotées pour la vision par ordinateur",
    color: 'from-purple-500 to-pink-500'
  }, {
    icon: <FileText className="h-8 w-8" />,
    title: 'Documents',
    count: '45+ datasets',
    description: 'Documents administratifs et juridiques tunisiens',
    color: 'from-green-500 to-emerald-500'
  }, {
    icon: <Database className="h-8 w-8" />,
    title: 'Données structurées',
    count: '60+ datasets',
    description: 'Données tabulaires et séries temporelles',
    color: 'from-orange-500 to-red-500'
  }];
  return <section className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.6
      }} className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Datasets de qualité
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Accédez à une large collection de datasets tunisiens et arabes pour
            entraîner vos modèles
          </p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {datasetCategories.map((category, index) => <motion.div key={index} initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          delay: index * 0.1,
          duration: 0.6
        }} whileHover={{
          y: -8
        }} className="group bg-gradient-to-br from-gray-50 to-white rounded-2xl p-8 shadow-sm hover:shadow-2xl transition-all duration-300 border border-gray-100">
              <div className={`inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-br ${category.color} text-white mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {category.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {category.title}
              </h3>
              <p className="text-sm font-medium text-blue-600 mb-3">
                {category.count}
              </p>
              <p className="text-gray-600">{category.description}</p>
            </motion.div>)}
        </div>
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        delay: 0.4,
        duration: 0.6
      }} className="text-center">
          <Link to="/datasets" className="inline-flex items-center px-8 py-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl">
            Explorer les datasets
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </motion.div>
      </div>
    </section>;
};