import React from 'react';
import { GithubIcon, TwitterIcon, LinkedinIcon } from 'lucide-react';
export function Footer() {
  return <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          <div className="col-span-2">
            <div className="flex items-center mb-4">
              <span className="text-2xl font-bold text-blue-500">AI</span>
              <span className="text-2xl font-bold text-white">+</span>
            </div>
            <p className="text-gray-400 mb-4">
              La plateforme tunisienne d'intelligence artificielle.
              <br /> Partagez et découvrez des modèles, des jeux de données et
              des applications pour contribuer à l'essor de l'IA en Tunisie.
            </p>
          </div>
          <div>
            <h3 className="text-white font-medium mb-4">Nos Produits</h3>
            <ul className="space-y-2">
              <li>
                <a href="/models" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Modèles d'IA
                </a>
              </li>
              <li>
                <a href="/datasets" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Datasets
                </a>
              </li>
              <li>
                <a href="/api" className="text-gray-400 hover:text-blue-500 transition-colors">
                  API
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-medium mb-4">À propos de AI+</h3>
            <ul className="space-y-2">
              <li>
                <a href="/about" className="text-gray-400 hover:text-blue-500 transition-colors">
                  À propos
                </a>
              </li>
              <li>
                <a href="/contact" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <a href="/support" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Support & FAQ
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-medium mb-4">Suivez-nous</h3>
            <p className="text-gray-400 mb-4">
              Restez à jour avec les dernières nouveautés de la communauté AI+
              en suivant nos réseaux sociaux.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-500 transition-colors">
                <GithubIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-500 transition-colors">
                <TwitterIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-500 transition-colors">
                <LinkedinIcon className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} AI+. Tous droits réservés.</p>
        </div>
      </div>
    </footer>;
}