import React from 'react';
import { motion } from 'framer-motion';
import { Activity, CheckCircle, AlertTriangle, Server, Database, Cpu } from 'lucide-react';
export function SystemHealthCard() {
  const metrics = [{
    label: 'API Uptime',
    value: '99.9%',
    status: 'healthy',
    icon: Server,
    color: 'text-green-400',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/20'
  }, {
    label: 'Database',
    value: '98.5%',
    status: 'healthy',
    icon: Database,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/20'
  }, {
    label: 'CPU Usage',
    value: '45%',
    status: 'warning',
    icon: Cpu,
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-500/10',
    borderColor: 'border-yellow-500/20'
  }];
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    delay: 0.2,
    duration: 0.5
  }} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-100 mb-1 flex items-center gap-2">
            <Activity className="h-5 w-5 text-green-400" />
            État du Système
          </h2>
          <p className="text-sm text-gray-400">
            Tous les services fonctionnent correctement
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg">
          <CheckCircle className="h-4 w-4 text-green-400" />
          <span className="text-sm font-medium text-green-400">
            Opérationnel
          </span>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((metric, index) => {
        const Icon = metric.icon;
        return <motion.div key={metric.label} initial={{
          opacity: 0,
          scale: 0.9
        }} animate={{
          opacity: 1,
          scale: 1
        }} transition={{
          delay: 0.3 + index * 0.1,
          duration: 0.5
        }} className={`${metric.bgColor} border ${metric.borderColor} rounded-lg p-4 hover:border-opacity-40 transition-all duration-300`}>
              <div className="flex items-center justify-between mb-2">
                <Icon className={`h-5 w-5 ${metric.color}`} />
                {metric.status === 'healthy' ? <CheckCircle className="h-4 w-4 text-green-400" /> : <AlertTriangle className="h-4 w-4 text-yellow-400" />}
              </div>
              <p className="text-sm text-gray-400 mb-1">{metric.label}</p>
              <p className={`text-2xl font-bold ${metric.color}`}>
                {metric.value}
              </p>
            </motion.div>;
      })}
      </div>
    </motion.div>;
}