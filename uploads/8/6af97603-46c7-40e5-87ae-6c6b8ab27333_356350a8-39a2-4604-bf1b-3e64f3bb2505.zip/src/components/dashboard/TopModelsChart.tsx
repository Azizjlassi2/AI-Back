import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp } from 'lucide-react';
export function TopModelsChart() {
  const models = [{
    name: 'ArabicBERT',
    downloads: 23100,
    percentage: 100
  }, {
    name: 'TunBERT',
    downloads: 18500,
    percentage: 80
  }, {
    name: 'MedicalVision',
    downloads: 15200,
    percentage: 66
  }, {
    name: 'VoiceAI',
    downloads: 12800,
    percentage: 55
  }, {
    name: 'TextGen',
    downloads: 9600,
    percentage: 42
  }];
  return <motion.div initial={{
    opacity: 0,
    x: 20
  }} animate={{
    opacity: 1,
    x: 0
  }} transition={{
    delay: 0.6,
    duration: 0.5
  }} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-100 mb-1">
            Top Modèles
          </h2>
          <p className="text-sm text-gray-400">Les plus téléchargés</p>
        </div>
        <div className="h-5 w-5 text-blue-400" />
      </div>
      <div className="space-y-4">
        {models.map((model, index) => <motion.div key={model.name} initial={{
        opacity: 0,
        x: -20
      }} animate={{
        opacity: 1,
        x: 0
      }} transition={{
        delay: 0.8 + index * 0.1,
        duration: 0.5
      }} className="group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-300 group-hover:text-gray-100 transition-colors">
                {model.name}
              </span>
              <span className="text-xs text-gray-400">
                {model.downloads.toLocaleString()}
              </span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <motion.div initial={{
            width: 0
          }} animate={{
            width: `${model.percentage}%`
          }} transition={{
            delay: 1 + index * 0.1,
            duration: 0.8
          }} className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full" />
            </div>
          </motion.div>)}
      </div>
    </motion.div>;
}