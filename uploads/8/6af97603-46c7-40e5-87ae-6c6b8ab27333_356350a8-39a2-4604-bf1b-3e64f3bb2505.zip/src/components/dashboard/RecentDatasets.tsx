import React from 'react';
import { DataTable } from '../admin/shared/DataTable';
export function RecentDatasets() {
  const datasets = [{
    id: 'DS-001',
    name: 'TunisianDialect v3',
    creator: 'ANLP Lab',
    size: '2.3GB',
    date: '2024-01-15'
  }, {
    id: 'DS-002',
    name: 'MedicalImages 2024',
    creator: 'CHU Tunis',
    size: '15GB',
    date: '2024-01-14'
  }, {
    id: 'DS-003',
    name: 'StreetViews Tunis',
    creator: 'Urban AI',
    size: '8.7GB',
    date: '2024-01-13'
  }];
  const columns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Nom',
    accessor: 'name'
  }, {
    header: 'Créateur',
    accessor: 'creator'
  }, {
    header: 'Taille',
    accessor: 'size'
  }, {
    header: 'Date',
    accessor: 'date'
  }];
  return <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">Datasets Récents</h2>
      <DataTable columns={columns} data={datasets} />
    </div>;
}