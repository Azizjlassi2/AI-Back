import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Users, Database, DollarSign, BoxIcon } from 'lucide-react';
export function StatCards() {
  const stats = [{
    title: 'Revenus Mensuels',
    value: '45,231 DT',
    change: '+12.5%',
    trend: 'up',
    icon: DollarSign,
    color: 'from-green-500 to-emerald-600',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/20'
  }, {
    title: 'Utilisateurs Actifs',
    value: '2,847',
    change: '+8.2%',
    trend: 'up',
    icon: Users,
    color: 'from-blue-500 to-cyan-600',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/20'
  }, {
    title: 'Modèles Publiés',
    value: '342',
    change: '+18',
    trend: 'up',
    icon: BoxIcon,
    color: 'from-purple-500 to-pink-600',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/20'
  }, {
    title: 'Datasets Disponibles',
    value: '156',
    change: '+12',
    trend: 'up',
    icon: Database,
    color: 'from-orange-500 to-red-600',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/20'
  }];
  return <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
      {stats.map((stat, index) => {
      const Icon = stat.icon;
      const TrendIcon = stat.trend === 'up' ? TrendingUp : TrendingDown;
      return <motion.div key={stat.title} initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        delay: index * 0.1,
        duration: 0.5
      }} className={`relative bg-gray-900 border ${stat.borderColor} rounded-xl p-6 overflow-hidden group hover:border-opacity-40 transition-all duration-300`}>
            {/* Gradient background */}
            <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
            {/* Icon background */}
            <div className={`absolute -right-4 -top-4 ${stat.bgColor} rounded-full w-24 h-24 opacity-50 group-hover:opacity-100 transition-opacity duration-300`} />
            <div className="relative">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 ${stat.bgColor} rounded-lg border ${stat.borderColor}`}>
                  <Icon className="h-6 w-6 text-gray-100" />
                </div>
                <div className={`flex items-center gap-1 text-sm font-medium ${stat.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                  <TrendIcon className="h-4 w-4" />
                  {stat.change}
                </div>
              </div>
              <h3 className="text-sm font-medium text-gray-400 mb-1">
                {stat.title}
              </h3>
              <p className="text-3xl font-bold text-gray-100">{stat.value}</p>
            </div>
          </motion.div>;
    })}
    </div>;
}