import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp } from 'lucide-react';
export function RevenueChart() {
  const data = [{
    month: 'Jan',
    value: 32000
  }, {
    month: 'Fév',
    value: 38000
  }, {
    month: 'Mar',
    value: 35000
  }, {
    month: 'Avr',
    value: 42000
  }, {
    month: 'Mai',
    value: 39000
  }, {
    month: 'Juin',
    value: 45231
  }];
  const maxValue = Math.max(...data.map(d => d.value));
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    delay: 0.4,
    duration: 0.5
  }} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-100 mb-1">
            Revenus Mensuels
          </h2>
          <p className="text-sm text-gray-400">
            Évolution des revenus sur 6 mois
          </p>
        </div>
        <div className="flex items-center gap-2 text-sm text-green-400">
          <TrendingUp className="h-4 w-4" />
          <span className="font-medium">+12.5%</span>
        </div>
      </div>
      <div className="h-64 flex items-end justify-between gap-3">
        {data.map((item, index) => {
        const height = item.value / maxValue * 100;
        return <div key={item.month} className="flex-1 flex flex-col items-center gap-3">
              <motion.div initial={{
            height: 0
          }} animate={{
            height: `${height}%`
          }} transition={{
            delay: 0.6 + index * 0.1,
            duration: 0.5
          }} className="w-full bg-gradient-to-t from-blue-600 to-cyan-500 rounded-t-lg relative group cursor-pointer hover:from-blue-500 hover:to-cyan-400 transition-all duration-300">
                <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-800 border border-gray-700 px-2 py-1 rounded text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {item.value.toLocaleString()} DT
                </div>
              </motion.div>
              <span className="text-xs text-gray-400 font-medium">
                {item.month}
              </span>
            </div>;
      })}
      </div>
    </motion.div>;
}