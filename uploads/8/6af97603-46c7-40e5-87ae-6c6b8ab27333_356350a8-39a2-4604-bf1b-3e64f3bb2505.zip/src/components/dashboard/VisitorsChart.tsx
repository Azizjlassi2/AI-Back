import React from 'react';
import { motion } from 'framer-motion';
import { Eye } from 'lucide-react';
export function VisitorsChart() {
  const data = [{
    day: 'Lun',
    value: 420
  }, {
    day: 'Mar',
    value: 380
  }, {
    day: 'Mer',
    value: 520
  }, {
    day: 'Jeu',
    value: 490
  }, {
    day: 'Ven',
    value: 610
  }, {
    day: 'Sam',
    value: 450
  }, {
    day: 'Dim',
    value: 380
  }];
  const maxValue = Math.max(...data.map(d => d.value));
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    delay: 0.5,
    duration: 0.5
  }} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-100 mb-1">
            Visiteurs Quotidiens
          </h2>
          <p className="text-sm text-gray-400">Dernière semaine</p>
        </div>
        <div className="flex items-center gap-2">
          <Eye className="h-5 w-5 text-purple-400" />
          <span className="text-sm font-medium text-gray-300">3,250 total</span>
        </div>
      </div>
      <div className="h-64 flex items-end justify-between gap-3">
        {data.map((item, index) => {
        const height = item.value / maxValue * 100;
        return <div key={item.month} className="w-10 flex flex-col items-center gap-2">
              <motion.div initial={{
            height: 0
          }} animate={{
            height: `${height}%`
          }} transition={{
            delay: 0.6 + index * 0.1,
            duration: 0.5
          }} className="w-full bg-gradient-to-t from-blue-600 to-cyan-500 rounded-t-lg relative group cursor-pointer hover:from-blue-500 hover:to-cyan-400">
                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-gray-800 border border-gray-700 px-2 py-1 rounded text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {item.value.toLocaleString()} DT
                </div>
              </motion.div>
              <span className="text-xs text-gray-400">{item.month}</span>
            </div>;
      })}
      </div>
    </motion.div>;
}