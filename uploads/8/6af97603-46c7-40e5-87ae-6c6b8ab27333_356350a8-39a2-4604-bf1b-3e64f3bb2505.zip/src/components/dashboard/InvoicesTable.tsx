import React from 'react';
import { DataTable } from '../admin/shared/DataTable';
import { Download, FileText } from 'lucide-react';
export function InvoicesTable() {
  const invoices = [{
    id: 'INV-001',
    client: 'TechCorp Tunisie',
    montant: '2,500 DT',
    status: 'Payée',
    date: '2024-01-15'
  }, {
    id: 'INV-002',
    client: 'AI Solutions SARL',
    montant: '1,800 DT',
    status: 'En attente',
    date: '2024-01-14'
  }, {
    id: 'INV-003',
    client: 'DataTech Tunisia',
    montant: '3,200 DT',
    status: 'Payée',
    date: '2024-01-13'
  }];
  const columns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Client',
    accessor: 'client'
  }, {
    header: 'Montant',
    accessor: 'montant'
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Payée' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}`}>
          {value}
        </span>
  }, {
    header: 'Date',
    accessor: 'date'
  }, {
    header: 'Actions',
    accessor: 'id',
    cell: () => <div className="flex space-x-2">
          <button className="p-1 hover:text-blue-500">
            <FileText className="h-5 w-5" />
          </button>
          <button className="p-1 hover:text-blue-500">
            <Download className="h-5 w-5" />
          </button>
        </div>
  }];
  return <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">Factures</h2>
      <DataTable columns={columns} data={invoices} />
    </div>;
}