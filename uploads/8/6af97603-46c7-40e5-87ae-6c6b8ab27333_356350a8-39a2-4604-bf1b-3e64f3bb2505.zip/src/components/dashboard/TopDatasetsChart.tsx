import React from 'react';
import { motion } from 'framer-motion';
import { Database } from 'lucide-react';
export function TopDatasetsChart() {
  const datasets = [{
    name: 'Tunisian Dialect',
    downloads: 12500,
    percentage: 100
  }, {
    name: 'Medical Images',
    downloads: 9800,
    percentage: 78
  }, {
    name: 'Arabic Speech',
    downloads: 8200,
    percentage: 66
  }, {
    name: 'Street Views',
    downloads: 6500,
    percentage: 52
  }, {
    name: 'Legal Docs',
    downloads: 4800,
    percentage: 38
  }];
  return <motion.div initial={{
    opacity: 0,
    x: 20
  }} animate={{
    opacity: 1,
    x: 0
  }} transition={{
    delay: 0.7,
    duration: 0.5
  }} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-100 mb-1">
            Top Datasets
          </h2>
          <p className="text-sm text-gray-400">Les plus téléchargés</p>
        </div>
        <Database className="h-5 w-5 text-green-400" />
      </div>
      <div className="space-y-4">
        {datasets.map((dataset, index) => <motion.div key={dataset.name} initial={{
        opacity: 0,
        x: -20
      }} animate={{
        opacity: 1,
        x: 0
      }} transition={{
        delay: 0.9 + index * 0.1,
        duration: 0.5
      }} className="group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-300 group-hover:text-gray-100 transition-colors">
                {dataset.name}
              </span>
              <span className="text-xs text-gray-400">
                {dataset.downloads.toLocaleString()}
              </span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <motion.div initial={{
            width: 0
          }} animate={{
            width: `${dataset.percentage}%`
          }} transition={{
            delay: 1.1 + index * 0.1,
            duration: 0.8
          }} className="h-full bg-gradient-to-r from-green-600 to-emerald-500 rounded-full" />
            </div>
          </motion.div>)}
      </div>
    </motion.div>;
}