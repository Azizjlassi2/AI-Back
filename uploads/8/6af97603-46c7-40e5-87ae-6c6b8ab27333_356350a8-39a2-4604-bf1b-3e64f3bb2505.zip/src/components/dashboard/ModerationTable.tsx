import React from 'react';
import { DataTable } from '../admin/shared/DataTable';
export function ModerationTable() {
  const reports = [{
    id: 'RPT-001',
    type: 'Modèle',
    content: 'ArabicBERT v2.1',
    reporter: 'Ahmed Ben Ali',
    reason: 'Contenu inapproprié',
    status: 'En attente'
  }, {
    id: 'RPT-002',
    type: 'Dataset',
    content: 'MedicalImages',
    reporter: 'Sarah Mejri',
    reason: 'Violation de licence',
    status: 'En cours'
  }, {
    id: 'RPT-003',
    type: 'Commentaire',
    content: 'Discussion #156',
    reporter: 'Karim Gharbi',
    reason: 'Spam',
    status: 'Résolu'
  }];
  const columns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Type',
    accessor: 'type'
  }, {
    header: 'Contenu',
    accessor: 'content'
  }, {
    header: 'Signalé par',
    accessor: 'reporter'
  }, {
    header: 'Raison',
    accessor: 'reason'
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Résolu' ? 'bg-green-200 text-green-800' : value === 'En cours' ? 'bg-blue-200 text-blue-800' : 'bg-yellow-200 text-yellow-800'}`}>
          {value}
        </span>
  }];
  return <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">Modération</h2>
      <DataTable columns={columns} data={reports} />
    </div>;
}