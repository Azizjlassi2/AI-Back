import React, { useState } from 'react';
import { Settings, Power, Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
export function QuickActionsCard() {
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [isToggling, setIsToggling] = useState(false);
  const handleMaintenanceToggle = async () => {
    setIsToggling(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setMaintenanceMode(!maintenanceMode);
    setIsToggling(false);
  };
  return <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-6 flex items-center">
        <Settings className="h-5 w-5 mr-2 text-blue-500" />
        Actions Rapides
      </h2>
      <div className="space-y-3">
        <Link to="/admin/settings" className="w-full px-4 py-3 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-between transition-colors">
          <div className="flex items-center">
            <Settings className="h-5 w-5 text-blue-500 mr-3" />
            <span>Configuration Système</span>
          </div>
        </Link>
        <button onClick={handleMaintenanceToggle} disabled={isToggling} className={`w-full px-4 py-3 rounded-lg flex items-center justify-between transition-colors ${maintenanceMode ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-gray-700 hover:bg-gray-600'} disabled:opacity-50`}>
          <div className="flex items-center">
            <Power className="h-5 w-5 mr-3" />
            <span>Mode Maintenance</span>
          </div>
          {maintenanceMode ? <span className="text-xs bg-yellow-800 px-2 py-1 rounded">
              Actif
            </span> : <span className="text-xs bg-gray-600 px-2 py-1 rounded">
              Inactif
            </span>}
        </button>
        <Link to="/admin/users" className="w-full px-4 py-3 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-between transition-colors">
          <div className="flex items-center">
            <Shield className="h-5 w-5 text-green-500 mr-3" />
            <span>Gérer les Utilisateurs</span>
          </div>
        </Link>
        <Link to="/admin/reports" className="w-full px-4 py-3 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-between transition-colors">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />
            <span>Signalements</span>
          </div>
          <span className="text-xs bg-red-600 px-2 py-1 rounded">8</span>
        </Link>
      </div>
      {maintenanceMode && <div className="mt-4 p-3 bg-yellow-900 border border-yellow-700 rounded-lg">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-yellow-200 mb-1">
                Mode maintenance actif
              </p>
              <p className="text-yellow-300">
                La plateforme est actuellement en maintenance. Les utilisateurs
                ne peuvent pas accéder aux services.
              </p>
            </div>
          </div>
        </div>}
    </div>;
}