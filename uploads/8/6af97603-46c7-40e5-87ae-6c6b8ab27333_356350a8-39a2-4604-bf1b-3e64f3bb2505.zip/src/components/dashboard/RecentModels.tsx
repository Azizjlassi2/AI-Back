import React from 'react';
import { DataTable } from '../admin/shared/DataTable';
export function RecentModels() {
  const models = [{
    id: 'MDL-001',
    name: 'ArabicBERT v2.1',
    creator: 'AI Lab Tunisia',
    status: 'Publié',
    date: '2024-01-15'
  }, {
    id: 'MDL-002',
    name: 'MedicalVision AI',
    creator: 'CHU Tunis',
    status: 'En révision',
    date: '2024-01-14'
  }, {
    id: 'MDL-003',
    name: 'TunBERT',
    creator: 'ANLP Lab',
    status: 'Publié',
    date: '2024-01-13'
  }];
  const columns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Nom',
    accessor: 'name'
  }, {
    header: 'Créateur',
    accessor: 'creator'
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Publié' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}`}>
          {value}
        </span>
  }, {
    header: 'Date',
    accessor: 'date'
  }];
  return <div className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">Modèles Récents</h2>
      <DataTable columns={columns} data={models} />
    </div>;
}