import React from 'react';
import { CheckIcon } from 'lucide-react';
export function Pricing() {
  const plans = [{
    name: 'Accès gratuit',
    price: '0 DT',
    description: 'Accédez librement aux modèles et datasets open-source partagés par la communauté.',
    features: ['Utilisation gratuite avec des limites définies par le créateur', 'Accès aux modèles et datasets communautaires', 'Support via la communauté', 'Déploiement basique']
  }, {
    name: 'Abonnements premium',
    price: 'Prix flexible',
    description: 'Les développeurs proposent des abonnements personnalisés pour leurs modèles avancés.',
    features: ['Paiement unique ou récurrent', 'Accès premium aux mises à jour et fonctionnalités avancées', 'Support technique dédié (optionnel)', 'SLA et conditions définies par le créateur']
  }, {
    name: 'Datasets & APIs personnalisées',
    price: 'Prix flexible',
    description: 'Achetez ou abonnez-vous à des datasets et APIs exclusifs proposés par les créateurs.',
    features: ['Accès limité ou illimité selon le plan', 'Intégration API sécurisée', 'Droits de licence définis par le créateur', 'Support et maintenance optionnels']
  }];
  return <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Tarification flexible contrôlée par les créateurs
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Sur <b>AI+</b>, chaque développeur fixe ses propres plans de
            tarification pour ses modèles et datasets. Découvrez des solutions
            adaptées à vos besoins.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  {plan.name}
                </h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-gray-900">
                    {plan.price}
                  </span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => <li key={featureIndex} className="flex items-start">
                      <CheckIcon className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                      <span className="text-gray-600">{feature}</span>
                    </li>)}
                </ul>
                <button className="w-full bg-blue-500 hover:bg-blue-600 text-white rounded-lg px-6 py-3 text-base font-medium">
                  Découvrir les offres
                </button>
              </div>
            </div>)}
        </div>
      </div>
    </section>;
}