import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, Download, TrendingUp, MessageSquare, Eye, Sparkles, Users } from 'lucide-react';
export function Models() {
  const featuredModels = [{
    id: 1,
    name: 'ArabicBERT',
    description: 'Modèle de traitement du langage naturel arabe',
    category: 'NLP',
    rating: 4.8,
    downloads: '12K',
    users: '2.3K',
    trend: '+15%',
    icon: MessageSquare,
    accent: 'blue'
  }, {
    id: 2,
    name: 'TunBERT',
    description: 'Spécialisé dans le dialecte tunisien',
    category: 'NLP',
    rating: 4.9,
    downloads: '8.5K',
    users: '1.8K',
    trend: '+22%',
    icon: MessageSquare,
    accent: 'purple'
  }, {
    id: 3,
    name: 'VisionAI',
    description: "Reconnaissance d'images et objets",
    category: 'Computer Vision',
    rating: 4.7,
    downloads: '15K',
    users: '3.1K',
    trend: '+18%',
    icon: Eye,
    accent: 'orange'
  }];
  const getAccentColors = (accent: string) => {
    const colors = {
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        text: 'text-blue-600',
        icon: 'text-blue-500',
        hover: 'group-hover:border-blue-300'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        text: 'text-purple-600',
        icon: 'text-purple-500',
        hover: 'group-hover:border-purple-300'
      },
      orange: {
        bg: 'bg-orange-50',
        border: 'border-orange-200',
        text: 'text-orange-600',
        icon: 'text-orange-500',
        hover: 'group-hover:border-orange-300'
      }
    };
    return colors[accent as keyof typeof colors] || colors.blue;
  };
  return <section className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.5
      }} className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-full mb-6">
            <Sparkles className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-700">
              Modèles populaires
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 tracking-tight">
            Découvrez nos modèles d'IA
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Des modèles performants et prêts à l'emploi, utilisés par des
            milliers de développeurs
          </p>
        </motion.div>

        {/* Models Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {featuredModels.map((model, index) => {
          const IconComponent = model.icon;
          const colors = getAccentColors(model.accent);
          return <motion.div key={model.id} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: index * 0.1,
            duration: 0.5
          }} className="group">
                <Link to={`/models/${model.id}`} className="block h-full bg-white border border-gray-200 rounded-2xl p-6 transition-all duration-300 hover:shadow-xl hover:shadow-gray-100 hover:-translate-y-1">
                  {/* Icon and Category */}
                  <div className="flex items-start justify-between mb-6">
                    <div className={`p-3 ${colors.bg} border ${colors.border} rounded-xl transition-colors ${colors.hover}`}>
                      <IconComponent className={`h-6 w-6 ${colors.icon}`} />
                    </div>
                    <span className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full">
                      {model.category}
                    </span>
                  </div>

                  {/* Title and Description */}
                  <div className="mb-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {model.name}
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {model.description}
                    </p>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-yellow-50 rounded-lg">
                        <Star className="h-3.5 w-3.5 text-yellow-500 fill-yellow-500" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Note</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {model.rating}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-green-50 rounded-lg">
                        <Download className="h-3.5 w-3.5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Téléchargements</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {model.downloads}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-blue-50 rounded-lg">
                        <Users className="h-3.5 w-3.5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Utilisateurs</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {model.users}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-purple-50 rounded-lg">
                        <TrendingUp className="h-3.5 w-3.5 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Croissance</p>
                        <p className="text-sm font-semibold text-green-600">
                          {model.trend}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <span className="text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">
                      Voir le modèle
                    </span>
                    <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                  </div>
                </Link>
              </motion.div>;
        })}
        </div>

        {/* CTA Button */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        delay: 0.4,
        duration: 0.5
      }} className="text-center">
          <Link to="/models" className="inline-flex items-center gap-2 px-8 py-4 bg-gray-900 text-white rounded-xl font-semibold hover:bg-gray-800 transition-all duration-200 shadow-lg hover:shadow-xl group">
            Voir tous les modèles
            <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </div>
    </section>;
}