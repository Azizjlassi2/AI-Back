import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Download, CheckCircle, Clock, XCircle } from 'lucide-react';
enum BillingPeriod {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
  PAY_AS_YOU_GO = 'PAY_AS_YOU_GO',
}
enum PaymentMethod {
  CREDIT_CARD = 'CREDIT_CARD',
  PAYPAL = 'PAYPAL',
  FLOUCI = 'FLOUCI',
  KONNECT = 'KONNECT',
  BANK_TRANSFER = 'BANK_TRANSFER',
}
enum PaymentStatus {
  PAID = 'PAID',
  PENDING = 'PENDING',
  FAILED = 'FAILED',
  REFUNDED = 'REFUNDED',
}
interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
}
interface Invoice {
  id: string;
  number: string;
  date: string;
  dueDate: string;
  status: PaymentStatus;
  customerName: string;
  customerEmail: string;
  customerAddress: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  companyName: string;
  companyAddress: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  companyVatNumber?: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  currency: string;
  paymentMethod: PaymentMethod;
  notes?: string;
  modelName: string;
  planName: string;
  billingPeriod: BillingPeriod;
  subscriptionId: string;
}
export function InvoiceDetailPage() {
  const {
    invoiceId
  } = useParams<{
    invoiceId: string;
  }>();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    const fetchInvoice = async () => {
      setIsLoading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 800));
        const mockInvoice: Invoice = {
          id: invoiceId || 'INV-2024-0001',
          number: 'INV-2024-0001',
          date: '2024-01-15',
          dueDate: '2024-01-15',
          status: PaymentStatus.PAID,
          customerName: 'Mohamed Ben Salem',
          customerEmail: 'mohamed.bensalem@example.com',
          customerAddress: {
            street: '123 Rue de la République',
            city: 'Tunis',
            postalCode: '1002',
            country: 'Tunisie'
          },
          companyName: 'AI+ Technologies',
          companyAddress: {
            street: '45 Avenue Habib Bourguiba',
            city: 'Tunis',
            postalCode: '1000',
            country: 'Tunisie'
          },
          companyVatNumber: 'TN1234567890',
          items: [{
            description: 'Abonnement au modèle ArabicBERT - Plan Standard (Mensuel)',
            quantity: 1,
            unitPrice: 49.99,
            amount: 49.99
          }],
          subtotal: 49.99,
          taxRate: 19,
          taxAmount: 9.5,
          total: 59.49,
          currency: 'TND',
          paymentMethod: PaymentMethod.CREDIT_CARD,
          notes: "Merci pour votre confiance. Votre abonnement est valable jusqu'au 15/02/2024.",
          modelName: 'ArabicBERT',
          planName: 'Plan Standard',
          billingPeriod: BillingPeriod.MONTHLY,
          subscriptionId: 'SUB-2024-0001'
        };
        setInvoice(mockInvoice);
      } catch (error) {
        console.error('Error fetching invoice:', error);
        setError('Une erreur est survenue lors du chargement de la facture.');
      } finally {
        setIsLoading(false);
      }
    };
    fetchInvoice();
  }, [invoiceId]);
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  const formatCurrency = (amount: number, currency: string): string => {
    return `${amount.toFixed(2)} ${currency}`;
  };
  const getPaymentStatusBadge = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID:
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium bg-green-50 text-green-700 border border-green-200">
            <CheckCircle className="h-4 w-4" />
            Payée
          </span>;
      case PaymentStatus.PENDING:
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium bg-yellow-50 text-yellow-700 border border-yellow-200">
            <Clock className="h-4 w-4" />
            En attente
          </span>;
      case PaymentStatus.FAILED:
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium bg-red-50 text-red-700 border border-red-200">
            <XCircle className="h-4 w-4" />
            Échouée
          </span>;
      default:
        return null;
    }
  };
  const handleDownloadPDF = () => {
    alert('Téléchargement de la facture en PDF...');
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
      </div>;
  }
  if (error || !invoice) {
    return <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <h1 className="text-xl font-semibold text-gray-900 mb-2">
          Facture non disponible
        </h1>
        <p className="text-gray-600 mb-6">
          {error || "La facture demandée n'est pas disponible."}
        </p>
        <Link to="/user/subscriptions" className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
          Retour aux abonnements
        </Link>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-3xl">
        {/* Minimal Invoice Card */}
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* Header */}
          <div className="px-12 pt-12 pb-8 flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-blue-600 mb-6">
                {invoice.companyName}
              </h1>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">INVOICE</h2>
              <p className="text-sm text-gray-500">{invoice.number}</p>
              <p className="text-sm text-gray-500">
                {formatDate(invoice.date)}
              </p>
            </div>
            <button onClick={handleDownloadPDF} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="h-4 w-4" />
              Download PDF
            </button>
          </div>

          {/* Customer & Billing Info */}
          <div className="px-12 pb-8 grid grid-cols-2 gap-8">
            <div className="bg-gray-50 rounded-lg p-6">
              <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">
                Billed to
              </p>
              <p className="font-medium text-gray-900 mb-1">
                {invoice.customerName}
              </p>
              <p className="text-sm text-gray-600">{invoice.customerEmail}</p>
              <p className="text-sm text-gray-600 mt-2">
                {invoice.customerAddress.street}
              </p>
              <p className="text-sm text-gray-600">
                {invoice.customerAddress.postalCode}{' '}
                {invoice.customerAddress.city}
              </p>
              <p className="text-sm text-gray-600">
                {invoice.customerAddress.country}
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">
                From
              </p>
              <p className="font-medium text-gray-900 mb-1">
                {invoice.companyName}
              </p>
              <p className="text-sm text-gray-600">
                {invoice.companyAddress.street}
              </p>
              <p className="text-sm text-gray-600">
                {invoice.companyAddress.postalCode}{' '}
                {invoice.companyAddress.city}
              </p>
              <p className="text-sm text-gray-600">
                {invoice.companyAddress.country}
              </p>
              {invoice.companyVatNumber && <p className="text-sm text-gray-600 mt-2">
                  TVA: {invoice.companyVatNumber}
                </p>}
            </div>
          </div>

          {/* Line Items Table */}
          <div className="px-12 pb-8">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wide pb-3">
                    Description
                  </th>
                  <th className="text-center text-xs font-medium text-gray-500 uppercase tracking-wide pb-3 w-20">
                    Qty
                  </th>
                  <th className="text-right text-xs font-medium text-gray-500 uppercase tracking-wide pb-3 w-32">
                    Unit Price
                  </th>
                  <th className="text-right text-xs font-medium text-gray-500 uppercase tracking-wide pb-3 w-32">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody>
                {invoice.items.map((item, index) => <tr key={index} className="border-b border-gray-100">
                    <td className="py-4 text-sm text-gray-900">
                      {item.description}
                    </td>
                    <td className="py-4 text-sm text-gray-600 text-center">
                      {item.quantity}
                    </td>
                    <td className="py-4 text-sm text-gray-600 text-right">
                      {formatCurrency(item.unitPrice, invoice.currency)}
                    </td>
                    <td className="py-4 text-sm text-gray-900 text-right font-medium">
                      {formatCurrency(item.amount, invoice.currency)}
                    </td>
                  </tr>)}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="px-12 pb-8">
            <div className="flex justify-end">
              <div className="w-80 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="text-gray-900">
                    {formatCurrency(invoice.subtotal, invoice.currency)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">
                    Tax ({invoice.taxRate}%)
                  </span>
                  <span className="text-gray-900">
                    {formatCurrency(invoice.taxAmount, invoice.currency)}
                  </span>
                </div>
                <div className="pt-2 border-t border-gray-200 flex justify-between">
                  <span className="text-base font-semibold text-gray-900">
                    Total
                  </span>
                  <span className="text-xl font-bold text-gray-900">
                    {formatCurrency(invoice.total, invoice.currency)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Status */}
          <div className="px-12 pb-8">
            {getPaymentStatusBadge(invoice.status)}
          </div>

          {/* Footer */}
          <div className="px-12 py-8 border-t border-gray-200 bg-gray-50">
            <p className="text-sm text-gray-600 text-center">
              Thank you for your business
            </p>
          </div>
        </div>
      </div>
    </div>;
}