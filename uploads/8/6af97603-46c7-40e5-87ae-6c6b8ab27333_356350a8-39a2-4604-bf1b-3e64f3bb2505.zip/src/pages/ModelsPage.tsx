import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, X, Download, Star, Clock, Sparkles, Bot } from 'lucide-react';
import { Link } from 'react-router-dom';
export function ModelsPage() {
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState('popular');
  const models = [{
    id: 1,
    name: 'MedTun-CXR',
    creator: 'CHU Tunis',
    description: "Modèle de détection d'anomalies pulmonaires sur radiographies",
    downloads: '9.3K',
    likes: '421',
    tasks: ['Computer Vision', 'Diagnostic Médical'],
    language: 'N/A',
    lastUpdate: '1 jour',
    rating: 4.8,
    color: 'blue'
  }, {
    id: 2,
    name: 'AgriGrowth Predictor',
    creator: 'INRAT',
    description: "Prédiction du rendement agricole par analyse d'images drones",
    downloads: '3.8K',
    likes: '89',
    tasks: ['Time Series', 'Image Analysis'],
    language: 'French',
    lastUpdate: '1 semaine',
    rating: 4.5,
    color: 'green'
  }, {
    id: 3,
    name: 'Tunisian Speech2Text',
    creator: 'ANLP Lab',
    description: 'Reconnaissance vocale pour dialecte tunisien',
    downloads: '12.1K',
    likes: '567',
    tasks: ['Speech Recognition', 'NLP'],
    language: 'Tunisian Arabic',
    lastUpdate: '3 jours',
    rating: 4.9,
    color: 'purple'
  }, {
    id: 4,
    name: 'OliveOil Quality AI',
    creator: 'CERTE',
    description: "Classification de la qualité de l'huile d'olive par spectrométrie",
    downloads: '2.4K',
    likes: '134',
    tasks: ['Classification', 'Chemometrics'],
    language: 'French',
    lastUpdate: '5 jours',
    rating: 4.6,
    color: 'orange'
  }, {
    id: 5,
    name: 'Tunis Traffic Flow',
    creator: 'Municipalité de Tunis',
    description: 'Optimisation du trafic urbain par analyse vidéo temps réel',
    downloads: '6.7K',
    likes: '278',
    tasks: ['Object Detection', 'Time Series'],
    language: 'N/A',
    lastUpdate: '2 jours',
    rating: 4.7,
    color: 'red'
  }, {
    id: 6,
    name: 'Darija Sentiment',
    creator: 'INS',
    description: 'Analyse de sentiment pour textes en dialecte tunisien',
    downloads: '14.9K',
    likes: '689',
    tasks: ['NLP', 'Sentiment Analysis'],
    language: 'Tunisian Arabic',
    lastUpdate: '4 jours',
    rating: 4.9,
    color: 'indigo'
  }];
  const tasks = ['Text Classification', 'Named Entity Recognition', 'Question Answering', 'Translation', 'Computer Vision', 'Object Detection', 'Speech Recognition', 'Time Series'];
  const languages = ['Modern Standard Arabic', 'Tunisian Arabic (Darija)', 'French', 'English'];
  const toggleTask = (task: string) => {
    setSelectedTasks(prev => prev.includes(task) ? prev.filter(t => t !== task) : [...prev, task]);
  };
  const toggleLanguage = (language: string) => {
    setSelectedLanguages(prev => prev.includes(language) ? prev.filter(l => l !== language) : [...prev, language]);
  };
  const clearFilters = () => {
    setSelectedTasks([]);
    setSelectedLanguages([]);
  };
  const filteredModels = models.filter(model => {
    const matchesSearch = model.name.toLowerCase().includes(searchQuery.toLowerCase()) || model.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTasks = selectedTasks.length === 0 || model.tasks.some(task => selectedTasks.includes(task));
    const matchesLanguages = selectedLanguages.length === 0 || selectedLanguages.includes(model.language);
    return matchesSearch && matchesTasks && matchesLanguages;
  });
  const getColorClasses = (color: string) => {
    const colors: Record<string, {
      border: string;
      bg: string;
      text: string;
    }> = {
      blue: {
        border: 'border-blue-200',
        bg: 'bg-blue-50',
        text: 'text-blue-700'
      },
      green: {
        border: 'border-green-200',
        bg: 'bg-green-50',
        text: 'text-green-700'
      },
      purple: {
        border: 'border-purple-200',
        bg: 'bg-purple-50',
        text: 'text-purple-700'
      },
      orange: {
        border: 'border-orange-200',
        bg: 'bg-orange-50',
        text: 'text-orange-700'
      },
      red: {
        border: 'border-red-200',
        bg: 'bg-red-50',
        text: 'text-red-700'
      },
      indigo: {
        border: 'border-indigo-200',
        bg: 'bg-indigo-50',
        text: 'text-indigo-700'
      }
    };
    return colors[color] || colors.blue;
  };
  return <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} className="mb-12">
          <div className="flex items-center mb-4">
            <Sparkles className="h-8 w-8 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">Modèles d'IA</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl">
            Découvrez des modèles d'intelligence artificielle de pointe pour vos
            projets
          </p>
        </motion.div>
        {/* Search and Filters */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        delay: 0.1
      }} className="mb-8">
          <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input type="text" placeholder="Rechercher des modèles..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all" />
              </div>
              {/* Filter Toggle */}
              <button onClick={() => setShowFilters(!showFilters)} className="inline-flex items-center px-6 py-3 bg-white text-gray-700 rounded-lg hover:bg-gray-100 transition-colors border border-gray-300">
                <Filter className="h-5 w-5 mr-2" />
                Filtres
                {(selectedTasks.length > 0 || selectedLanguages.length > 0) && <span className="ml-2 px-2 py-0.5 bg-blue-600 text-white rounded-full text-xs font-medium">
                    {selectedTasks.length + selectedLanguages.length}
                  </span>}
              </button>
              {/* Sort */}
              <select value={sortBy} onChange={e => setSortBy(e.target.value)} className="px-6 py-3 bg-white text-gray-700 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="popular">Plus populaires</option>
                <option value="recent">Plus récents</option>
                <option value="downloads">Plus téléchargés</option>
                <option value="rating">Mieux notés</option>
              </select>
            </div>
            {/* Active Filters */}
            <AnimatePresence>
              {(selectedTasks.length > 0 || selectedLanguages.length > 0) && <motion.div initial={{
              opacity: 0,
              height: 0
            }} animate={{
              opacity: 1,
              height: 'auto'
            }} exit={{
              opacity: 0,
              height: 0
            }} className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-gray-200">
                  {selectedTasks.map(task => <motion.span key={task} initial={{
                scale: 0.8,
                opacity: 0
              }} animate={{
                scale: 1,
                opacity: 1
              }} exit={{
                scale: 0.8,
                opacity: 0
              }} className="inline-flex items-center px-3 py-1.5 bg-blue-100 text-blue-700 rounded-md text-sm font-medium border border-blue-200">
                      {task}
                      <button onClick={() => toggleTask(task)} className="ml-2 hover:text-blue-900">
                        <X className="h-3 w-3" />
                      </button>
                    </motion.span>)}
                  {selectedLanguages.map(language => <motion.span key={language} initial={{
                scale: 0.8,
                opacity: 0
              }} animate={{
                scale: 1,
                opacity: 1
              }} exit={{
                scale: 0.8,
                opacity: 0
              }} className="inline-flex items-center px-3 py-1.5 bg-green-100 text-green-700 rounded-md text-sm font-medium border border-green-200">
                      {language}
                      <button onClick={() => toggleLanguage(language)} className="ml-2 hover:text-green-900">
                        <X className="h-3 w-3" />
                      </button>
                    </motion.span>)}
                  <button onClick={clearFilters} className="inline-flex items-center px-3 py-1.5 text-gray-600 hover:text-gray-900 text-sm font-medium">
                    Tout effacer
                  </button>
                </motion.div>}
            </AnimatePresence>
          </div>
          {/* Filter Panel */}
          <AnimatePresence>
            {showFilters && <motion.div initial={{
            opacity: 0,
            height: 0
          }} animate={{
            opacity: 1,
            height: 'auto'
          }} exit={{
            opacity: 0,
            height: 0
          }} className="mt-4 bg-gray-50 rounded-xl p-6 border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Tasks */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900 mb-3">
                      Tâches
                    </h3>
                    <div className="space-y-2">
                      {tasks.map(task => <label key={task} className="flex items-center group cursor-pointer">
                          <input type="checkbox" checked={selectedTasks.includes(task)} onChange={() => toggleTask(task)} className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                          <span className="ml-3 text-sm text-gray-700 group-hover:text-gray-900">
                            {task}
                          </span>
                        </label>)}
                    </div>
                  </div>
                  {/* Languages */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900 mb-3">
                      Langues
                    </h3>
                    <div className="space-y-2">
                      {languages.map(language => <label key={language} className="flex items-center group cursor-pointer">
                          <input type="checkbox" checked={selectedLanguages.includes(language)} onChange={() => toggleLanguage(language)} className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                          <span className="ml-3 text-sm text-gray-700 group-hover:text-gray-900">
                            {language}
                          </span>
                        </label>)}
                    </div>
                  </div>
                </div>
              </motion.div>}
          </AnimatePresence>
        </motion.div>
        {/* Results Count */}
        <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} transition={{
        delay: 0.2
      }} className="mb-6 text-gray-600">
          {filteredModels.length} modèle{filteredModels.length > 1 ? 's' : ''}{' '}
          trouvé{filteredModels.length > 1 ? 's' : ''}
        </motion.div>
        {/* Models Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredModels.map((model, index) => {
          const colorClasses = getColorClasses(model.color);
          return <motion.div key={model.id} initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: index * 0.05
          }}>
                <Link to={`/models/${model.id}`}>
                  <motion.div whileHover={{
                y: -4
              }} className="group bg-white rounded-xl border-2 border-gray-200 hover:border-gray-300 transition-all duration-300 overflow-hidden h-full">
                    {/* Header with color accent */}
                    <div className={`h-2 ${colorClasses.bg}`}></div>
                    <div className="p-6">
                      {/* Title and Creator */}
                      <div className="mb-3">
                        <div className="flex items-center mb-1">
                          <Bot className="h-5 w-5 text-gray-400 mr-2 flex-shrink-0" />
                          <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {model.name}
                          </h3>
                        </div>
                        <p className="text-sm text-gray-500 ml-7">
                          {model.creator}
                        </p>
                      </div>
                      {/* Description */}
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {model.description}
                      </p>
                      {/* Tasks */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {model.tasks.slice(0, 2).map(task => <span key={task} className="inline-flex items-center px-2.5 py-1 bg-gray-100 text-gray-700 rounded-md text-xs font-medium border border-gray-200">
                            {task}
                          </span>)}
                      </div>
                      {/* Stats */}
                      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Download className="h-4 w-4 mr-1" />
                            {model.downloads}
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 mr-1 text-yellow-500 fill-current" />
                            {model.rating}
                          </div>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="h-4 w-4 mr-1" />
                          {model.lastUpdate}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </Link>
              </motion.div>;
        })}
        </div>
        {/* Empty State */}
        {filteredModels.length === 0 && <motion.div initial={{
        opacity: 0,
        scale: 0.95
      }} animate={{
        opacity: 1,
        scale: 1
      }} className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4 border-2 border-gray-200">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Aucun modèle trouvé
            </h3>
            <p className="text-gray-600 mb-6">
              Essayez de modifier vos filtres ou votre recherche
            </p>
            <button onClick={clearFilters} className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors border border-blue-700">
              Réinitialiser les filtres
            </button>
          </motion.div>}
      </div>
    </div>;
}