import React, { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Database, Download, FileText, Globe, Calendar, BarChart, Tag, Star, Share2, User, GitBranch, MessageSquare, Cpu, HardDrive, Code, Server, Lock, Send, CreditCard, CheckCircle, Zap } from 'lucide-react';
interface TaskDto {
  id: number;
  name: string;
}
interface EndpointDto {
  method: string;
  path: string;
  description: string;
  requestBody: string;
  successResponse: string;
  errorResponse: string;
}
// Define subscription plan types
enum BillingPeriod {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
  PAY_AS_YOU_GO = 'PAY_AS_YOU_GO',
}
// Interface for subscription plans
interface SubscriptionPlan {
  id: number;
  name: string;
  price: number;
  currency: string;
  description: string;
  billingPeriod: BillingPeriod;
  apiCallsLimit: number;
  features: string[];
}
enum Visibility {
  PUBLIC = 'PUBLIC',
  PRIVATE = 'PRIVATE',
}
interface Comment {
  id: number;
  username: string;
  avatar: string;
  content: string;
  date: string;
}
export function ModelDetailPage() {
  const navigate = useNavigate();
  const [newComment, setNewComment] = useState('');
  const [comments, setComments] = useState<Comment[]>([{
    id: 1,
    username: 'Utilisateur1',
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=U1',
    content: "✨ Excellent modèle pour l'analyse de sentiments en arabe !",
    date: '2024-01-20'
  }, {
    id: 2,
    username: 'Utilisateur2',
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=U2',
    content: '👍 Fonctionne bien, mais pourrait être amélioré pour les dialectes !',
    date: '2024-01-18'
  }]);
  // State for selected subscription plan
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const model = {
    name: 'ArabicBERT',
    creator: {
      name: 'AI Lab Tunisia',
      avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=AI',
      description: 'Laboratory for Arabic Natural Language Processing Research',
      location: 'Tunis, Tunisia',
      joinedDate: '2022',
      models: 12,
      followers: 234
    },
    description: 'Un modèle BERT pré-entraîné sur un large corpus de textes arabes, optimisé pour les tâches de traitement du langage naturel en arabe standard moderne et dialectal tunisien.',
    metadata: {
      framework: 'PyTorch',
      size: '1.2GB',
      parameters: '110M',
      lastUpdate: '2023-12-01',
      version: '2.1.0',
      license: 'MIT',
      architecture: 'BERT-base',
      inputType: 'Text',
      outputType: 'Embeddings, Classifications',
      batchSize: '32',
      trainingSamples: '850M tokens',
      trainingDataset: 'Tunisian Dialect Corpus + Arabic Wikipedia'
    },
    stats: {
      downloads: '15.2K',
      stars: '234',
      forks: '45',
      discussions: '23'
    },
    tasks: [{
      id: 1,
      name: 'Text Classification'
    }, {
      id: 2,
      name: 'Named Entity Recognition'
    }, {
      id: 3,
      name: 'Sentiment Analysis'
    }, {
      id: 4,
      name: 'Question Answering'
    }],
    performance: {
      accuracy: '94.2%',
      f1Score: '0.923',
      precision: '0.918',
      recall: '0.928'
    },
    visibility: Visibility.PUBLIC,
    image: 'ailabtunisia/arabicbert:v2.1',
    requirements: {
      python: '>=3.8',
      cuda: '>=11.0',
      ram: '>=8GB',
      dependencies: ['torch>=1.9.0', 'transformers>=4.12.0', 'arabic-nltk>=0.2.0']
    },
    endpoints: [{
      method: 'POST',
      path: '/api/v1/predict',
      description: 'Endpoint principal pour les prédictions textuelles',
      requestBody: '{\n  "text": "مرحبا بكم في تونس",\n  "options": {\n    "return_probabilities": true\n  }\n}',
      successResponse: '{\n  "prediction": "positive",\n  "probabilities": {\n    "positive": 0.92,\n    "neutral": 0.06,\n    "negative": 0.02\n  },\n  "processing_time": "120ms"\n}',
      errorResponse: '{\n  "error": "Invalid input format",\n  "code": "INPUT_ERROR",\n  "status": 400\n}'
    }, {
      method: 'GET',
      path: '/api/v1/info',
      description: 'Récupère les informations sur le modèle',
      requestBody: '{}',
      successResponse: '{\n  "model": "ArabicBERT",\n  "version": "2.1.0",\n  "language": "Arabic",\n  "capabilities": ["classification", "ner", "sentiment"]\n}',
      errorResponse: '{\n  "error": "Service unavailable",\n  "code": "SERVICE_ERROR",\n  "status": 503\n}'
    }],
    subscriptionPlans: [{
      id: 1,
      name: 'Plan Basique',
      price: 100,
      currency: 'TND',
      description: 'Pour les projets de recherche et les tests',
      billingPeriod: BillingPeriod.MONTHLY,
      apiCallsLimit: 1000,
      features: ["Accès à l'API avec limites", '1000 appels API par mois', 'Support']
    }, {
      id: 2,
      name: 'Plan Standard',
      price: 49.99,
      currency: 'TND',
      description: 'Pour les startups et projets en croissance',
      billingPeriod: BillingPeriod.MONTHLY,
      apiCallsLimit: 50000,
      features: ["Accès à l'API avec limites étendues", '50 000 appels API par mois', 'Support par email', "Tableaux de bord d'analyse"]
    }, {
      id: 3,
      name: 'Plan Pro',
      price: 499.99,
      currency: 'TND',
      description: 'Pour les entreprises et projets à grande échelle',
      billingPeriod: BillingPeriod.ANNUAL,
      apiCallsLimit: 1000000,
      features: ["Accès illimité à l'API", 'Support prioritaire', 'SLA garanti', 'Environnement dédié', 'Formation personnalisée']
    }]
  };
  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const newCommentObj: Comment = {
      id: comments.length + 1,
      username: 'Vous',
      avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=You',
      content: newComment,
      date: new Date().toISOString().split('T')[0]
    };
    setComments([...comments, newCommentObj]);
    setNewComment('');
  };
  const formatJson = (json: string): string => {
    try {
      return JSON.stringify(JSON.parse(json), null, 2);
    } catch (e) {
      return json;
    }
  };
  // Function to handle subscription plan selection
  const handleSelectPlan = (planId: number) => {
    setSelectedPlan(planId);
  };
  // Function to handle subscription checkout
  const handleSubscribe = () => {
    if (selectedPlan) {
      const selectedPlanData = model.subscriptionPlans.find(plan => plan.id === selectedPlan);
      if (selectedPlanData) {
        // Store subscription in localStorage for persistence
        const subscriptions = JSON.parse(localStorage.getItem('userSubscriptions') || '[]');
        const newSubscription = {
          id: Date.now(),
          modelId: 1,
          modelName: model.name,
          planId: selectedPlanData.id,
          planName: selectedPlanData.name,
          startDate: new Date().toISOString(),
          price: selectedPlanData.price,
          currency: selectedPlanData.currency,
          billingPeriod: selectedPlanData.billingPeriod,
          nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'ACTIVE',
          usageData: {
            apiCallsUsed: 0,
            apiCallsLimit: selectedPlanData.apiCallsLimit,
            lastUsed: new Date().toISOString()
          }
        };
        subscriptions.push(newSubscription);
        localStorage.setItem('userSubscriptions', JSON.stringify(subscriptions));
        // Navigate to checkout page with selected plan data
        navigate(`/checkout/${model.name}`, {
          state: {
            selectedPlan: selectedPlanData
          }
        });
      }
    }
  };
  // Function to get appropriate icon for plan feature
  const getPlanIcon = (billingPeriod: BillingPeriod) => {
    switch (billingPeriod) {
      case BillingPeriod.MONTHLY:
        return <Calendar className="h-5 w-5 text-blue-600" />;
      case BillingPeriod.ANNUAL:
        return <Calendar className="h-5 w-5 text-green-600" />;
      case BillingPeriod.PAY_AS_YOU_GO:
        return <Zap className="h-5 w-5 text-purple-600" />;
      default:
        return <CreditCard className="h-5 w-5 text-blue-600" />;
    }
  };
  return <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <div className="h-12 w-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <div className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <div className="flex items-center">
                  <h1 className="text-2xl font-bold text-gray-900 mr-3">
                    {model.name}
                  </h1>
                  {model.visibility === Visibility.PUBLIC ? <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <Globe className="h-3 w-3 mr-1" />
                      Public
                    </span> : <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      <Lock className="h-3 w-3 mr-1" />
                      Privé
                    </span>}
                </div>
                <p className="text-gray-600">par {model.creator.name}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center text-gray-600 hover:text-blue-600">
                <Star className="h-5 w-5 mr-1" />
                {model.stats.stars}
              </button>
              <button className="flex items-center text-gray-600 hover:text-blue-600">
                <GitBranch className="h-5 w-5 mr-1" />
                {model.stats.forks}
              </button>
              <button className="flex items-center text-gray-600 hover:text-blue-600">
                <Share2 className="h-5 w-5" />
              </button>
            </div>
          </div>
          <p className="text-gray-600 mb-6">{model.description}</p>
          <div className="flex flex-wrap gap-2 mb-6">
            {model.tasks.map(task => <span key={task.id} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                <Tag className="h-3 w-3 mr-2" />
                {task.name}
              </span>)}
          </div>
          <div className="flex flex-wrap gap-4">
            <button className="bg-white border border-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-50">
              Tester le modèle
            </button>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center mb-4">
                <img src={model.creator.avatar} alt={model.creator.name} className="h-12 w-12 rounded-full" />
                <div className="ml-3">
                  <Link to={`/creators/${model.creator.name}`} className="font-semibold text-gray-900 hover:text-blue-600 transition-colors">
                    {model.creator.name}
                  </Link>
                  <p className="text-sm text-gray-500">
                    {model.creator.location}
                  </p>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                {model.creator.description}
              </p>
              <div className="flex justify-between text-sm text-gray-500 mb-4">
                <span>{model.creator.models} modèles</span>
                <span>{model.creator.followers} abonnés</span>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">Métadonnées</h2>
              <div className="space-y-3">
                <div className="flex items-center">
                  <Cpu className="h-5 w-5 text-gray-400 mr-3" />
                  <span className="text-gray-600">
                    <strong>Framework:</strong> {model.metadata.framework}
                  </span>
                </div>

                <div className="flex items-center">
                  <Code className="h-5 w-5 text-gray-400 mr-3" />
                  <span className="text-gray-600">
                    <strong>Architecture:</strong> {model.metadata.architecture}
                  </span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                  <span className="text-gray-600">
                    <strong>Mise à jour:</strong> {model.metadata.lastUpdate}
                  </span>
                </div>
                <div className="flex items-center">
                  <HardDrive className="h-5 w-5 text-gray-400 mr-3" />
                  <span className="text-gray-600">
                    <strong>Dataset:</strong> {model.metadata.trainingDataset}
                  </span>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">Statistiques</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-gray-900">
                    {model.stats.downloads}
                  </div>
                  <div className="text-sm text-gray-500">Téléchargements</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-gray-900">
                    {model.stats.discussions}
                  </div>
                  <div className="text-sm text-gray-500">Discussions</div>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">Performance</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-500 mb-1">Accuracy</div>
                  <div className="text-xl font-bold text-gray-900">
                    {model.performance.accuracy}
                  </div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-500 mb-1">Precision</div>
                  <div className="text-xl font-bold text-gray-900">
                    {model.performance.precision}
                  </div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-500 mb-1">Recall</div>
                  <div className="text-xl font-bold text-gray-900">
                    {model.performance.recall}
                  </div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-500 mb-1">F1 Score</div>
                  <div className="text-xl font-bold text-gray-900">
                    {model.performance.f1Score}
                  </div>
                </div>
              </div>
            </div>
            {/* Subscription Plans Section */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <div className="flex items-center mb-6">
                <CreditCard className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-lg font-semibold">Plans d'abonnement</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {model.subscriptionPlans.map(plan => <div key={plan.id} className={`border-2 rounded-lg overflow-hidden ${selectedPlan === plan.id ? 'border-blue-500 shadow-md' : 'border-gray-200'}`}>
                    <div className="p-6">
                      <div className="flex items-center mb-3">
                        {getPlanIcon(plan.billingPeriod)}
                        <h3 className="text-xl font-semibold ml-2">
                          {plan.name}
                        </h3>
                      </div>
                      <div className="mb-4">
                        <div className="flex items-baseline">
                          <span className="text-3xl font-bold">
                            {plan.price} {plan.currency}
                          </span>
                          <span className="text-gray-500 ml-1">
                            /
                            {plan.billingPeriod === BillingPeriod.MONTHLY ? ' mois' : ' an'}
                          </span>
                        </div>
                        <div className="text-sm text-gray-600 mt-1">
                          {plan.apiCallsLimit.toLocaleString()} appels API
                          inclus
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4">{plan.description}</p>
                      <ul className="mb-6 space-y-2">
                        {plan.features.map((feature, index) => <li key={index} className="flex items-start text-gray-600">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>)}
                      </ul>
                      <button onClick={() => handleSelectPlan(plan.id!)} className={`w-full py-2 px-4 rounded-lg transition-colors ${selectedPlan === plan.id ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                        {selectedPlan === plan.id ? 'Sélectionné' : 'Sélectionner ce plan'}
                      </button>
                    </div>
                  </div>)}
              </div>
              {selectedPlan && <div className="mt-6 flex justify-end">
                  <button onClick={handleSubscribe} className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center">
                    S'abonner au plan sélectionné
                  </button>
                </div>}
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <div className="flex items-center mb-4">
                <Server className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-lg font-semibold">API Endpoints</h2>
              </div>
              <div className="space-y-4">
                {model.endpoints.map((endpoint, index) => <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center">
                        <span className={`px-2 py-1 text-xs font-medium rounded mr-2 ${endpoint.method === 'GET' ? 'bg-green-100 text-green-800' : endpoint.method === 'POST' ? 'bg-blue-100 text-blue-800' : endpoint.method === 'PUT' ? 'bg-yellow-100 text-yellow-800' : endpoint.method === 'DELETE' ? 'bg-red-100 text-red-800' : 'bg-purple-100 text-purple-800'}`}>
                          {endpoint.method}
                        </span>
                        <span className="font-medium text-blue-600">
                          {endpoint.path}
                        </span>
                      </div>
                    </div>
                    {endpoint.description && <div className="mb-3 text-sm text-gray-600">
                        {endpoint.description}
                      </div>}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                      {endpoint.requestBody && endpoint.requestBody !== '{}' && <div className="bg-gray-50 p-3 rounded-lg">
                            <h4 className="text-xs font-semibold text-gray-500 mb-2">
                              REQUÊTE
                            </h4>
                            <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                              {formatJson(endpoint.requestBody)}
                            </pre>
                          </div>}
                      {endpoint.successResponse && endpoint.successResponse !== '{}' && <div className="bg-green-50 p-3 rounded-lg">
                            <h4 className="text-xs font-semibold text-green-600 mb-2">
                              SUCCÈS
                            </h4>
                            <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                              {formatJson(endpoint.successResponse)}
                            </pre>
                          </div>}
                      {endpoint.errorResponse && endpoint.errorResponse !== '{}' && <div className="bg-red-50 p-3 rounded-lg">
                            <h4 className="text-xs font-semibold text-red-600 mb-2">
                              ERREUR
                            </h4>
                            <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                              {formatJson(endpoint.errorResponse)}
                            </pre>
                          </div>}
                    </div>
                  </div>)}
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center mb-4">
                <MessageSquare className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-lg font-semibold">Commentaires</h2>
              </div>
              <div className="space-y-4 mb-6">
                {comments.map(comment => <div key={comment.id} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center mb-2">
                      <img src={comment.avatar} alt={comment.username} className="h-8 w-8 rounded-full mr-2" />
                      <div>
                        <p className="font-medium">{comment.username}</p>
                        <p className="text-xs text-gray-500">{comment.date}</p>
                      </div>
                    </div>
                    <p className="text-gray-700">{comment.content}</p>
                  </div>)}
              </div>
              <form onSubmit={handleCommentSubmit} className="space-y-4">
                <div>
                  <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
                    Ajouter un commentaire
                  </label>
                  <textarea id="comment" rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={newComment} onChange={e => setNewComment(e.target.value)} placeholder="Partagez votre expérience avec ce modèle..." />
                </div>
                <div className="flex justify-end">
                  <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                    <Send className="h-4 w-4 mr-2" />
                    Publier
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>;
}