import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Lock, Bell, Globe, CreditCard, Shield, Key, Save, Check, AlertTriangle, Mail, Phone, Home, Smartphone, Moon, Sun, FileText, Building, DollarSign, Settings as SettingsIcon, Database, Eye, EyeOff } from 'lucide-react';
import { DeveloperDashboardHeader } from '../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../components/developer-dashboard/DeveloperDashboardSidebar';
interface DeveloperSettings {
  email: string;
  language: string;
  notifications: {
    email: boolean;
    push: boolean;
    subscribers: boolean;
    revenue: boolean;
    ratings: boolean;
    marketing: boolean;
  };
  security: {
    twoFactorAuth: boolean;
    sessionTimeout: number;
  };
  apiSettings: {
    defaultTimeout: number;
    defaultFormat: string;
    rateLimit: number;
  };
  resourceDefaults: {
    modelVisibility: 'public' | 'private';
    datasetVisibility: 'public' | 'private';
    requireCitation: boolean;
    defaultLicense: string;
  };
  payoutSettings: {
    autoPayout: boolean;
    minPayoutAmount: number;
    payoutDay: number;
  };
  dockerHub: {
    username: string;
    token: string;
  };
}
export function DeveloperSettingsPage() {
  const [activeTab, setActiveTab] = useState('settings');
  const [settingsTab, setSettingsTab] = useState<string>('profile');
  const [settings, setSettings] = useState<DeveloperSettings>({
    email: 'contact@ailabtunisia.com',
    language: 'fr',
    notifications: {
      email: true,
      push: true,
      subscribers: true,
      revenue: true,
      ratings: true,
      marketing: false
    },
    security: {
      twoFactorAuth: false,
      sessionTimeout: 30
    },
    apiSettings: {
      defaultTimeout: 60,
      defaultFormat: 'json',
      rateLimit: 100
    },
    resourceDefaults: {
      modelVisibility: 'public',
      datasetVisibility: 'public',
      requireCitation: true,
      defaultLicense: 'CC BY-NC-SA 4.0'
    },
    payoutSettings: {
      autoPayout: true,
      minPayoutAmount: 500,
      payoutDay: 15
    },
    dockerHub: {
      username: '',
      token: ''
    }
  });
  const [loading, setLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showToken, setShowToken] = useState(false);
  // Developer profile data
  const [profile, setProfile] = useState({
    name: 'AI Lab Tunisia',
    email: 'contact@ailabtunisia.com',
    phone: '+216 71 123 456',
    company: 'AI Lab Tunisia',
    website: 'https://ailabtunisia.com',
    address: '15 Rue de Carthage, Tunis',
    bio: "AI Lab Tunisia est un laboratoire spécialisé dans le développement de modèles d'intelligence artificielle adaptés aux besoins spécifiques de la région MENA.",
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=ALT',
    socialLinks: {
      twitter: 'https://twitter.com/ailabtunisia',
      linkedin: 'https://linkedin.com/company/ailabtunisia',
      github: 'https://github.com/ailabtunisia'
    }
  });
  // Password change fields
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  // Payment methods
  const [paymentMethods, setPaymentMethods] = useState([{
    id: 'pm_1',
    type: 'bank_account',
    details: {
      bankName: 'Banque Nationale de Tunisie',
      accountNumber: '•••• 5678'
    },
    isDefault: true
  }, {
    id: 'pm_2',
    type: 'paypal',
    details: {
      email: 'ai.lab.tunisia@example.com'
    },
    isDefault: false
  }]);
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  const handleSettingsTabChange = (tab: string) => {
    setSettingsTab(tab);
  };
  const handleSaveSettings = () => {
    setLoading(true);
    setError(null);
    // Simulate API call
    setTimeout(() => {
      try {
        // In a real app, this would be an API call to save settings
        localStorage.setItem('developerSettings', JSON.stringify(settings));
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } catch (err) {
        setError("Une erreur est survenue lors de l'enregistrement des paramètres");
      } finally {
        setLoading(false);
      }
    }, 800);
  };
  const handleSaveProfile = () => {
    setLoading(true);
    setError(null);
    // Simulate API call
    setTimeout(() => {
      try {
        // In a real app, this would be an API call to save profile
        localStorage.setItem('developerProfile', JSON.stringify(profile));
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } catch (err) {
        setError("Une erreur est survenue lors de l'enregistrement du profil");
      } finally {
        setLoading(false);
      }
    }, 800);
  };
  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }
    if (passwordData.newPassword.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }
    setLoading(true);
    setError(null);
    // Simulate API call
    setTimeout(() => {
      try {
        // In a real app, this would be an API call to change password
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        // Reset password fields
        setPasswordData({
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
      } catch (err) {
        setError('Une erreur est survenue lors du changement de mot de passe');
      } finally {
        setLoading(false);
      }
    }, 800);
  };
  const handleSetDefaultPaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.map(method => ({
      ...method,
      isDefault: method.id === id
    })));
  };
  const handleRemovePaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.filter(method => method.id !== id));
  };
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-6xl">
            {saveSuccess && <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                <p className="text-green-700">
                  Modifications enregistrées avec succès
                </p>
              </div>}
            {error && <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />
                <p className="text-red-700">{error}</p>
              </div>}
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="flex flex-col md:flex-row">
                {/* Sidebar */}
                <div className="w-full md:w-64 bg-gray-50 p-6 border-r border-gray-200">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6">
                    Paramètres
                  </h2>
                  <nav className="space-y-1">
                    <button onClick={() => handleSettingsTabChange('profile')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'profile' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <User className="h-5 w-5 mr-3" />
                      Profil
                    </button>
                    <button onClick={() => handleSettingsTabChange('security')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'security' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <Lock className="h-5 w-5 mr-3" />
                      Sécurité
                    </button>
                    <button onClick={() => handleSettingsTabChange('notifications')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'notifications' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <Bell className="h-5 w-5 mr-3" />
                      Notifications
                    </button>
                    <button onClick={() => handleSettingsTabChange('preferences')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'preferences' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <Globe className="h-5 w-5 mr-3" />
                      Préférences
                    </button>
                    <button onClick={() => handleSettingsTabChange('billing')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'billing' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <CreditCard className="h-5 w-5 mr-3" />
                      Paiements
                    </button>
                    <button onClick={() => handleSettingsTabChange('api')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'api' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <Key className="h-5 w-5 mr-3" />
                      API
                    </button>
                    <button onClick={() => handleSettingsTabChange('dockerhub')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'dockerhub' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <div className="h-5 w-5 mr-3" />
                      Docker Hub
                    </button>
                    <button onClick={() => handleSettingsTabChange('resources')} className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${settingsTab === 'resources' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <SettingsIcon className="h-5 w-5 mr-3" />
                      Ressources
                    </button>
                  </nav>
                  <div className="mt-10">
                    <Link to="/developer/dashboard" className="text-sm text-blue-600 hover:text-blue-800">
                      ← Retour au tableau de bord
                    </Link>
                  </div>
                </div>
                {/* Main content */}
                <div className="flex-1 p-6">
                  {/* Profile Settings */}
                  {settingsTab === 'profile' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Informations du développeur
                      </h2>
                      <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center">
                        <div className="relative mb-4 sm:mb-0 sm:mr-6">
                          <img src={profile.avatar} alt={profile.name} className="h-24 w-24 rounded-full" />
                          <button className="absolute bottom-0 right-0 bg-blue-600 text-white p-1 rounded-full">
                            <User className="h-4 w-4" />
                          </button>
                        </div>
                        <div>
                          <h3 className="text-lg font-medium">
                            {profile.name}
                          </h3>
                          <p className="text-gray-500">{profile.email}</p>
                          <p className="text-sm text-gray-500">
                            Développeur IA chez {profile.company}
                          </p>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Nom de l'organisation
                          </label>
                          <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.name} onChange={e => setProfile({
                        ...profile,
                        name: e.target.value
                      })} />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Email
                          </label>
                          <div className="flex">
                            <input type="email" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.email} onChange={e => setProfile({
                          ...profile,
                          email: e.target.value
                        })} />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Téléphone
                          </label>
                          <div className="flex">
                            <span className="inline-flex items-center px-3 py-2 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500">
                              <Phone className="h-4 w-4" />
                            </span>
                            <input type="tel" className="w-full px-3 py-2 border border-gray-300 rounded-r-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.phone} onChange={e => setProfile({
                          ...profile,
                          phone: e.target.value
                        })} />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Site web
                          </label>
                          <div className="flex">
                            <span className="inline-flex items-center px-3 py-2 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500">
                              <Globe className="h-4 w-4" />
                            </span>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-r-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.website} onChange={e => setProfile({
                          ...profile,
                          website: e.target.value
                        })} />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Organisation
                          </label>
                          <div className="flex">
                            <span className="inline-flex items-center px-3 py-2 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500">
                              <Building className="h-4 w-4" />
                            </span>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-r-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.company} onChange={e => setProfile({
                          ...profile,
                          company: e.target.value
                        })} />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Adresse
                          </label>
                          <div className="flex">
                            <span className="inline-flex items-center px-3 py-2 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500">
                              <Home className="h-4 w-4" />
                            </span>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-r-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.address} onChange={e => setProfile({
                          ...profile,
                          address: e.target.value
                        })} />
                          </div>
                        </div>
                      </div>
                      <div className="mb-6">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Bio
                        </label>
                        <textarea rows={4} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.bio} onChange={e => setProfile({
                      ...profile,
                      bio: e.target.value
                    })} />
                        <p className="mt-1 text-sm text-gray-500">
                          Brève description de votre organisation qui sera
                          affichée sur votre profil public.
                        </p>
                      </div>
                      <div className="mb-6">
                        <h3 className="text-sm font-medium text-gray-700 mb-3">
                          Réseaux sociaux
                        </h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Twitter
                            </label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.socialLinks.twitter} onChange={e => setProfile({
                          ...profile,
                          socialLinks: {
                            ...profile.socialLinks,
                            twitter: e.target.value
                          }
                        })} placeholder="https://twitter.com/username" />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              LinkedIn
                            </label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.socialLinks.linkedin} onChange={e => setProfile({
                          ...profile,
                          socialLinks: {
                            ...profile.socialLinks,
                            linkedin: e.target.value
                          }
                        })} placeholder="https://linkedin.com/company/name" />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              GitHub
                            </label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={profile.socialLinks.github} onChange={e => setProfile({
                          ...profile,
                          socialLinks: {
                            ...profile.socialLinks,
                            github: e.target.value
                          }
                        })} placeholder="https://github.com/username" />
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveProfile} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                  {/* Security Settings */}
                  {settingsTab === 'security' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Sécurité
                      </h2>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Changer le mot de passe
                        </h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Mot de passe actuel
                            </label>
                            <input type="password" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={passwordData.currentPassword} onChange={e => setPasswordData({
                          ...passwordData,
                          currentPassword: e.target.value
                        })} />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Nouveau mot de passe
                            </label>
                            <input type="password" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={passwordData.newPassword} onChange={e => setPasswordData({
                          ...passwordData,
                          newPassword: e.target.value
                        })} />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Confirmer le nouveau mot de passe
                            </label>
                            <input type="password" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={passwordData.confirmPassword} onChange={e => setPasswordData({
                          ...passwordData,
                          confirmPassword: e.target.value
                        })} />
                          </div>
                          <div className="flex justify-end">
                            <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleChangePassword} disabled={loading}>
                              Mettre à jour le mot de passe
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Authentification à deux facteurs
                        </h3>
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <input id="2fa" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.security.twoFactorAuth} onChange={e => setSettings({
                          ...settings,
                          security: {
                            ...settings.security,
                            twoFactorAuth: e.target.checked
                          }
                        })} />
                          </div>
                          <div className="ml-3 text-sm">
                            <label htmlFor="2fa" className="font-medium text-gray-700">
                              Activer l'authentification à deux facteurs
                            </label>
                            <p className="text-gray-500">
                              Renforcez la sécurité de votre compte en exigeant
                              à la fois un mot de passe et un code
                              d'authentification.
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Expiration de session
                        </h3>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Déconnexion automatique après inactivité (minutes)
                          </label>
                          <select className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md" value={settings.security.sessionTimeout} onChange={e => setSettings({
                        ...settings,
                        security: {
                          ...settings.security,
                          sessionTimeout: parseInt(e.target.value)
                        }
                      })}>
                            <option value={15}>15 minutes</option>
                            <option value={30}>30 minutes</option>
                            <option value={60}>1 heure</option>
                            <option value={120}>2 heures</option>
                            <option value={240}>4 heures</option>
                          </select>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveSettings} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                  {/* Notification Settings */}
                  {settingsTab === 'notifications' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Notifications
                      </h2>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Canaux de notification
                        </h3>
                        <div className="space-y-4">
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="email-notifications" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.notifications.email} onChange={e => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              email: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="email-notifications" className="font-medium text-gray-700">
                                Notifications par email
                              </label>
                              <p className="text-gray-500">
                                Recevez des notifications par email pour les
                                activités importantes.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="push-notifications" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.notifications.push} onChange={e => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              push: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="push-notifications" className="font-medium text-gray-700">
                                Notifications push
                              </label>
                              <p className="text-gray-500">
                                Recevez des notifications push dans votre
                                navigateur.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Types de notification
                        </h3>
                        <div className="space-y-4">
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="subscribers-notifications" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.notifications.subscribers} onChange={e => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              subscribers: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="subscribers-notifications" className="font-medium text-gray-700">
                                Abonnés
                              </label>
                              <p className="text-gray-500">
                                Notifications concernant les nouveaux abonnés et
                                les renouvellements.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="revenue-notifications" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.notifications.revenue} onChange={e => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              revenue: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="revenue-notifications" className="font-medium text-gray-700">
                                Revenus
                              </label>
                              <p className="text-gray-500">
                                Notifications concernant les paiements reçus et
                                les versements.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="ratings-notifications" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.notifications.ratings} onChange={e => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              ratings: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="ratings-notifications" className="font-medium text-gray-700">
                                Évaluations
                              </label>
                              <p className="text-gray-500">
                                Notifications concernant les nouvelles
                                évaluations et commentaires.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="marketing-notifications" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.notifications.marketing} onChange={e => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              marketing: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="marketing-notifications" className="font-medium text-gray-700">
                                Marketing
                              </label>
                              <p className="text-gray-500">
                                Nouvelles fonctionnalités, mises à jour et
                                offres spéciales.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveSettings} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                  {/* Billing Settings */}
                  {settingsTab === 'billing' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Paiements
                      </h2>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Paramètres de versement
                        </h3>
                        <div className="space-y-4">
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="auto-payout" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.payoutSettings.autoPayout} onChange={e => setSettings({
                            ...settings,
                            payoutSettings: {
                              ...settings.payoutSettings,
                              autoPayout: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="auto-payout" className="font-medium text-gray-700">
                                Versements automatiques
                              </label>
                              <p className="text-gray-500">
                                Recevez automatiquement vos revenus chaque mois
                                lorsque le seuil minimum est atteint.
                              </p>
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Montant minimum de versement (TND)
                            </label>
                            <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={settings.payoutSettings.minPayoutAmount} onChange={e => setSettings({
                          ...settings,
                          payoutSettings: {
                            ...settings.payoutSettings,
                            minPayoutAmount: parseInt(e.target.value)
                          }
                        })} min={100} />
                            <p className="mt-1 text-sm text-gray-500">
                              Les versements ne seront effectués que lorsque
                              votre solde dépassera ce montant.
                            </p>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Jour de versement mensuel
                            </label>
                            <select className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={settings.payoutSettings.payoutDay} onChange={e => setSettings({
                          ...settings,
                          payoutSettings: {
                            ...settings.payoutSettings,
                            payoutDay: parseInt(e.target.value)
                          }
                        })}>
                              {[1, 5, 10, 15, 20, 25].map(day => <option key={day} value={day}>
                                  {day} du mois
                                </option>)}
                            </select>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Méthodes de paiement
                        </h3>
                        {paymentMethods.length === 0 ? <div className="text-center py-4">
                            <p className="text-gray-500 mb-4">
                              Aucune méthode de paiement enregistrée
                            </p>
                          </div> : <div className="space-y-4">
                            {paymentMethods.map(method => <div key={method.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg bg-white">
                                <div className="flex items-center">
                                  <div className="mr-4">
                                    <CreditCard className="h-8 w-8 text-gray-400" />
                                  </div>
                                  <div>
                                    <p className="font-medium">
                                      {method.type === 'bank_account' ? 'Compte bancaire' : 'PayPal'}
                                    </p>
                                    <p className="text-sm text-gray-500">
                                      {method.type === 'bank_account' ? `${method.details.bankName} - ${method.details.accountNumber}` : method.details.email}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  {method.isDefault ? <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                      Par défaut
                                    </span> : <button type="button" className="text-sm text-blue-600 hover:text-blue-800" onClick={() => handleSetDefaultPaymentMethod(method.id)}>
                                      Définir par défaut
                                    </button>}
                                  <button type="button" className="text-sm text-red-600 hover:text-red-800" onClick={() => handleRemovePaymentMethod(method.id)}>
                                    Supprimer
                                  </button>
                                </div>
                              </div>)}
                          </div>}
                        <div className="mt-4">
                          <button type="button" className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            <CreditCard className="h-4 w-4 mr-2" />
                            Ajouter une méthode de paiement
                          </button>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Informations fiscales
                        </h3>
                        <p className="text-sm text-gray-500 mb-4">
                          Assurez-vous que vos informations fiscales sont à jour
                          pour éviter tout problème avec les paiements.
                        </p>
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                          <FileText className="h-4 w-4 mr-2" />
                          Gérer les informations fiscales
                        </button>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveSettings} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                  {/* API Settings */}
                  {settingsTab === 'api' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Paramètres API
                      </h2>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Clés API
                        </h3>
                        <p className="text-gray-600 mb-4">
                          Gérez vos clés API pour l'accès à la console
                          développeur et aux statistiques.
                        </p>
                        <Link to="/developer/api-keys" className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                          <Key className="h-4 w-4 mr-2" />
                          Gérer les clés API
                        </Link>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">
                          Paramètres par défaut
                        </h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Timeout par défaut (secondes)
                            </label>
                            <input type="number" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md" value={settings.apiSettings.defaultTimeout} onChange={e => setSettings({
                          ...settings,
                          apiSettings: {
                            ...settings.apiSettings,
                            defaultTimeout: parseInt(e.target.value)
                          }
                        })} min={1} max={300} />
                            <p className="mt-1 text-sm text-gray-500">
                              Délai d'expiration par défaut pour les appels API.
                            </p>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Format de réponse par défaut
                            </label>
                            <select className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md" value={settings.apiSettings.defaultFormat} onChange={e => setSettings({
                          ...settings,
                          apiSettings: {
                            ...settings.apiSettings,
                            defaultFormat: e.target.value
                          }
                        })}>
                              <option value="json">JSON</option>
                              <option value="xml">XML</option>
                              <option value="csv">CSV</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Limite de requêtes par minute
                            </label>
                            <input type="number" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md" value={settings.apiSettings.rateLimit} onChange={e => setSettings({
                          ...settings,
                          apiSettings: {
                            ...settings.apiSettings,
                            rateLimit: parseInt(e.target.value)
                          }
                        })} min={10} max={1000} />
                            <p className="mt-1 text-sm text-gray-500">
                              Nombre maximum de requêtes API par minute pour vos
                              clients.
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveSettings} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                  {/* Resources Settings */}
                  {settingsTab === 'resources' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Paramètres des ressources
                      </h2>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                          <div className="h-5 w-5 text-blue-600 mr-2" />
                          Paramètres des modèles
                        </h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Visibilité par défaut
                            </label>
                            <div className="mt-1 flex items-center space-x-4">
                              <div className="flex items-center">
                                <input id="model-visibility-public" name="model-visibility" type="radio" className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked={settings.resourceDefaults.modelVisibility === 'public'} onChange={() => setSettings({
                              ...settings,
                              resourceDefaults: {
                                ...settings.resourceDefaults,
                                modelVisibility: 'public'
                              }
                            })} />
                                <label htmlFor="model-visibility-public" className="ml-2 block text-sm text-gray-700">
                                  Public
                                </label>
                              </div>
                              <div className="flex items-center">
                                <input id="model-visibility-private" name="model-visibility" type="radio" className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked={settings.resourceDefaults.modelVisibility === 'private'} onChange={() => setSettings({
                              ...settings,
                              resourceDefaults: {
                                ...settings.resourceDefaults,
                                modelVisibility: 'private'
                              }
                            })} />
                                <label htmlFor="model-visibility-private" className="ml-2 block text-sm text-gray-700">
                                  Privé
                                </label>
                              </div>
                            </div>
                            <p className="mt-1 text-sm text-gray-500">
                              Les modèles publics sont visibles dans la
                              marketplace, les modèles privés ne sont
                              accessibles que par vous.
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                          <Database className="h-5 w-5 text-green-600 mr-2" />
                          Paramètres des datasets
                        </h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Visibilité par défaut
                            </label>
                            <div className="mt-1 flex items-center space-x-4">
                              <div className="flex items-center">
                                <input id="dataset-visibility-public" name="dataset-visibility" type="radio" className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked={settings.resourceDefaults.datasetVisibility === 'public'} onChange={() => setSettings({
                              ...settings,
                              resourceDefaults: {
                                ...settings.resourceDefaults,
                                datasetVisibility: 'public'
                              }
                            })} />
                                <label htmlFor="dataset-visibility-public" className="ml-2 block text-sm text-gray-700">
                                  Public
                                </label>
                              </div>
                              <div className="flex items-center">
                                <input id="dataset-visibility-private" name="dataset-visibility" type="radio" className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked={settings.resourceDefaults.datasetVisibility === 'private'} onChange={() => setSettings({
                              ...settings,
                              resourceDefaults: {
                                ...settings.resourceDefaults,
                                datasetVisibility: 'private'
                              }
                            })} />
                                <label htmlFor="dataset-visibility-private" className="ml-2 block text-sm text-gray-700">
                                  Privé
                                </label>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <div className="flex items-center h-5">
                              <input id="require-citation" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked={settings.resourceDefaults.requireCitation} onChange={e => setSettings({
                            ...settings,
                            resourceDefaults: {
                              ...settings.resourceDefaults,
                              requireCitation: e.target.checked
                            }
                          })} />
                            </div>
                            <div className="ml-3 text-sm">
                              <label htmlFor="require-citation" className="font-medium text-gray-700">
                                Exiger une citation
                              </label>
                              <p className="text-gray-500">
                                Exiger que les utilisateurs citent votre dataset
                                lorsqu'ils l'utilisent dans leurs publications.
                              </p>
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Licence par défaut
                            </label>
                            <select className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md" value={settings.resourceDefaults.defaultLicense} onChange={e => setSettings({
                          ...settings,
                          resourceDefaults: {
                            ...settings.resourceDefaults,
                            defaultLicense: e.target.value
                          }
                        })}>
                              <option value="CC BY 4.0">
                                CC BY 4.0 - Attribution
                              </option>
                              <option value="CC BY-SA 4.0">
                                CC BY-SA 4.0 - Attribution-ShareAlike
                              </option>
                              <option value="CC BY-NC 4.0">
                                CC BY-NC 4.0 - Attribution-NonCommercial
                              </option>
                              <option value="CC BY-NC-SA 4.0">
                                CC BY-NC-SA 4.0 -
                                Attribution-NonCommercial-ShareAlike
                              </option>
                              <option value="CC BY-ND 4.0">
                                CC BY-ND 4.0 - Attribution-NoDerivatives
                              </option>
                              <option value="CC BY-NC-ND 4.0">
                                CC BY-NC-ND 4.0 -
                                Attribution-NonCommercial-NoDerivatives
                              </option>
                              <option value="CUSTOM">
                                Licence personnalisée
                              </option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveSettings} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                  {/* Docker Hub Settings */}
                  {settingsTab === 'dockerhub' && <div>
                      <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Identifiants Docker Hub
                      </h2>
                      <div className="bg-gray-50 p-6 rounded-lg mb-6">
                        <div className="flex items-start mb-6">
                          <div className="h-8 w-8 text-blue-600 mr-4 mt-1" />
                          <div>
                            <h3 className="text-lg font-medium text-gray-900">
                              Configuration Docker Hub
                            </h3>
                            <p className="text-gray-600 mt-1">
                              Configurez vos identifiants Docker Hub pour
                              accéder à vos images privées et automatiser les
                              déploiements.
                            </p>
                          </div>
                        </div>
                        <div className="space-y-5">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Nom d'utilisateur Docker Hub
                            </label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value={settings.dockerHub.username} onChange={e => setSettings({
                          ...settings,
                          dockerHub: {
                            ...settings.dockerHub,
                            username: e.target.value
                          }
                        })} placeholder="votre-nom-utilisateur" />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Token d'accès personnel (PAT)
                            </label>
                            <div className="relative">
                              <input type={showToken ? 'text' : 'password'} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 pr-10" value={settings.dockerHub.token} onChange={e => setSettings({
                            ...settings,
                            dockerHub: {
                              ...settings.dockerHub,
                              token: e.target.value
                            }
                          })} placeholder="dckr_pat_***********************" />
                              <button type="button" className="absolute inset-y-0 right-0 pr-3 flex items-center" onClick={() => setShowToken(!showToken)}>
                                {showToken ? <EyeOff className="h-5 w-5 text-gray-400" /> : <Eye className="h-5 w-5 text-gray-400" />}
                              </button>
                            </div>
                            <p className="mt-1 text-sm text-gray-500">
                              Votre PAT sera chiffré et utilisé uniquement pour
                              vérifier vos images privées.
                            </p>
                          </div>
                          <div className="bg-blue-50 p-4 rounded-md">
                            <div className="flex">
                              <Shield className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                              <div>
                                <h4 className="text-sm font-medium text-blue-800">
                                  Bonnes pratiques de sécurité
                                </h4>
                                <ul className="mt-2 text-sm text-blue-700 space-y-1 list-disc list-inside">
                                  <li>
                                    Créez un token avec des permissions limitées
                                    (lecture seule)
                                  </li>
                                  <li>
                                    Utilisez un token avec une date d'expiration
                                  </li>
                                  <li>
                                    Ne partagez jamais votre token avec d'autres
                                    personnes
                                  </li>
                                </ul>
                                <p className="mt-2 text-sm text-blue-700">
                                  <a href="https://docs.docker.com/docker-hub/access-tokens/" target="_blank" rel="noopener noreferrer" className="font-medium underline">
                                    En savoir plus sur les tokens Docker Hub
                                  </a>
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onClick={handleSaveSettings} disabled={loading}>
                          {loading ? <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg> : <Save className="h-4 w-4 mr-2" />}
                          Enregistrer
                        </button>
                      </div>
                    </div>}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>;
}