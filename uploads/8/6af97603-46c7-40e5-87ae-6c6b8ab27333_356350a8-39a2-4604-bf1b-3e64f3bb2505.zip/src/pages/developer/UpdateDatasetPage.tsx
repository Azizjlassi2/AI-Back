import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { UploadCloud, Database, FileText, Tag, Globe, Package, X, CreditCard, Plus, Save, Clock, Calendar, Trash2, Info, ArrowLeft, HardDrive } from 'lucide-react';
// Dataset visibility options
enum Visibility {
  PUBLIC = 'PUBLIC',
  PRIVATE = 'PRIVATE',
}
// Dataset format options
enum DatasetFormat {
  CSV = 'CSV',
  JSON = 'JSON',
  XML = 'XML',
  PARQUET = 'PARQUET',
  IMAGES = 'IMAGES',
  AUDIO = 'AUDIO',
  TEXT = 'TEXT',
  MIXED = 'MIXED',
}
// Dataset license options
enum LicenseType {
  CC_BY = 'CC_BY',
  CC_BY_SA = 'CC_BY_SA',
  CC_BY_NC = 'CC_BY_NC',
  CC_BY_ND = 'CC_BY_ND',
  CC_BY_NC_SA = 'CC_BY_NC_SA',
  CC_BY_NC_ND = 'CC_BY_NC_ND',
  CC0 = 'CC0',
  MIT = 'MIT',
  APACHE_2 = 'APACHE_2',
  GPL_3 = 'GPL_3',
  CUSTOM = 'CUSTOM',
}
// Billing period options
enum BillingPeriod {
  ONE_TIME = 'ONE_TIME',
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
}
// Interface for dataset tags
interface Tag {
  id: number;
  name: string;
}
// Interface for dataset sample
interface DatasetSample {
  id?: number;
  content: string;
  label?: string;
}
// Interface for dataset purchasing plan
interface PurchasePlan {
  name: string;
  description: string;
  price: number;
  currency: string;
  billingPeriod: BillingPeriod;
  features: string[];
}
// Main dataset interface
interface Dataset {
  id: number;
  name: string;
  description: string;
  visibility: Visibility;
  format: DatasetFormat;
  size: string;
  sampleCount: number;
  license: LicenseType;
  customLicenseUrl?: string;
  tags: Tag[];
  samples: DatasetSample[];
  purchasePlan: PurchasePlan | null;
  version?: string;
  status?: 'PUBLISHED' | 'DRAFT' | 'UNDER_REVIEW' | 'REJECTED';
}
export function UpdateDatasetPage() {
  const {
    datasetId
  } = useParams<{
    datasetId: string;
  }>();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<{
    [key: string]: string;
  }>({});
  const [success, setSuccess] = useState<boolean>(false);
  // State for dataset
  const [dataset, setDataset] = useState<Dataset>({
    id: parseInt(datasetId || '0'),
    name: '',
    description: '',
    visibility: Visibility.PUBLIC,
    format: DatasetFormat.CSV,
    size: '',
    sampleCount: 0,
    license: LicenseType.CC_BY,
    customLicenseUrl: '',
    tags: [],
    samples: [],
    purchasePlan: null,
    version: '1.0.0',
    status: 'PUBLISHED'
  });
  // State for tag input
  const [tagInput, setTagInput] = useState('');
  // State for sample inputs
  const [sampleInput, setSampleInput] = useState({
    content: '',
    label: ''
  });
  // State for purchase plan
  const [purchasePlan, setPurchasePlan] = useState<PurchasePlan>({
    name: 'Standard Access',
    description: 'Full access to the dataset with standard support',
    price: 0,
    currency: 'TND',
    billingPeriod: BillingPeriod.ONE_TIME,
    features: ['Full dataset download', 'Documentation access']
  });
  // State for new feature in purchase plan
  const [newFeature, setNewFeature] = useState('');
  // State for file upload
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  useEffect(() => {
    const fetchDataset = async () => {
      setIsLoading(true);
      try {
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 800));
        // Mock data for a dataset
        const mockDataset: Dataset = {
          id: parseInt(datasetId || '1'),
          name: 'Tunisian Dialect Corpus',
          description: 'Corpus de textes en dialecte tunisien pour NLP',
          visibility: Visibility.PUBLIC,
          format: DatasetFormat.JSON,
          size: '2.3GB',
          sampleCount: 1200000,
          license: LicenseType.CC_BY_NC_SA,
          customLicenseUrl: '',
          tags: [{
            id: 1,
            name: 'NLP'
          }, {
            id: 2,
            name: 'Arabic'
          }, {
            id: 3,
            name: 'Dialect'
          }, {
            id: 4,
            name: 'Tunisia'
          }, {
            id: 5,
            name: 'Text Corpus'
          }],
          samples: [{
            id: 1,
            content: '{"text": "شنوة الأخبار؟", "source": "conversation", "region": "Tunis", "sentiment": "neutral"}',
            label: 'Neutral sentiment'
          }, {
            id: 2,
            content: '{"text": "برشا باهي اليوم", "source": "social media", "region": "Sousse", "sentiment": "positive"}',
            label: 'Positive sentiment'
          }],
          purchasePlan: {
            name: 'Standard Access',
            description: 'Full access to the dataset with standard support',
            price: 149.99,
            currency: 'TND',
            billingPeriod: BillingPeriod.ONE_TIME,
            features: ['Full dataset download', 'Documentation access', 'Email support', 'Updates for 1 year']
          },
          version: '2.3.0',
          status: 'PUBLISHED'
        };
        setDataset(mockDataset);
        if (mockDataset.purchasePlan) {
          setPurchasePlan(mockDataset.purchasePlan);
        }
      } catch (error) {
        console.error('Error fetching dataset:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchDataset();
  }, [datasetId]);
  // Handle adding a new tag
  const handleAddTag = () => {
    if (tagInput.trim()) {
      const newTag = {
        id: Date.now(),
        name: tagInput.trim()
      };
      setDataset({
        ...dataset,
        tags: [...dataset.tags, newTag]
      });
      setTagInput('');
    }
  };
  // Handle removing a tag
  const handleRemoveTag = (tagId: number) => {
    setDataset({
      ...dataset,
      tags: dataset.tags.filter(tag => tag.id !== tagId)
    });
  };
  // Handle adding a new sample
  const handleAddSample = () => {
    if (sampleInput.content.trim()) {
      const newSample = {
        id: Date.now(),
        content: sampleInput.content,
        label: sampleInput.label
      };
      setDataset({
        ...dataset,
        samples: [...dataset.samples, newSample]
      });
      setSampleInput({
        content: '',
        label: ''
      });
    }
  };
  // Handle removing a sample
  const handleRemoveSample = (sampleId: number) => {
    setDataset({
      ...dataset,
      samples: dataset.samples.filter(sample => sample.id !== sampleId)
    });
  };
  // Handle adding a feature to the purchase plan
  const handleAddFeature = () => {
    if (newFeature.trim()) {
      setPurchasePlan({
        ...purchasePlan,
        features: [...purchasePlan.features, newFeature.trim()]
      });
      setNewFeature('');
    }
  };
  // Handle removing a feature from the purchase plan
  const handleRemoveFeature = (index: number) => {
    const updatedFeatures = [...purchasePlan.features];
    updatedFeatures.splice(index, 1);
    setPurchasePlan({
      ...purchasePlan,
      features: updatedFeatures
    });
  };
  // Handle saving the purchase plan
  const handleSavePurchasePlan = () => {
    setDataset({
      ...dataset,
      purchasePlan: purchasePlan
    });
  };
  // Handle removing the purchase plan
  const handleRemovePurchasePlan = () => {
    setDataset({
      ...dataset,
      purchasePlan: null
    });
  };
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
      // Update dataset size based on file size
      const fileSizeInBytes = e.target.files[0].size;
      let fileSizeFormatted = '';
      if (fileSizeInBytes < 1024 * 1024) {
        fileSizeFormatted = `${(fileSizeInBytes / 1024).toFixed(2)}KB`;
      } else if (fileSizeInBytes < 1024 * 1024 * 1024) {
        fileSizeFormatted = `${(fileSizeInBytes / (1024 * 1024)).toFixed(2)}MB`;
      } else {
        fileSizeFormatted = `${(fileSizeInBytes / (1024 * 1024 * 1024)).toFixed(2)}GB`;
      }
      setDataset({
        ...dataset,
        size: fileSizeFormatted
      });
    }
  };
  // Simulate file upload
  const handleFileUpload = async () => {
    if (!selectedFile) return;
    setIsUploading(true);
    setUploadProgress(0);
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prevProgress => {
        const newProgress = prevProgress + 5;
        if (newProgress >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsUploading(false);
            setUploadProgress(0);
          }, 500);
          return 100;
        }
        return newProgress;
      });
    }, 200);
  };
  // Validate the form
  const validateForm = (): boolean => {
    const newErrors: {
      [key: string]: string;
    } = {};
    if (!dataset.name.trim()) {
      newErrors.name = 'Le nom du dataset est requis';
    }
    if (!dataset.description.trim()) {
      newErrors.description = 'La description est requise';
    }
    if (!dataset.size.trim()) {
      newErrors.size = 'La taille du dataset est requise';
    }
    if (dataset.license === LicenseType.CUSTOM && !dataset.customLicenseUrl?.trim()) {
      newErrors.customLicenseUrl = "L'URL de la licence personnalisée est requise";
    }
    if (dataset.samples.length === 0) {
      newErrors.samples = 'Au moins un exemple est requis';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setIsSaving(true);
      try {
        // In a real app, this would be an API call to update the dataset
        await new Promise(resolve => setTimeout(resolve, 1500));
        // If there's a file to upload, handle that first
        if (selectedFile && !isUploading) {
          await handleFileUpload();
        }
        setSuccess(true);
        setTimeout(() => {
          setSuccess(false);
        }, 3000);
      } catch (error) {
        console.error('Error updating dataset:', error);
      } finally {
        setIsSaving(false);
      }
    }
  };
  // Get license display name
  const getLicenseName = (license: LicenseType): string => {
    switch (license) {
      case LicenseType.CC_BY:
        return 'Creative Commons Attribution (CC BY)';
      case LicenseType.CC_BY_SA:
        return 'CC Attribution-ShareAlike (CC BY-SA)';
      case LicenseType.CC_BY_NC:
        return 'CC Attribution-NonCommercial (CC BY-NC)';
      case LicenseType.CC_BY_ND:
        return 'CC Attribution-NoDerivs (CC BY-ND)';
      case LicenseType.CC_BY_NC_SA:
        return 'CC Attribution-NonCommercial-ShareAlike (CC BY-NC-SA)';
      case LicenseType.CC_BY_NC_ND:
        return 'CC Attribution-NonCommercial-NoDerivs (CC BY-NC-ND)';
      case LicenseType.CC0:
        return 'Creative Commons Zero (CC0)';
      case LicenseType.MIT:
        return 'MIT License';
      case LicenseType.APACHE_2:
        return 'Apache License 2.0';
      case LicenseType.GPL_3:
        return 'GNU General Public License v3.0';
      case LicenseType.CUSTOM:
        return 'Licence personnalisée';
      default:
        return '';
    }
  };
  // Get billing period display name
  const getBillingPeriodName = (period: BillingPeriod): string => {
    switch (period) {
      case BillingPeriod.ONE_TIME:
        return 'Paiement unique';
      case BillingPeriod.MONTHLY:
        return 'Mensuel';
      case BillingPeriod.ANNUAL:
        return 'Annuel';
      default:
        return '';
    }
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="bg-white rounded-xl shadow-sm p-8">
          <div className="flex items-center mb-6">
            <button onClick={() => navigate('/developer/datasets')} className="mr-4 text-gray-500 hover:text-gray-700">
              <ArrowLeft className="h-5 w-5" />
            </button>
            <h1 className="text-3xl font-bold flex items-center">
              <Database className="h-8 w-8 text-blue-600 mr-3" />
              Mettre à jour le dataset
            </h1>
          </div>
          {success && <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                <Check className="h-5 w-5 text-green-600" />
              </div>
              <span className="text-green-800">
                Dataset mis à jour avec succès
              </span>
            </div>}
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Information */}
            <div>
              <div className="flex items-center mb-4">
                <Database className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Informations de base</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nom du dataset *
                  </label>
                  <input type="text" className={`w-full px-4 py-2 border rounded-lg focus:ring-blue-500 focus:border-blue-500 ${errors.name ? 'border-red-500' : 'border-gray-300'}`} value={dataset.name} onChange={e => setDataset({
                  ...dataset,
                  name: e.target.value
                })} placeholder="ex: Tunisian Dialect Corpus" />
                  {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description *
                  </label>
                  <textarea rows={4} className={`w-full px-4 py-2 border rounded-lg focus:ring-blue-500 focus:border-blue-500 ${errors.description ? 'border-red-500' : 'border-gray-300'}`} value={dataset.description} onChange={e => setDataset({
                  ...dataset,
                  description: e.target.value
                })} placeholder="Décrivez votre dataset, son contenu, ses cas d'utilisation..." />
                  {errors.description && <p className="mt-1 text-sm text-red-500">
                      {errors.description}
                    </p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Version
                  </label>
                  <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={dataset.version || ''} onChange={e => setDataset({
                  ...dataset,
                  version: e.target.value
                })} placeholder="ex: 1.0.0" />
                </div>
              </div>
            </div>
            {/* Dataset Upload */}
            <div>
              <div className="flex items-center mb-4">
                <UploadCloud className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Fichiers du dataset</h2>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg border-2 border-dashed border-gray-300">
                <div className="text-center">
                  <UploadCloud className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {selectedFile ? selectedFile.name : 'Mettre à jour les fichiers du dataset'}
                  </h3>
                  <p className="text-gray-500 mb-4">
                    Glissez-déposez vos fichiers ici, ou cliquez pour
                    sélectionner des fichiers
                  </p>
                  <input type="file" id="file-upload" className="hidden" onChange={handleFileChange} />
                  <label htmlFor="file-upload" className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer">
                    <UploadCloud className="h-4 w-4 mr-2" />
                    {selectedFile ? 'Changer de fichier' : 'Sélectionner un fichier'}
                  </label>
                </div>
                {selectedFile && !isUploading && <div className="mt-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">
                        Prêt à télécharger
                      </span>
                      <span className="text-sm text-gray-500">
                        {dataset.size}
                      </span>
                    </div>
                    <button type="button" onClick={handleFileUpload} className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center justify-center">
                      <UploadCloud className="h-4 w-4 mr-2" />
                      Télécharger maintenant
                    </button>
                  </div>}
                {isUploading && <div className="mt-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">
                        Téléchargement en cours...
                      </span>
                      <span className="text-sm text-gray-500">
                        {uploadProgress}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-600 h-2.5 rounded-full" style={{
                    width: `${uploadProgress}%`
                  }}></div>
                    </div>
                  </div>}
              </div>
            </div>
            {/* Dataset Metadata */}
            <div>
              <div className="flex items-center mb-4">
                <FileText className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Métadonnées</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Format
                  </label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={dataset.format} onChange={e => setDataset({
                  ...dataset,
                  format: e.target.value as DatasetFormat
                })}>
                    <option value={DatasetFormat.CSV}>CSV</option>
                    <option value={DatasetFormat.JSON}>JSON</option>
                    <option value={DatasetFormat.XML}>XML</option>
                    <option value={DatasetFormat.PARQUET}>Parquet</option>
                    <option value={DatasetFormat.IMAGES}>Images</option>
                    <option value={DatasetFormat.AUDIO}>Audio</option>
                    <option value={DatasetFormat.TEXT}>Texte</option>
                    <option value={DatasetFormat.MIXED}>Format mixte</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Taille du dataset *
                  </label>
                  <input type="text" className={`w-full px-4 py-2 border rounded-lg focus:ring-blue-500 focus:border-blue-500 ${errors.size ? 'border-red-500' : 'border-gray-300'}`} value={dataset.size} onChange={e => setDataset({
                  ...dataset,
                  size: e.target.value
                })} placeholder="ex: 2.5GB, 500MB" readOnly={!!selectedFile} />
                  {errors.size && <p className="mt-1 text-sm text-red-500">{errors.size}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre d'échantillons
                  </label>
                  <input type="number" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={dataset.sampleCount} onChange={e => setDataset({
                  ...dataset,
                  sampleCount: parseInt(e.target.value) || 0
                })} placeholder="ex: 10000" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Licence
                  </label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={dataset.license} onChange={e => setDataset({
                  ...dataset,
                  license: e.target.value as LicenseType
                })}>
                    <option value={LicenseType.CC_BY}>
                      Creative Commons Attribution (CC BY)
                    </option>
                    <option value={LicenseType.CC_BY_SA}>
                      CC Attribution-ShareAlike (CC BY-SA)
                    </option>
                    <option value={LicenseType.CC_BY_NC}>
                      CC Attribution-NonCommercial (CC BY-NC)
                    </option>
                    <option value={LicenseType.CC_BY_ND}>
                      CC Attribution-NoDerivs (CC BY-ND)
                    </option>
                    <option value={LicenseType.CC_BY_NC_SA}>
                      CC Attribution-NonCommercial-ShareAlike (CC BY-NC-SA)
                    </option>
                    <option value={LicenseType.CC_BY_NC_ND}>
                      CC Attribution-NonCommercial-NoDerivs (CC BY-NC-ND)
                    </option>
                    <option value={LicenseType.CC0}>
                      Creative Commons Zero (CC0)
                    </option>
                    <option value={LicenseType.MIT}>MIT License</option>
                    <option value={LicenseType.APACHE_2}>
                      Apache License 2.0
                    </option>
                    <option value={LicenseType.GPL_3}>
                      GNU General Public License v3.0
                    </option>
                    <option value={LicenseType.CUSTOM}>
                      Licence personnalisée
                    </option>
                  </select>
                </div>
                {dataset.license === LicenseType.CUSTOM && <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      URL de la licence personnalisée *
                    </label>
                    <input type="url" className={`w-full px-4 py-2 border rounded-lg focus:ring-blue-500 focus:border-blue-500 ${errors.customLicenseUrl ? 'border-red-500' : 'border-gray-300'}`} value={dataset.customLicenseUrl || ''} onChange={e => setDataset({
                  ...dataset,
                  customLicenseUrl: e.target.value
                })} placeholder="https://example.com/license" />
                    {errors.customLicenseUrl && <p className="mt-1 text-sm text-red-500">
                        {errors.customLicenseUrl}
                      </p>}
                  </div>}
              </div>
            </div>
            {/* Tags */}
            <div>
              <div className="flex items-center mb-4">
                <Tag className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Tags</h2>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                {dataset.tags.map(tag => <div key={tag.id} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    {tag.name}
                    <button type="button" onClick={() => handleRemoveTag(tag.id)} className="ml-1 text-blue-600 hover:text-blue-800">
                      <X className="h-3 w-3" />
                    </button>
                  </div>)}
              </div>
              <div className="flex">
                <input type="text" className="flex-1 px-4 py-2 border border-gray-300 rounded-l-lg focus:ring-blue-500 focus:border-blue-500" value={tagInput} onChange={e => setTagInput(e.target.value)} placeholder="Ajouter un tag..." onKeyPress={e => e.key === 'Enter' && (e.preventDefault(), handleAddTag())} />
                <button type="button" onClick={handleAddTag} className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700">
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                Ajoutez des tags pour aider les utilisateurs à trouver votre
                dataset (ex: nlp, images, tunisie)
              </p>
            </div>
            {/* Dataset Samples */}
            <div>
              <div className="flex items-center mb-4">
                <Database className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Exemples de données</h2>
              </div>
              {errors.samples && <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start">
                  <AlertCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                  <p className="text-sm text-red-700">{errors.samples}</p>
                </div>}
              <div className="space-y-4 mb-4">
                {dataset.samples.map(sample => <div key={sample.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-medium">Exemple</div>
                      <button type="button" onClick={() => handleRemoveSample(sample.id!)} className="text-red-500 hover:text-red-700">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg mb-2 font-mono text-sm">
                      {sample.content}
                    </div>
                    {sample.label && <div className="text-sm text-gray-600">
                        <span className="font-medium">Label:</span>{' '}
                        {sample.label}
                      </div>}
                  </div>)}
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-md font-medium mb-3">Ajouter un exemple</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Contenu
                    </label>
                    <textarea rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 font-mono text-sm" value={sampleInput.content} onChange={e => setSampleInput({
                    ...sampleInput,
                    content: e.target.value
                  })} placeholder="Exemple de contenu de votre dataset..." />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Label (optionnel)
                    </label>
                    <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={sampleInput.label} onChange={e => setSampleInput({
                    ...sampleInput,
                    label: e.target.value
                  })} placeholder="ex: Positif, Question, Classe 1" />
                  </div>
                  <div>
                    <button type="button" onClick={handleAddSample} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                      <Plus className="h-4 w-4 mr-2" />
                      Ajouter l'exemple
                    </button>
                  </div>
                </div>
              </div>
            </div>
            {/* Purchase Plan */}
            <div>
              <div className="flex items-center mb-4">
                <CreditCard className="h-5 w-5 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Plan d'achat</h2>
              </div>
              {dataset.purchasePlan ? <div className="bg-white border border-gray-200 rounded-lg p-4 mb-4">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">
                        {dataset.purchasePlan.name}
                      </h3>
                      <p className="text-gray-600">
                        {dataset.purchasePlan.description}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <button type="button" onClick={() => {
                    setPurchasePlan(dataset.purchasePlan!);
                    setDataset({
                      ...dataset,
                      purchasePlan: null
                    });
                  }} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 text-sm">
                        Modifier
                      </button>
                      <button type="button" onClick={handleRemovePurchasePlan} className="px-3 py-1 bg-red-100 text-red-700 rounded-md hover:bg-red-200 text-sm">
                        Supprimer
                      </button>
                    </div>
                  </div>
                  <div className="flex items-baseline mb-3">
                    <span className="text-2xl font-bold">
                      {dataset.purchasePlan.price}{' '}
                      {dataset.purchasePlan.currency}
                    </span>
                    <span className="text-gray-500 ml-1">
                      {dataset.purchasePlan.billingPeriod !== BillingPeriod.ONE_TIME && `/${getBillingPeriodName(dataset.purchasePlan.billingPeriod)}é`}
                    </span>
                  </div>
                  <div className="space-y-2">
                    {dataset.purchasePlan.features.map((feature, index) => <div key={index} className="flex items-center text-sm">
                        <div className="h-4 w-4 rounded-full bg-green-100 flex items-center justify-center mr-2">
                          <svg className="h-3 w-3 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                        </div>
                        {feature}
                      </div>)}
                  </div>
                </div> : <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <h3 className="text-md font-medium mb-4">
                    Configurer un plan d'achat
                  </h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Nom du plan
                        </label>
                        <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={purchasePlan.name} onChange={e => setPurchasePlan({
                      ...purchasePlan,
                      name: e.target.value
                    })} placeholder="ex: Standard, Premium, Entreprise" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Type de facturation
                        </label>
                        <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={purchasePlan.billingPeriod} onChange={e => setPurchasePlan({
                      ...purchasePlan,
                      billingPeriod: e.target.value as BillingPeriod
                    })}>
                          <option value={BillingPeriod.ONE_TIME}>
                            Paiement unique
                          </option>
                          <option value={BillingPeriod.MONTHLY}>Mensuel</option>
                          <option value={BillingPeriod.ANNUAL}>Annuel</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <textarea rows={2} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={purchasePlan.description} onChange={e => setPurchasePlan({
                    ...purchasePlan,
                    description: e.target.value
                  })} placeholder="Décrivez ce que ce plan offre aux utilisateurs..." />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Prix
                        </label>
                        <input type="number" step="0.01" min="0" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={purchasePlan.price} onChange={e => setPurchasePlan({
                      ...purchasePlan,
                      price: parseFloat(e.target.value) || 0
                    })} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Devise
                        </label>
                        <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={purchasePlan.currency} onChange={e => setPurchasePlan({
                      ...purchasePlan,
                      currency: e.target.value
                    })}>
                          <option value="TND">TND - Dinar Tunisien</option>
                          <option value="EUR">EUR - Euro</option>
                          <option value="USD">USD - Dollar US</option>
                        </select>
                      </div>
                    </div>
                    {/* Features */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Fonctionnalités incluses
                      </label>
                      <div className="space-y-2 mb-3">
                        {purchasePlan.features.map((feature, index) => <div key={index} className="flex items-center justify-between bg-gray-100 px-3 py-2 rounded-lg">
                            <span>{feature}</span>
                            <button type="button" onClick={() => handleRemoveFeature(index)} className="text-red-500 hover:text-red-700">
                              <X className="h-4 w-4" />
                            </button>
                          </div>)}
                      </div>
                      <div className="flex">
                        <input type="text" className="flex-1 px-4 py-2 border border-gray-300 rounded-l-lg focus:ring-blue-500 focus:border-blue-500" value={newFeature} onChange={e => setNewFeature(e.target.value)} placeholder="ex: Support prioritaire, Mises à jour..." onKeyPress={e => e.key === 'Enter' && (e.preventDefault(), handleAddFeature())} />
                        <button type="button" onClick={handleAddFeature} className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700">
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <div>
                      <button type="button" onClick={handleSavePurchasePlan} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                        <Save className="h-4 w-4 mr-2" />
                        Enregistrer le plan
                      </button>
                    </div>
                  </div>
                </div>}
              <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                <Info className="h-5 w-5 text-blue-600 mr-3 flex-shrink-0" />
                <p className="text-sm text-blue-700">
                  {dataset.purchasePlan ? "Votre dataset sera disponible à l'achat selon le plan configuré ci-dessus." : "Si vous ne configurez pas de plan d'achat, votre dataset sera disponible gratuitement."}
                </p>
              </div>
            </div>
            {/* Visibility */}
            <div>
              <div className="flex items-center mb-4">
                {dataset.visibility === Visibility.PUBLIC ? <Globe className="h-5 w-5 text-green-600 mr-2" /> : <Lock className="h-5 w-5 text-red-600 mr-2" />}
                <h2 className="text-xl font-semibold">Visibilité</h2>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <button type="button" className={`p-4 rounded-lg border-2 ${dataset.visibility === Visibility.PUBLIC ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`} onClick={() => setDataset({
                ...dataset,
                visibility: Visibility.PUBLIC
              })}>
                  <div className="font-medium">Public</div>
                  <p className="text-sm text-gray-600 mt-1">
                    Visible par tous les utilisateurs
                  </p>
                </button>
                <button type="button" className={`p-4 rounded-lg border-2 ${dataset.visibility === Visibility.PRIVATE ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`} onClick={() => setDataset({
                ...dataset,
                visibility: Visibility.PRIVATE
              })}>
                  <div className="font-medium">Privé</div>
                  <p className="text-sm text-gray-600 mt-1">
                    Visible uniquement par vous
                  </p>
                </button>
              </div>
            </div>
            {/* Submit Button */}
            <div className="pt-8 border-t border-gray-200">
              <button type="submit" className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 flex items-center justify-center" disabled={isSaving}>
                {isSaving ? <>
                    <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-3"></div>
                    Mise à jour en cours...
                  </> : <>
                    <Save className="h-5 w-5 mr-2" />
                    Mettre à jour le dataset
                  </>}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>;
}