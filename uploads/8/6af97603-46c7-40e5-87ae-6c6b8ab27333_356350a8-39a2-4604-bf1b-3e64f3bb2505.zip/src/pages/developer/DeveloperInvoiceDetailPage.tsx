import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Download, FileText, Calendar, DollarSign, User, CheckCircle } from 'lucide-react';
import { DeveloperDashboardHeader } from '../../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../../components/developer-dashboard/DeveloperDashboardSidebar';
export function DeveloperInvoiceDetailPage() {
  const {
    invoiceId
  } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('payments');
  const [invoice, setInvoice] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    const fetchInvoice = async () => {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 500));
      setInvoice({
        id: invoiceId || 'INV-2024-001',
        date: '2024-05-15',
        period: 'Mai 2024',
        customer: 'Société Tunisienne IA',
        amount: 199.99,
        currency: 'TND',
        status: 'paid',
        items: [{
          description: 'Abonnement ArabicBERT - Plan Standard',
          quantity: 1,
          unitPrice: 199.99,
          total: 199.99
        }]
      });
      setIsLoading(false);
    };
    fetchInvoice();
  }, [invoiceId]);
  if (isLoading || !invoice) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-4xl">
            <button onClick={() => navigate('/developer/payments')} className="flex items-center text-gray-600 hover:text-blue-600 mb-6 transition-colors">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Retour aux paiements
            </button>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} className="bg-white rounded-xl shadow-sm p-8">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    Facture {invoice.id}
                  </h1>
                  <p className="text-gray-600">Période: {invoice.period}</p>
                </div>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                  <Download className="h-4 w-4 mr-2" />
                  Télécharger PDF
                </button>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-8 pb-8 border-b border-gray-200">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Client</p>
                  <p className="font-medium text-gray-900">
                    {invoice.customer}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Date d'émission</p>
                  <p className="font-medium text-gray-900">
                    {new Date(invoice.date).toLocaleDateString('fr-FR')}
                  </p>
                </div>
              </div>

              <table className="w-full mb-8">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">
                      Description
                    </th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">
                      Quantité
                    </th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">
                      Prix unitaire
                    </th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">
                      Total
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items.map((item: any, index: number) => <tr key={index} className="border-b border-gray-200">
                      <td className="px-4 py-4 text-gray-900">
                        {item.description}
                      </td>
                      <td className="px-4 py-4 text-right text-gray-900">
                        {item.quantity}
                      </td>
                      <td className="px-4 py-4 text-right text-gray-900">
                        {item.unitPrice} {invoice.currency}
                      </td>
                      <td className="px-4 py-4 text-right font-medium text-gray-900">
                        {item.total} {invoice.currency}
                      </td>
                    </tr>)}
                </tbody>
              </table>

              <div className="flex justify-end">
                <div className="w-64">
                  <div className="flex justify-between py-2">
                    <span className="text-gray-600">Sous-total</span>
                    <span className="font-medium text-gray-900">
                      {invoice.amount} {invoice.currency}
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-t border-gray-200 font-bold text-lg">
                    <span>Total</span>
                    <span>
                      {invoice.amount} {invoice.currency}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-gray-200">
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span className="font-medium">Facture payée</span>
                </div>
              </div>
            </motion.div>
          </div>
        </main>
      </div>
    </div>;
}