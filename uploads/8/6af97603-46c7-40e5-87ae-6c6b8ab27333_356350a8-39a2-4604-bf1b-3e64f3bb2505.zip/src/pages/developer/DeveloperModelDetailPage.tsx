import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { DeveloperDashboardHeader } from '../../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../../components/developer-dashboard/DeveloperDashboardSidebar';
import { ArrowUpRight, ArrowDownRight, Edit, Trash2, Download, BarChart2, Users, Tag, Globe, Lock, Server, Code, Database, Calendar, HardDrive, Cpu, DollarSign, AlertTriangle, MessageSquare, Star, Share2, GitBranch, CheckCircle, Settings, ExternalLink, Terminal, FileText, User } from 'lucide-react';
enum Visibility {
  PUBLIC = 'PUBLIC',
  PRIVATE = 'PRIVATE',
}
enum BillingPeriod {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
  PAY_AS_YOU_GO = 'PAY_AS_YOU_GO',
}
interface SubscriptionPlan {
  id: number;
  name: string;
  description: string;
  price: number;
  currency: string;
  billingPeriod: BillingPeriod;
  features: string[];
  apiCallsLimit?: number;
  apiCallsPrice?: number;
  subscribersCount: number;
  revenue: number;
}
interface ModelTask {
  id: number;
  name: string;
}
interface ModelEndpoint {
  method: string;
  path: string;
  description: string;
  requestBody: string;
  successResponse: string;
  errorResponse: string;
  callsCount: number;
  avgResponseTime: string;
  errorRate: number;
}
interface ModelVersion {
  version: string;
  releaseDate: string;
  changes: string[];
  isLatest: boolean;
}
interface ModelPerformance {
  accuracy: string;
  f1Score: string;
  precision: string;
  recall: string;
}
interface UsageStats {
  totalCalls: number;
  callsTrend: number;
  uniqueUsers: number;
  usersTrend: number;
  averageResponseTime: string;
  responseTimeTrend: number;
  errorRate: number;
  errorRateTrend: number;
}
interface RevenueStats {
  totalRevenue: number;
  revenueTrend: number;
  subscriptions: number;
  subscriptionsTrend: number;
  averageRevenuePerUser: number;
  arpuTrend: number;
}
interface Model {
  id: number;
  name: string;
  description: string;
  version: string;
  visibility: Visibility;
  status: 'PUBLISHED' | 'DRAFT' | 'UNDER_REVIEW' | 'REJECTED';
  createdAt: string;
  updatedAt: string;
  publishedAt: string;
  tasks: ModelTask[];
  endpoints: ModelEndpoint[];
  performance: ModelPerformance;
  image: string;
  framework: string;
  architecture: string;
  trainingDataset: string;
  subscriptionPlans: SubscriptionPlan[];
  versions: ModelVersion[];
  usage: UsageStats;
  revenue: RevenueStats;
}
export function DeveloperModelDetailPage() {
  const {
    id
  } = useParams<{
    id: string;
  }>();
  const [activeTab, setActiveTab] = useState('models');
  const [model, setModel] = useState<Model | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState<'overview' | 'usage' | 'subscribers' | 'endpoints' | 'versions' | 'settings'>('overview');
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  useEffect(() => {
    const fetchModel = async () => {
      setIsLoading(true);
      try {
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 800));
        // Mock model data
        const mockModel: Model = {
          id: parseInt(id || '1'),
          name: 'ArabicBERT',
          description: "Modèle BERT pré-entraîné pour l'arabe standard et dialectal",
          version: '2.1.0',
          visibility: Visibility.PUBLIC,
          status: 'PUBLISHED',
          createdAt: '2023-09-15',
          updatedAt: '2023-12-01',
          publishedAt: '2023-12-01',
          tasks: [{
            id: 1,
            name: 'Text Classification'
          }, {
            id: 2,
            name: 'Named Entity Recognition'
          }, {
            id: 3,
            name: 'Sentiment Analysis'
          }, {
            id: 4,
            name: 'Question Answering'
          }],
          endpoints: [{
            method: 'POST',
            path: '/api/v1/predict',
            description: 'Endpoint principal pour les prédictions textuelles',
            requestBody: '{\n  "text": "مرحبا بكم في تونس",\n  "options": {\n    "return_probabilities": true\n  }\n}',
            successResponse: '{\n  "prediction": "positive",\n  "probabilities": {\n    "positive": 0.92,\n    "neutral": 0.06,\n    "negative": 0.02\n  },\n  "processing_time": "120ms"\n}',
            errorResponse: '{\n  "error": "Invalid input format",\n  "code": "INPUT_ERROR",\n  "status": 400\n}',
            callsCount: 65432,
            avgResponseTime: '135ms',
            errorRate: 0.8
          }, {
            method: 'GET',
            path: '/api/v1/info',
            description: 'Récupère les informations sur le modèle',
            requestBody: '{}',
            successResponse: '{\n  "model": "ArabicBERT",\n  "version": "2.1.0",\n  "language": "Arabic",\n  "capabilities": ["classification", "ner", "sentiment"]\n}',
            errorResponse: '{\n  "error": "Service unavailable",\n  "code": "SERVICE_ERROR",\n  "status": 503\n}',
            callsCount: 12345,
            avgResponseTime: '42ms',
            errorRate: 0.2
          }],
          performance: {
            accuracy: '94.2%',
            f1Score: '0.923',
            precision: '0.918',
            recall: '0.928'
          },
          image: 'ailabtunisia/arabicbert:v2.1',
          framework: 'PyTorch',
          architecture: 'BERT-base',
          trainingDataset: 'Tunisian Dialect Corpus + Arabic Wikipedia',
          subscriptionPlans: [{
            id: 1,
            name: 'Plan Basique',
            description: 'Pour les projets de recherche et les tests',
            price: 0,
            currency: 'TND',
            billingPeriod: BillingPeriod.MONTHLY,
            features: ["Accès à l'API avec limites", '1000 appels API par mois', 'Support communautaire'],
            apiCallsLimit: 1000,
            subscribersCount: 845,
            revenue: 0
          }, {
            id: 2,
            name: 'Plan Standard',
            description: 'Pour les startups et projets en croissance',
            price: 49.99,
            currency: 'TND',
            billingPeriod: BillingPeriod.MONTHLY,
            features: ["Accès à l'API avec limites étendues", '50 000 appels API par mois', 'Support par email', "Tableaux de bord d'analyse"],
            apiCallsLimit: 50000,
            subscribersCount: 325,
            revenue: 16246.75
          }, {
            id: 3,
            name: 'Plan Pro',
            description: 'Pour les entreprises et projets à grande échelle',
            price: 499.99,
            currency: 'TND',
            billingPeriod: BillingPeriod.ANNUAL,
            features: ["Accès illimité à l'API", 'Support prioritaire', 'SLA garanti', 'Environnement dédié', 'Formation personnalisée'],
            apiCallsLimit: 1000000,
            subscribersCount: 80,
            revenue: 39999.2
          }],
          versions: [{
            version: '2.1.0',
            releaseDate: '2023-12-01',
            changes: ['Amélioration de la performance sur les dialectes tunisiens', 'Optimisation de la vitesse de traitement', 'Correction de bugs mineurs'],
            isLatest: true
          }, {
            version: '2.0.0',
            releaseDate: '2023-10-15',
            changes: ["Refonte complète de l'architecture", 'Support amélioré pour les tâches de NER', 'Ajout du support pour les questions-réponses'],
            isLatest: false
          }, {
            version: '1.5.0',
            releaseDate: '2023-08-20',
            changes: ['Amélioration de la classification de texte', 'Réduction de la taille du modèle de 15%', 'Ajout de nouveaux exemples dans la documentation'],
            isLatest: false
          }],
          usage: {
            totalCalls: 78500,
            callsTrend: 12.5,
            uniqueUsers: 1250,
            usersTrend: 8.3,
            averageResponseTime: '128ms',
            responseTimeTrend: -5.2,
            errorRate: 0.6,
            errorRateTrend: -0.8
          },
          revenue: {
            totalRevenue: 15250.75,
            revenueTrend: 10.2,
            subscriptions: 405,
            subscriptionsTrend: 7.5,
            averageRevenuePerUser: 37.65,
            arpuTrend: 2.8
          }
        };
        setModel(mockModel);
      } catch (err) {
        console.error('Error fetching model:', err);
        setError('Une erreur est survenue lors du chargement des données du modèle');
      } finally {
        setIsLoading(false);
      }
    };
    fetchModel();
  }, [id]);
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  const formatNumber = (num: number): string => {
    return num.toLocaleString('fr-FR');
  };
  const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('fr-FR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  const formatJson = (json: string): string => {
    try {
      return JSON.stringify(JSON.parse(json), null, 2);
    } catch (e) {
      return json;
    }
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  if (error || !model) {
    return <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <AlertTriangle className="h-16 w-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Erreur</h1>
        <p className="text-gray-600 mb-6">
          {error || 'Impossible de charger les données du modèle.'}
        </p>
        <button onClick={() => window.location.reload()} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Réessayer
        </button>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-7xl">
            {/* Header with model name and actions */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <div className="flex items-center">
                  <Link to="/developer/models" className="text-sm text-gray-500 hover:text-blue-600 mr-2">
                    Modèles
                  </Link>
                  <span className="text-gray-500 mx-2">/</span>
                  <h1 className="text-2xl font-bold text-gray-900">
                    {model.name}
                  </h1>
                  {model.visibility === Visibility.PUBLIC ? <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <Globe className="h-3 w-3 mr-1" />
                      Public
                    </span> : <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      <Lock className="h-3 w-3 mr-1" />
                      Privé
                    </span>}
                  {model.status === 'PUBLISHED' ? <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Publié
                    </span> : model.status === 'DRAFT' ? <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      Brouillon
                    </span> : model.status === 'UNDER_REVIEW' ? <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      En revue
                    </span> : <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      Rejeté
                    </span>}
                </div>
                <p className="text-gray-500 mt-1">
                  Version {model.version} • Mis à jour le{' '}
                  {formatDate(model.updatedAt)}
                </p>
              </div>
              <div className="flex gap-3 mt-4 md:mt-0">
                <Link to={`/developer/models/${model.id}/update`} className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                  <Edit className="h-4 w-4 mr-2" />
                  Modifier
                </Link>
                <Link to={`/models/${model.id}`} className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Vue publique
                </Link>
                <button className="inline-flex items-center px-4 py-2 border border-red-300 shadow-sm text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Supprimer
                </button>
              </div>
            </div>
            {/* Tabs */}
            <div className="bg-white rounded-t-xl shadow-sm mb-6">
              <div className="border-b border-gray-200">
                <nav className="flex -mb-px">
                  <button onClick={() => setSelectedTab('overview')} className={`py-4 px-6 text-sm font-medium ${selectedTab === 'overview' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    Vue d'ensemble
                  </button>
                  <button onClick={() => setSelectedTab('usage')} className={`py-4 px-6 text-sm font-medium ${selectedTab === 'usage' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    Utilisation
                  </button>
                  <button onClick={() => setSelectedTab('subscribers')} className={`py-4 px-6 text-sm font-medium ${selectedTab === 'subscribers' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    Abonnés
                  </button>
                  <button onClick={() => setSelectedTab('endpoints')} className={`py-4 px-6 text-sm font-medium ${selectedTab === 'endpoints' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    Endpoints
                  </button>
                  <button onClick={() => setSelectedTab('versions')} className={`py-4 px-6 text-sm font-medium ${selectedTab === 'versions' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    Versions
                  </button>
                  <button onClick={() => setSelectedTab('settings')} className={`py-4 px-6 text-sm font-medium ${selectedTab === 'settings' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    Paramètres
                  </button>
                </nav>
              </div>
            </div>
            {/* Tab Content */}
            {selectedTab === 'overview' && <div className="space-y-6">
                {/* Key metrics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <div className="flex items-center">
                      <div className="p-3 rounded-full bg-blue-100 mr-4">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Utilisateurs</p>
                        <div className="flex items-center">
                          <p className="text-2xl font-bold text-gray-900">
                            {formatNumber(model.usage.uniqueUsers)}
                          </p>
                          <div className="flex items-center ml-2">
                            {model.usage.usersTrend > 0 ? <div className="flex items-center text-green-600">
                                <ArrowUpRight className="h-4 w-4" />
                                <span className="text-xs">
                                  +{model.usage.usersTrend}%
                                </span>
                              </div> : <div className="flex items-center text-red-600">
                                <ArrowDownRight className="h-4 w-4" />
                                <span className="text-xs">
                                  {model.usage.usersTrend}%
                                </span>
                              </div>}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <div className="flex items-center">
                      <div className="p-3 rounded-full bg-green-100 mr-4">
                        <Server className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Appels API</p>
                        <div className="flex items-center">
                          <p className="text-2xl font-bold text-gray-900">
                            {formatNumber(model.usage.totalCalls)}
                          </p>
                          <div className="flex items-center ml-2">
                            {model.usage.callsTrend > 0 ? <div className="flex items-center text-green-600">
                                <ArrowUpRight className="h-4 w-4" />
                                <span className="text-xs">
                                  +{model.usage.callsTrend}%
                                </span>
                              </div> : <div className="flex items-center text-red-600">
                                <ArrowDownRight className="h-4 w-4" />
                                <span className="text-xs">
                                  {model.usage.callsTrend}%
                                </span>
                              </div>}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <div className="flex items-center">
                      <div className="p-3 rounded-full bg-purple-100 mr-4">
                        <DollarSign className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Revenus</p>
                        <div className="flex items-center">
                          <p className="text-2xl font-bold text-gray-900">
                            {formatCurrency(model.revenue.totalRevenue)} TND
                          </p>
                          <div className="flex items-center ml-2">
                            {model.revenue.revenueTrend > 0 ? <div className="flex items-center text-green-600">
                                <ArrowUpRight className="h-4 w-4" />
                                <span className="text-xs">
                                  +{model.revenue.revenueTrend}%
                                </span>
                              </div> : <div className="flex items-center text-red-600">
                                <ArrowDownRight className="h-4 w-4" />
                                <span className="text-xs">
                                  {model.revenue.revenueTrend}%
                                </span>
                              </div>}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <div className="flex items-center">
                      <div className="p-3 rounded-full bg-yellow-100 mr-4">
                        <User className="h-6 w-6 text-yellow-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Abonnements</p>
                        <div className="flex items-center">
                          <p className="text-2xl font-bold text-gray-900">
                            {formatNumber(model.revenue.subscriptions)}
                          </p>
                          <div className="flex items-center ml-2">
                            {model.revenue.subscriptionsTrend > 0 ? <div className="flex items-center text-green-600">
                                <ArrowUpRight className="h-4 w-4" />
                                <span className="text-xs">
                                  +{model.revenue.subscriptionsTrend}%
                                </span>
                              </div> : <div className="flex items-center text-red-600">
                                <ArrowDownRight className="h-4 w-4" />
                                <span className="text-xs">
                                  {model.revenue.subscriptionsTrend}%
                                </span>
                              </div>}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Model description and metadata */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6">
                    <h2 className="text-lg font-semibold mb-4">Description</h2>
                    <p className="text-gray-700 mb-6">{model.description}</p>
                    <h3 className="text-md font-semibold mb-3">Tâches</h3>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {model.tasks.map(task => <span key={task.id} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                          <Tag className="h-3 w-3 mr-2" />
                          {task.name}
                        </span>)}
                    </div>
                    <h3 className="text-md font-semibold mb-3">Performance</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">
                          Accuracy
                        </div>
                        <div className="text-xl font-bold text-gray-900">
                          {model.performance.accuracy}
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">
                          Precision
                        </div>
                        <div className="text-xl font-bold text-gray-900">
                          {model.performance.precision}
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Recall</div>
                        <div className="text-xl font-bold text-gray-900">
                          {model.performance.recall}
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">
                          F1 Score
                        </div>
                        <div className="text-xl font-bold text-gray-900">
                          {model.performance.f1Score}
                        </div>
                      </div>
                    </div>
                    <h3 className="text-md font-semibold mb-3">
                      Statistiques d'utilisation
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">
                          Temps de réponse moyen
                        </div>
                        <div className="text-xl font-bold text-gray-900">
                          {model.usage.averageResponseTime}
                        </div>
                        <div className="flex items-center mt-1">
                          {model.usage.responseTimeTrend < 0 ? <div className="flex items-center text-green-600 text-xs">
                              <ArrowDownRight className="h-3 w-3 mr-1" />
                              <span>
                                {Math.abs(model.usage.responseTimeTrend)}% plus
                                rapide
                              </span>
                            </div> : <div className="flex items-center text-red-600 text-xs">
                              <ArrowUpRight className="h-3 w-3 mr-1" />
                              <span>
                                {model.usage.responseTimeTrend}% plus lent
                              </span>
                            </div>}
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">
                          Taux d'erreur
                        </div>
                        <div className="text-xl font-bold text-gray-900">
                          {model.usage.errorRate}%
                        </div>
                        <div className="flex items-center mt-1">
                          {model.usage.errorRateTrend < 0 ? <div className="flex items-center text-green-600 text-xs">
                              <ArrowDownRight className="h-3 w-3 mr-1" />
                              <span>
                                {Math.abs(model.usage.errorRateTrend)}%
                                d'amélioration
                              </span>
                            </div> : <div className="flex items-center text-red-600 text-xs">
                              <ArrowUpRight className="h-3 w-3 mr-1" />
                              <span>
                                {model.usage.errorRateTrend}% de dégradation
                              </span>
                            </div>}
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">
                          Revenu moyen par utilisateur
                        </div>
                        <div className="text-xl font-bold text-gray-900">
                          {formatCurrency(model.revenue.averageRevenuePerUser)}{' '}
                          TND
                        </div>
                        <div className="flex items-center mt-1">
                          {model.revenue.arpuTrend > 0 ? <div className="flex items-center text-green-600 text-xs">
                              <ArrowUpRight className="h-3 w-3 mr-1" />
                              <span>
                                +{model.revenue.arpuTrend}% d'augmentation
                              </span>
                            </div> : <div className="flex items-center text-red-600 text-xs">
                              <ArrowDownRight className="h-3 w-3 mr-1" />
                              <span>
                                {model.revenue.arpuTrend}% de diminution
                              </span>
                            </div>}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <h2 className="text-lg font-semibold mb-4">Métadonnées</h2>
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <Code className="h-5 w-5 text-gray-400 mr-3" />
                        <div>
                          <span className="text-sm text-gray-500">
                            Framework
                          </span>
                          <p className="font-medium text-gray-900">
                            {model.framework}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Cpu className="h-5 w-5 text-gray-400 mr-3" />
                        <div>
                          <span className="text-sm text-gray-500">
                            Architecture
                          </span>
                          <p className="font-medium text-gray-900">
                            {model.architecture}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Database className="h-5 w-5 text-gray-400 mr-3" />
                        <div>
                          <span className="text-sm text-gray-500">
                            Dataset d'entraînement
                          </span>
                          <p className="font-medium text-gray-900">
                            {model.trainingDataset}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Terminal className="h-5 w-5 text-gray-400 mr-3" />
                        <div>
                          <span className="text-sm text-gray-500">
                            Image Docker
                          </span>
                          <p className="font-medium text-gray-900">
                            {model.image}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                        <div>
                          <span className="text-sm text-gray-500">
                            Date de création
                          </span>
                          <p className="font-medium text-gray-900">
                            {formatDate(model.createdAt)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                        <div>
                          <span className="text-sm text-gray-500">
                            Date de publication
                          </span>
                          <p className="font-medium text-gray-900">
                            {formatDate(model.publishedAt)}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <h3 className="text-md font-semibold mb-3">
                        Actions rapides
                      </h3>
                      <div className="space-y-2">
                        <Link to={`/developer/models/${model.id}/analytics`} className="flex items-center p-2 text-blue-600 hover:bg-blue-50 rounded-md">
                          <BarChart2 className="h-5 w-5 mr-2" />
                          <span>Voir les analyses détaillées</span>
                        </Link>
                        <Link to={`/developer/models/${model.id}/documentation`} className="flex items-center p-2 text-blue-600 hover:bg-blue-50 rounded-md">
                          <FileText className="h-5 w-5 mr-2" />
                          <span>Gérer la documentation</span>
                        </Link>
                        <Link to={`/developer/models/${model.id}/update`} className="flex items-center p-2 text-blue-600 hover:bg-blue-50 rounded-md">
                          <Edit className="h-5 w-5 mr-2" />
                          <span>Mettre à jour le modèle</span>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Subscription Plans */}
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4">
                    Plans d'abonnement
                  </h2>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Plan
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Prix
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Facturation
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Abonnés
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Revenus
                          </th>
                          <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {model.subscriptionPlans.map(plan => <tr key={plan.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="text-sm font-medium text-gray-900">
                                  {plan.name}
                                </div>
                              </div>
                              <div className="text-sm text-gray-500">
                                {plan.description}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {plan.billingPeriod === BillingPeriod.PAY_AS_YOU_GO ? <div className="text-sm text-gray-900">
                                  {plan.apiCallsPrice} {plan.currency} / appel
                                </div> : <div className="text-sm text-gray-900">
                                  {formatCurrency(plan.price)} {plan.currency}
                                </div>}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">
                                {plan.billingPeriod === BillingPeriod.MONTHLY ? 'Mensuelle' : plan.billingPeriod === BillingPeriod.ANNUAL ? 'Annuelle' : 'Pay-as-you-go'}
                              </div>
                              {plan.apiCallsLimit && <div className="text-sm text-gray-500">
                                  {formatNumber(plan.apiCallsLimit)} appels API
                                </div>}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatNumber(plan.subscribersCount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatCurrency(plan.revenue)} {plan.currency}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <Link to={`/developer/models/${model.id}/plans/${plan.id}/edit`} className="text-blue-600 hover:text-blue-900">
                                Modifier
                              </Link>
                            </td>
                          </tr>)}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>}
            {selectedTab === 'usage' && <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold mb-4">
                  Statistiques d'utilisation
                </h2>
                <div className="mb-6 flex justify-end">
                  <div className="flex items-center bg-white rounded-md border border-gray-200 shadow-sm">
                    <button className={`px-3 py-1.5 text-sm rounded-md ${timeRange === '7d' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setTimeRange('7d')}>
                      7 jours
                    </button>
                    <button className={`px-3 py-1.5 text-sm rounded-md ${timeRange === '30d' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setTimeRange('30d')}>
                      30 jours
                    </button>
                    <button className={`px-3 py-1.5 text-sm rounded-md ${timeRange === '90d' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setTimeRange('90d')}>
                      90 jours
                    </button>
                    <button className={`px-3 py-1.5 text-sm rounded-md ${timeRange === 'all' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setTimeRange('all')}>
                      Tout
                    </button>
                  </div>
                </div>
                <div className="h-64 bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
                  <p className="text-gray-500">
                    Graphique d'utilisation (simulé)
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">
                      Appels API par jour
                    </h3>
                    <p className="text-2xl font-bold text-gray-900">
                      {formatNumber(Math.round(model.usage.totalCalls / 30))}
                    </p>
                    <div className="flex items-center mt-1">
                      {model.usage.callsTrend > 0 ? <div className="flex items-center text-green-600 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          <span>
                            +{model.usage.callsTrend}% vs période précédente
                          </span>
                        </div> : <div className="flex items-center text-red-600 text-xs">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          <span>
                            {model.usage.callsTrend}% vs période précédente
                          </span>
                        </div>}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">
                      Utilisateurs actifs
                    </h3>
                    <p className="text-2xl font-bold text-gray-900">
                      {formatNumber(model.usage.uniqueUsers)}
                    </p>
                    <div className="flex items-center mt-1">
                      {model.usage.usersTrend > 0 ? <div className="flex items-center text-green-600 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          <span>
                            +{model.usage.usersTrend}% vs période précédente
                          </span>
                        </div> : <div className="flex items-center text-red-600 text-xs">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          <span>
                            {model.usage.usersTrend}% vs période précédente
                          </span>
                        </div>}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">
                      Taux d'erreur
                    </h3>
                    <p className="text-2xl font-bold text-gray-900">
                      {model.usage.errorRate}%
                    </p>
                    <div className="flex items-center mt-1">
                      {model.usage.errorRateTrend < 0 ? <div className="flex items-center text-green-600 text-xs">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          <span>
                            {Math.abs(model.usage.errorRateTrend)}%
                            d'amélioration
                          </span>
                        </div> : <div className="flex items-center text-red-600 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          <span>
                            +{model.usage.errorRateTrend}% de dégradation
                          </span>
                        </div>}
                    </div>
                  </div>
                </div>
                <h3 className="text-md font-semibold mb-3">
                  Utilisation par endpoint
                </h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Endpoint
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Appels
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Temps de réponse
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Taux d'erreur
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {model.endpoints.map((endpoint, index) => <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <span className={`px-2 py-1 text-xs font-medium rounded mr-2 ${endpoint.method === 'GET' ? 'bg-green-100 text-green-800' : endpoint.method === 'POST' ? 'bg-blue-100 text-blue-800' : endpoint.method === 'PUT' ? 'bg-yellow-100 text-yellow-800' : endpoint.method === 'DELETE' ? 'bg-red-100 text-red-800' : 'bg-purple-100 text-purple-800'}`}>
                                {endpoint.method}
                              </span>
                              <span className="font-medium text-gray-900">
                                {endpoint.path}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatNumber(endpoint.callsCount)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {endpoint.avgResponseTime}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {endpoint.errorRate}%
                          </td>
                        </tr>)}
                    </tbody>
                  </table>
                </div>
              </div>}
            {selectedTab === 'subscribers' && <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold mb-4">Abonnés</h2>
                <div className="h-64 bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
                  <p className="text-gray-500">Tableau des abonnés (simulé)</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  {model.subscriptionPlans.map(plan => <div key={plan.id} className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="text-sm font-medium text-gray-700 mb-2">
                        {plan.name}
                      </h3>
                      <p className="text-2xl font-bold text-gray-900">
                        {formatNumber(plan.subscribersCount)}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">
                        {formatCurrency(plan.revenue)} {plan.currency} de
                        revenus
                      </p>
                    </div>)}
                </div>
              </div>}
            {selectedTab === 'endpoints' && <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold mb-4">Endpoints API</h2>
                <div className="space-y-6">
                  {model.endpoints.map((endpoint, index) => <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center">
                          <span className={`px-2 py-1 text-xs font-medium rounded mr-2 ${endpoint.method === 'GET' ? 'bg-green-100 text-green-800' : endpoint.method === 'POST' ? 'bg-blue-100 text-blue-800' : endpoint.method === 'PUT' ? 'bg-yellow-100 text-yellow-800' : endpoint.method === 'DELETE' ? 'bg-red-100 text-red-800' : 'bg-purple-100 text-purple-800'}`}>
                            {endpoint.method}
                          </span>
                          <span className="font-medium text-blue-600">
                            {endpoint.path}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button className="text-gray-500 hover:text-blue-600">
                            <Edit className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                      {endpoint.description && <div className="mb-3 text-sm text-gray-600">
                          {endpoint.description}
                        </div>}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-xs font-medium text-gray-500 mb-1">
                            APPELS TOTAUX
                          </div>
                          <div className="text-lg font-bold text-gray-900">
                            {formatNumber(endpoint.callsCount)}
                          </div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-xs font-medium text-gray-500 mb-1">
                            TEMPS DE RÉPONSE
                          </div>
                          <div className="text-lg font-bold text-gray-900">
                            {endpoint.avgResponseTime}
                          </div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-xs font-medium text-gray-500 mb-1">
                            TAUX D'ERREUR
                          </div>
                          <div className="text-lg font-bold text-gray-900">
                            {endpoint.errorRate}%
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {endpoint.requestBody && endpoint.requestBody !== '{}' && <div className="bg-gray-50 p-3 rounded-lg">
                              <h4 className="text-xs font-semibold text-gray-500 mb-2">
                                REQUÊTE
                              </h4>
                              <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                                {formatJson(endpoint.requestBody)}
                              </pre>
                            </div>}
                        {endpoint.successResponse && endpoint.successResponse !== '{}' && <div className="bg-green-50 p-3 rounded-lg">
                              <h4 className="text-xs font-semibold text-green-600 mb-2">
                                SUCCÈS
                              </h4>
                              <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                                {formatJson(endpoint.successResponse)}
                              </pre>
                            </div>}
                        {endpoint.errorResponse && endpoint.errorResponse !== '{}' && <div className="bg-red-50 p-3 rounded-lg">
                              <h4 className="text-xs font-semibold text-red-600 mb-2">
                                ERREUR
                              </h4>
                              <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                                {formatJson(endpoint.errorResponse)}
                              </pre>
                            </div>}
                      </div>
                    </div>)}
                </div>
              </div>}
            {selectedTab === 'versions' && <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold mb-4">
                  Historique des versions
                </h2>
                <div className="flow-root">
                  <ul className="-mb-8">
                    {model.versions.map((version, versionIdx) => <li key={version.version}>
                        <div className="relative pb-8">
                          {versionIdx !== model.versions.length - 1 ? <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true" /> : null}
                          <div className="relative flex items-start space-x-3">
                            <div className="relative">
                              <div className={`h-10 w-10 rounded-full flex items-center justify-center ${version.isLatest ? 'bg-blue-100' : 'bg-gray-100'}`}>
                                <Code className={`h-5 w-5 ${version.isLatest ? 'text-blue-600' : 'text-gray-500'}`} />
                              </div>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div>
                                <div className="text-sm">
                                  <span className="font-medium text-gray-900">
                                    Version {version.version}
                                  </span>
                                  {version.isLatest && <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                      Actuelle
                                    </span>}
                                </div>
                                <p className="mt-0.5 text-sm text-gray-500">
                                  Publié le {formatDate(version.releaseDate)}
                                </p>
                              </div>
                              <div className="mt-2 text-sm text-gray-700">
                                <ul className="list-disc pl-5 space-y-1">
                                  {version.changes.map((change, changeIdx) => <li key={changeIdx}>{change}</li>)}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>)}
                  </ul>
                </div>
              </div>}
            {selectedTab === 'settings' && <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold mb-4">
                  Paramètres du modèle
                </h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-md font-medium mb-3">Visibilité</h3>
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <input id="visibility-public" name="visibility" type="radio" className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked={model.visibility === Visibility.PUBLIC} />
                        <label htmlFor="visibility-public" className="ml-2 block text-sm text-gray-700">
                          Public
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input id="visibility-private" name="visibility" type="radio" className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked={model.visibility === Visibility.PRIVATE} />
                        <label htmlFor="visibility-private" className="ml-2 block text-sm text-gray-700">
                          Privé
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="pt-6 border-t border-gray-200">
                    <h3 className="text-md font-medium mb-3">
                      Paramètres avancés
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <div className="flex items-center h-5">
                          <input id="versioning" name="versioning" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked />
                        </div>
                        <div className="ml-3 text-sm">
                          <label htmlFor="versioning" className="font-medium text-gray-700">
                            Activer le versionnement
                          </label>
                          <p className="text-gray-500">
                            Conserve l'historique des versions du modèle.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="flex items-center h-5">
                          <input id="metrics" name="metrics" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked />
                        </div>
                        <div className="ml-3 text-sm">
                          <label htmlFor="metrics" className="font-medium text-gray-700">
                            Collecter les métriques d'utilisation
                          </label>
                          <p className="text-gray-500">
                            Collecte des données sur l'utilisation, les
                            performances et les erreurs.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="flex items-center h-5">
                          <input id="caching" name="caching" type="checkbox" className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked />
                        </div>
                        <div className="ml-3 text-sm">
                          <label htmlFor="caching" className="font-medium text-gray-700">
                            Activer le cache des requêtes
                          </label>
                          <p className="text-gray-500">
                            Améliore les performances en mettant en cache les
                            résultats des requêtes fréquentes.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="pt-6 border-t border-gray-200">
                    <h3 className="text-md font-medium mb-3 text-red-600">
                      Zone de danger
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <button className="px-4 py-2 border border-red-300 rounded-md text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                          Désactiver temporairement le modèle
                        </button>
                        <p className="mt-1 text-sm text-gray-500">
                          Le modèle ne sera plus accessible via l'API, mais
                          toutes les données seront conservées.
                        </p>
                      </div>
                      <div>
                        <button className="px-4 py-2 bg-red-600 border border-transparent rounded-md text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                          Supprimer définitivement le modèle
                        </button>
                        <p className="mt-1 text-sm text-gray-500">
                          Cette action est irréversible. Toutes les données
                          associées à ce modèle seront supprimées.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>}
          </div>
        </main>
      </div>
    </div>;
}