import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Book, DollarSign, CreditCard, FileText, HelpCircle, ChevronRight, Code, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { DeveloperDashboardHeader } from '../../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../../components/developer-dashboard/DeveloperDashboardSidebar';
export function DeveloperPaymentDocsPage() {
  const [activeTab, setActiveTab] = useState('documentation');
  const [selectedSection, setSelectedSection] = useState('overview');
  const sections = [{
    id: 'overview',
    title: "Vue d'ensemble",
    icon: Book
  }, {
    id: 'payouts',
    title: 'Versements',
    icon: DollarSign
  }, {
    id: 'methods',
    title: 'Méthodes de paiement',
    icon: CreditCard
  }, {
    id: 'invoices',
    title: 'Factures',
    icon: FileText
  }, {
    id: 'faq',
    title: 'FAQ',
    icon: HelpCircle
  }];
  const renderContent = () => {
    switch (selectedSection) {
      case 'overview':
        return <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Documentation des paiements
              </h2>
              <p className="text-gray-600 mb-4">
                Bienvenue dans la documentation complète du système de paiements
                pour développeurs AI+. Cette documentation vous guidera à
                travers tous les aspects de la gestion de vos revenus.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="font-semibold text-blue-900 mb-2">
                Comment ça marche ?
              </h3>
              <ol className="list-decimal list-inside space-y-2 text-blue-800">
                <li>
                  Vos modèles et datasets génèrent des revenus via les
                  abonnements et achats
                </li>
                <li>Les revenus s'accumulent dans votre solde disponible</li>
                <li>
                  Vous pouvez demander un versement dès que le seuil minimum
                  (500 TND) est atteint
                </li>
                <li>Les versements sont traités sous 7 jours ouvrables</li>
              </ol>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <CheckCircle className="h-8 w-8 text-green-500 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">
                  Seuil minimum
                </h4>
                <p className="text-sm text-gray-600">
                  500 TND de solde minimum pour demander un versement
                </p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <Clock className="h-8 w-8 text-blue-500 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">
                  Délai de traitement
                </h4>
                <p className="text-sm text-gray-600">
                  7 jours ouvrables maximum pour recevoir votre versement
                </p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <DollarSign className="h-8 w-8 text-purple-500 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">
                  Frais de service
                </h4>
                <p className="text-sm text-gray-600">
                  1.5% de frais avec un minimum de 5 TND par versement
                </p>
              </div>
            </div>
          </div>;
      case 'payouts':
        return <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Versements
            </h2>

            <div className="prose max-w-none">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Comment demander un versement
              </h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-700">
                <li>Accédez à la page Paiements</li>
                <li>Vérifiez que votre solde atteint le minimum de 500 TND</li>
                <li>Cliquez sur "Demander un versement"</li>
                <li>Sélectionnez votre méthode de paiement</li>
                <li>Confirmez le montant et validez</li>
              </ol>

              <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">
                Versements automatiques
              </h3>
              <p className="text-gray-700 mb-4">
                Vous pouvez activer les versements automatiques mensuels.
                Lorsque activés, vos revenus seront automatiquement versés le 15
                de chaque mois si le seuil minimum est atteint.
              </p>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 my-4">
                <div className="flex">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mr-3 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-medium mb-1">Important</p>
                    <p>
                      Assurez-vous que vos informations de paiement sont à jour
                      avant de demander un versement.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>;
      case 'methods':
        return <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Méthodes de paiement
            </h2>

            <div className="space-y-4">
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <div className="flex items-start">
                  <CreditCard className="h-6 w-6 text-blue-600 mr-4 mt-1" />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Compte bancaire
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Recevez vos versements directement sur votre compte
                      bancaire tunisien.
                    </p>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Informations requises :
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-700 text-sm">
                      <li>Nom du titulaire du compte</li>
                      <li>Nom de la banque</li>
                      <li>Numéro de compte</li>
                      <li>IBAN</li>
                      <li>Code SWIFT/BIC (optionnel)</li>
                      <li>Adresse complète</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <div className="flex items-start">
                  <DollarSign className="h-6 w-6 text-purple-600 mr-4 mt-1" />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      PayPal
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Recevez vos versements sur votre compte PayPal vérifié.
                    </p>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Informations requises :
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-700 text-sm">
                      <li>Email PayPal vérifié</li>
                      <li>
                        Compte capable de recevoir des paiements commerciaux
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>;
      case 'invoices':
        return <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Factures</h2>

            <p className="text-gray-600 mb-4">
              Chaque transaction génère automatiquement une facture détaillée
              que vous pouvez télécharger et utiliser pour votre comptabilité.
            </p>

            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Contenu des factures
              </h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Numéro de facture unique</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Date d'émission et période couverte</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>
                    Détail des transactions (abonnements, achats, API)
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Montants bruts et nets</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Frais de plateforme détaillés</span>
                </li>
              </ul>
            </div>
          </div>;
      case 'faq':
        return <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Questions fréquentes
            </h2>

            <div className="space-y-4">
              {[{
              q: 'Quel est le délai de traitement des versements ?',
              a: 'Les versements sont traités sous 7 jours ouvrables maximum après votre demande.'
            }, {
              q: 'Puis-je modifier ma méthode de paiement ?',
              a: 'Oui, vous pouvez ajouter, modifier ou supprimer vos méthodes de paiement à tout moment depuis la page Paiements.'
            }, {
              q: 'Y a-t-il des frais sur les versements ?',
              a: "Oui, des frais de service de 1.5% s'appliquent avec un minimum de 5 TND par versement."
            }, {
              q: 'Que se passe-t-il si mon versement échoue ?',
              a: "En cas d'échec, vous serez notifié par email et le montant sera remis dans votre solde disponible. Vérifiez vos informations de paiement et réessayez."
            }, {
              q: 'Puis-je annuler un versement en cours ?',
              a: "Non, une fois qu'un versement est en cours de traitement, il ne peut plus être annulé. Assurez-vous de vérifier toutes les informations avant de confirmer."
            }].map((faq, index) => <div key={index} className="bg-white border border-gray-200 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">{faq.q}</h3>
                  <p className="text-gray-600">{faq.a}</p>
                </div>)}
            </div>
          </div>;
      default:
        return null;
    }
  };
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-7xl">
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-900 mb-2 flex items-center">
                <Book className="h-6 w-6 text-blue-600 mr-2" />
                Documentation des paiements
              </h1>
              <p className="text-gray-600">
                Guide complet pour gérer vos revenus et versements
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Sidebar Navigation */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-xl shadow-sm p-4 sticky top-6">
                  <nav className="space-y-1">
                    {sections.map(section => {
                    const Icon = section.icon;
                    return <button key={section.id} onClick={() => setSelectedSection(section.id)} className={`w-full flex items-center px-4 py-3 rounded-lg text-left transition-colors ${selectedSection === section.id ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>
                          <Icon className="h-5 w-5 mr-3" />
                          <span className="font-medium">{section.title}</span>
                          {selectedSection === section.id && <ChevronRight className="h-4 w-4 ml-auto" />}
                        </button>;
                  })}
                  </nav>
                </div>
              </div>

              {/* Content */}
              <div className="lg:col-span-3">
                <motion.div key={selectedSection} initial={{
                opacity: 0,
                y: 20
              }} animate={{
                opacity: 1,
                y: 0
              }} transition={{
                duration: 0.3
              }} className="bg-white rounded-xl shadow-sm p-8">
                  {renderContent()}
                </motion.div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>;
}