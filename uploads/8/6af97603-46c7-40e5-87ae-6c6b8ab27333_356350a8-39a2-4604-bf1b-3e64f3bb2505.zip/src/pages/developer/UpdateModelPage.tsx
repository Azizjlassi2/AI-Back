import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, AlertCircle, Check, Bot, Globe, Lock, Info, Zap, BarChart2, Code, Server, CreditCard, Plus, X, FileText, Tag, List, Cpu } from 'lucide-react';
import { DeveloperDashboardHeader } from '../../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../../components/developer-dashboard/DeveloperDashboardSidebar';
enum Visibility {
  PUBLIC = 'PUBLIC',
  PRIVATE = 'PRIVATE',
}
enum BillingPeriod {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
}
interface ApiEndpoint {
  id: number;
  path: string;
  endpoint: string;
  description: string;
  successResponse: string;
  errorResponse: string;
  method: string;
  requestBody: string;
}
interface ModelTask {
  id: number;
  name: string;
  description: string;
}
interface PricingTier {
  id: number;
  name: string;
  price: number;
  currency: string;
  billingPeriod: BillingPeriod;
  description: string;
  apiCallsLimit: number | null;
  apiCallsPrice: number | null;
  features: string[];
}
interface TechnicalDetail {
  architecture: string;
  parameters: string;
  trainingData: string;
  framework: string;
  inputFormat: string;
  outputFormat: string;
  requirements: string;
  inferenceTime: string;
  modelSize: string;
}
interface PerformanceMetric {
  metric: string;
  value: string;
  dataset: string;
  description: string;
}
interface PricingPlan {
  free: boolean;
  freeTier: {
    requestsPerMonth: number;
    features: string[];
  };
  paidTiers: PricingTier[];
}
interface Model {
  id: number;
  name: string;
  description: string;
  version: string;
  visibility: Visibility;
  status: 'PUBLISHED' | 'DRAFT' | 'UNDER_REVIEW' | 'REJECTED';
  tags: string[];
  languages: string[];
  documentation: string;
  apiEndpoints: ApiEndpoint[];
  tasks: ModelTask[];
  technicalDetails: TechnicalDetail;
  performanceMetrics: PerformanceMetric[];
  pricingPlan: PricingPlan;
}
export function UpdateModelPage() {
  const {
    modelId
  } = useParams<{
    modelId: string;
  }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('models');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);
  const [model, setModel] = useState<Model | null>(null);
  const [formData, setFormData] = useState<Partial<Model>>({});
  const [newTag, setNewTag] = useState('');
  const [newLanguage, setNewLanguage] = useState('');
  const [activeSection, setActiveSection] = useState('basic');
  const [newEndpoint, setNewEndpoint] = useState<ApiEndpoint>({
    id: Date.now(),
    path: '',
    endpoint: '',
    description: '',
    successResponse: '',
    errorResponse: '',
    method: 'GET',
    requestBody: ''
  });
  const [newParameter, setNewParameter] = useState({
    name: '',
    type: 'string',
    required: false,
    description: ''
  });
  const [newTask, setNewTask] = useState<ModelTask>({
    id: Date.now(),
    name: '',
    description: ''
  });
  const [newPricingTier, setNewPricingTier] = useState<PricingTier>({
    id: Date.now(),
    name: '',
    price: 0,
    currency: 'TND',
    billingPeriod: BillingPeriod.MONTHLY,
    description: '',
    apiCallsLimit: null,
    apiCallsPrice: null,
    features: []
  });
  const [newFeature, setNewFeature] = useState('');
  const [newPerformanceMetric, setNewPerformanceMetric] = useState<PerformanceMetric>({
    metric: '',
    value: '',
    dataset: '',
    description: ''
  });
  useEffect(() => {
    const fetchModel = async () => {
      setIsLoading(true);
      try {
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 800));
        // Mock data for a single model
        const mockModel: Model = {
          id: parseInt(modelId || '1'),
          name: 'ArabicBERT',
          description: "Modèle BERT pré-entraîné pour l'arabe standard et dialectal tunisien, optimisé pour les tâches de classification de texte et d'analyse de sentiment.",
          version: '2.1.0',
          visibility: Visibility.PUBLIC,
          status: 'PUBLISHED',
          tags: ['NLP', 'Text Classification', 'Sentiment Analysis', 'Arabic'],
          languages: ['Modern Standard Arabic', 'Tunisian Dialect'],
          documentation: "## Introduction\n\nArabicBERT est un modèle de langage pré-entraîné pour l'arabe standard moderne et le dialecte tunisien.\n\n## Utilisation\n\n```python\nfrom transformers import AutoModel, AutoTokenizer\n\ntokenizer = AutoTokenizer.from_pretrained('ai-lab-tunisia/arabicbert')\nmodel = AutoModel.from_pretrained('ai-lab-tunisia/arabicbert')\n",
          apiEndpoints: [{
            id: 1,
            path: 'sentiment',
            endpoint: 'https://api.ai-tunisia.com/v1/models/arabicbert/sentiment',
            description: "Analyse le sentiment d'un texte en arabe",
            successResponse: '{"sentiment": "positive", "score": 0.92}',
            errorResponse: '{"error": "Invalid input", "code": 400}',
            method: 'POST',
            requestBody: '{"text": "Exemple de texte à analyser"}'
          }, {
            id: 2,
            path: 'classify',
            endpoint: 'https://api.ai-tunisia.com/v1/models/arabicbert/classify',
            description: 'Classifie un texte en arabe selon des catégories prédéfinies',
            successResponse: '{"category": "news", "confidence": 0.85}',
            errorResponse: '{"error": "Invalid input", "code": 400}',
            method: 'POST',
            requestBody: '{"text": "Exemple de texte à classifier", "categories": ["news", "sports", "technology"]}'
          }],
          tasks: [{
            id: 1,
            name: 'Analyse de sentiment',
            description: 'Détermine si un texte exprime un sentiment positif, négatif ou neutre'
          }, {
            id: 2,
            name: 'Classification de texte',
            description: 'Catégorise un texte selon des thèmes prédéfinis'
          }, {
            id: 3,
            name: "Reconnaissance d'entités nommées",
            description: 'Identifie les personnes, lieux, organisations et autres entités dans un texte'
          }],
          technicalDetails: {
            architecture: 'BERT (Bidirectional Encoder Representations from Transformers)',
            parameters: '110M',
            trainingData: '30GB de textes en arabe standard et dialectal tunisien',
            framework: 'PyTorch / Transformers',
            inputFormat: 'Texte brut ou tokens encodés',
            outputFormat: 'Embeddings contextuels, logits pour classification',
            requirements: "GPU recommandé pour l'inférence rapide",
            inferenceTime: '~50ms par requête sur GPU T4',
            modelSize: '440MB'
          },
          performanceMetrics: [{
            metric: 'Précision (Classification)',
            value: '92.5%',
            dataset: 'TuniBERT Benchmark',
            description: 'Précision sur tâches de classification binaire'
          }, {
            metric: 'F1-Score (NER)',
            value: '88.3%',
            dataset: 'ANER Corpus',
            description: "Score F1 pour la reconnaissance d'entités nommées"
          }, {
            metric: 'BLEU Score',
            value: '36.2',
            dataset: 'Arabic MT Dataset',
            description: 'Score BLEU pour la traduction automatique'
          }],
          pricingPlan: {
            free: true,
            freeTier: {
              requestsPerMonth: 1000,
              features: ['Accès API de base', 'Taux de requêtes limité', 'Support communautaire']
            },
            paidTiers: [{
              id: 1,
              name: 'Standard',
              price: 99.99,
              currency: 'TND',
              billingPeriod: BillingPeriod.MONTHLY,
              requestsPerMonth: 10000,
              features: ['Accès API complet', 'Taux de requêtes élevé', 'Support par email']
            }, {
              id: 2,
              name: 'Premium',
              price: 299.99,
              currency: 'TND',
              billingPeriod: BillingPeriod.MONTHLY,
              requestsPerMonth: 50000,
              features: ['Accès API illimité', 'Taux de requêtes prioritaire', 'Support dédié']
            }]
          }
        };
        setModel(mockModel);
        setFormData(mockModel);
      } catch (err) {
        console.error('Error fetching model:', err);
        setError('Erreur lors du chargement des données du modèle');
      } finally {
        setIsLoading(false);
      }
    };
    fetchModel();
  }, [modelId]);
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const {
      name,
      value
    } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  const handleVisibilityChange = (visibility: Visibility) => {
    setFormData({
      ...formData,
      visibility
    });
  };
  const handleAddTag = () => {
    if (!newTag.trim()) return;
    if (formData.tags?.includes(newTag.trim())) return;
    setFormData({
      ...formData,
      tags: [...(formData.tags || []), newTag.trim()]
    });
    setNewTag('');
  };
  const handleRemoveTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags?.filter(t => t !== tag)
    });
  };
  const handleAddLanguage = () => {
    if (!newLanguage.trim()) return;
    if (formData.languages?.includes(newLanguage.trim())) return;
    setFormData({
      ...formData,
      languages: [...(formData.languages || []), newLanguage.trim()]
    });
    setNewLanguage('');
  };
  const handleRemoveLanguage = (language: string) => {
    setFormData({
      ...formData,
      languages: formData.languages?.filter(l => l !== language)
    });
  };
  const handleTechnicalDetailChange = (field: string, value: string) => {
    setFormData({
      ...formData,
      technicalDetails: {
        ...(formData.technicalDetails || {}),
        [field]: value
      } as TechnicalDetail
    });
  };
  const handleAddApiEndpoint = () => {
    if (!newEndpoint.path.trim() || !newEndpoint.endpoint.trim()) return;
    setFormData({
      ...formData,
      apiEndpoints: [...(formData.apiEndpoints || []), {
        ...newEndpoint,
        id: Date.now()
      }]
    });
    setNewEndpoint({
      id: Date.now(),
      path: '',
      endpoint: '',
      description: '',
      successResponse: '',
      errorResponse: '',
      method: 'GET',
      requestBody: ''
    });
  };
  const handleRemoveApiEndpoint = (id: number) => {
    setFormData({
      ...formData,
      apiEndpoints: formData.apiEndpoints?.filter(endpoint => endpoint.id !== id)
    });
  };
  const handleAddParameter = (endpointId: number) => {
    if (!newParameter.name.trim()) return;
    const updatedEndpoints = formData.apiEndpoints?.map(endpoint => {
      if (endpoint.id === endpointId) {
        return {
          ...endpoint,
          parameters: [...endpoint.parameters, {
            ...newParameter
          }]
        };
      }
      return endpoint;
    });
    setFormData({
      ...formData,
      apiEndpoints: updatedEndpoints
    });
    setNewParameter({
      name: '',
      type: 'string',
      required: false,
      description: ''
    });
  };
  const handleRemoveParameter = (endpointId: number, paramName: string) => {
    const updatedEndpoints = formData.apiEndpoints?.map(endpoint => {
      if (endpoint.id === endpointId) {
        return {
          ...endpoint,
          parameters: endpoint.parameters.filter(param => param.name !== paramName)
        };
      }
      return endpoint;
    });
    setFormData({
      ...formData,
      apiEndpoints: updatedEndpoints
    });
  };
  const handleAddTask = () => {
    if (!newTask.name.trim()) return;
    setFormData({
      ...formData,
      tasks: [...(formData.tasks || []), {
        ...newTask,
        id: Date.now()
      }]
    });
    setNewTask({
      id: Date.now(),
      name: '',
      description: ''
    });
  };
  const handleRemoveTask = (id: number) => {
    setFormData({
      ...formData,
      tasks: formData.tasks?.filter(task => task.id !== id)
    });
  };
  const handleAddPerformanceMetric = () => {
    if (!newPerformanceMetric.metric.trim() || !newPerformanceMetric.value.trim()) return;
    setFormData({
      ...formData,
      performanceMetrics: [...(formData.performanceMetrics || []), {
        ...newPerformanceMetric
      }]
    });
    setNewPerformanceMetric({
      metric: '',
      value: '',
      dataset: '',
      description: ''
    });
  };
  const handleRemovePerformanceMetric = (index: number) => {
    const updatedMetrics = [...(formData.performanceMetrics || [])];
    updatedMetrics.splice(index, 1);
    setFormData({
      ...formData,
      performanceMetrics: updatedMetrics
    });
  };
  const handleAddPricingTier = () => {
    if (!newPricingTier.name.trim()) return;
    setFormData({
      ...formData,
      pricingPlan: {
        ...(formData.pricingPlan || {
          free: false,
          freeTier: {
            requestsPerMonth: 0,
            features: []
          },
          paidTiers: []
        }),
        paidTiers: [...(formData.pricingPlan?.paidTiers || []), {
          ...newPricingTier,
          id: Date.now()
        }]
      }
    });
    setNewPricingTier({
      id: Date.now(),
      name: '',
      price: 0,
      currency: 'TND',
      billingPeriod: BillingPeriod.MONTHLY,
      description: '',
      apiCallsLimit: null,
      apiCallsPrice: null,
      features: []
    });
  };
  const handleRemovePricingTier = (id: number) => {
    setFormData({
      ...formData,
      pricingPlan: {
        ...(formData.pricingPlan || {
          free: false,
          freeTier: {
            requestsPerMonth: 0,
            features: []
          },
          paidTiers: []
        }),
        paidTiers: formData.pricingPlan?.paidTiers.filter(tier => tier.id !== id) || []
      }
    });
  };
  const handleAddFeature = (tierId: number | 'free') => {
    if (!newFeature.trim()) return;
    if (tierId === 'free') {
      setFormData({
        ...formData,
        pricingPlan: {
          ...(formData.pricingPlan || {
            free: true,
            freeTier: {
              requestsPerMonth: 0,
              features: []
            },
            paidTiers: []
          }),
          freeTier: {
            ...(formData.pricingPlan?.freeTier || {
              requestsPerMonth: 0,
              features: []
            }),
            features: [...(formData.pricingPlan?.freeTier?.features || []), newFeature]
          }
        }
      });
    } else {
      const updatedTiers = formData.pricingPlan?.paidTiers.map(tier => {
        if (tier.id === tierId) {
          return {
            ...tier,
            features: [...tier.features, newFeature]
          };
        }
        return tier;
      });
      setFormData({
        ...formData,
        pricingPlan: {
          ...(formData.pricingPlan || {
            free: true,
            freeTier: {
              requestsPerMonth: 0,
              features: []
            },
            paidTiers: []
          }),
          paidTiers: updatedTiers || []
        }
      });
    }
    setNewFeature('');
  };
  const handleRemoveFeature = (tierId: number | 'free', index: number) => {
    if (tierId === 'free') {
      const updatedFeatures = [...(formData.pricingPlan?.freeTier?.features || [])];
      updatedFeatures.splice(index, 1);
      setFormData({
        ...formData,
        pricingPlan: {
          ...(formData.pricingPlan || {
            free: true,
            freeTier: {
              requestsPerMonth: 0,
              features: []
            },
            paidTiers: []
          }),
          freeTier: {
            ...(formData.pricingPlan?.freeTier || {
              requestsPerMonth: 0,
              features: []
            }),
            features: updatedFeatures
          }
        }
      });
    } else {
      const updatedTiers = formData.pricingPlan?.paidTiers.map(tier => {
        if (tier.id === tierId) {
          const updatedFeatures = [...tier.features];
          updatedFeatures.splice(index, 1);
          return {
            ...tier,
            features: updatedFeatures
          };
        }
        return tier;
      });
      setFormData({
        ...formData,
        pricingPlan: {
          ...(formData.pricingPlan || {
            free: true,
            freeTier: {
              requestsPerMonth: 0,
              features: []
            },
            paidTiers: []
          }),
          paidTiers: updatedTiers || []
        }
      });
    }
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setError(null);
    try {
      // In a real app, this would be an API call to update the model
      await new Promise(resolve => setTimeout(resolve, 1000));
      // Show success message
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
      }, 3000);
    } catch (err) {
      console.error('Error updating model:', err);
      setError('Erreur lors de la mise à jour du modèle');
    } finally {
      setIsSaving(false);
    }
  };
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50">
        <DeveloperDashboardHeader />
        <div className="flex">
          <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
          <main className="flex-1 p-6">
            <div className="container mx-auto max-w-5xl">
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
              </div>
            </div>
          </main>
        </div>
      </div>;
  }
  if (error && !model) {
    return <div className="min-h-screen bg-gray-50">
        <DeveloperDashboardHeader />
        <div className="flex">
          <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
          <main className="flex-1 p-6">
            <div className="container mx-auto max-w-5xl">
              <div className="bg-red-50 border border-red-200 rounded-xl p-6 flex items-start">
                <AlertCircle className="h-6 w-6 text-red-600 mr-3 mt-0.5" />
                <div>
                  <h3 className="font-medium text-red-800 mb-1">Erreur</h3>
                  <p className="text-red-700">{error}</p>
                  <button onClick={() => navigate('/developer/models')} className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                    Retour à la liste des modèles
                  </button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-5xl">
            {/* Back button and title */}
            <div className="mb-6">
              <button onClick={() => navigate('/developer/models')} className="text-blue-600 hover:text-blue-800 flex items-center mb-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Retour à la liste des modèles
              </button>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center mr-3">
                  <Bot className="h-5 w-5 text-blue-600" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Modifier le modèle: {model?.name}
                </h1>
              </div>
            </div>
            {/* Success message */}
            {success && <div className="mb-6 bg-green-50 border border-green-200 rounded-xl p-4 flex items-center">
                <Check className="h-5 w-5 text-green-600 mr-3" />
                <span className="text-green-700">
                  Modèle mis à jour avec succès
                </span>
              </div>}
            {/* Error message */}
            {error && <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-center">
                <AlertCircle className="h-5 w-5 text-red-600 mr-3" />
                <span className="text-red-700">{error}</span>
              </div>}
            {/* Section Navigation */}
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <div className="flex flex-wrap gap-2">
                <button onClick={() => setActiveSection('basic')} className={`px-4 py-2 rounded-lg ${activeSection === 'basic' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <Bot className="h-4 w-4 inline mr-2" />
                  Informations de base
                </button>
                <button onClick={() => setActiveSection('technical')} className={`px-4 py-2 rounded-lg ${activeSection === 'technical' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <Cpu className="h-4 w-4 inline mr-2" />
                  Détails techniques
                </button>
                <button onClick={() => setActiveSection('performance')} className={`px-4 py-2 rounded-lg ${activeSection === 'performance' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <BarChart2 className="h-4 w-4 inline mr-2" />
                  Performance
                </button>
                <button onClick={() => setActiveSection('api')} className={`px-4 py-2 rounded-lg ${activeSection === 'api' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <Server className="h-4 w-4 inline mr-2" />
                  API Endpoints
                </button>
                <button onClick={() => setActiveSection('tasks')} className={`px-4 py-2 rounded-lg ${activeSection === 'tasks' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <List className="h-4 w-4 inline mr-2" />
                  Tâches
                </button>
                <button onClick={() => setActiveSection('pricing')} className={`px-4 py-2 rounded-lg ${activeSection === 'pricing' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <CreditCard className="h-4 w-4 inline mr-2" />
                  Tarification
                </button>
                <button onClick={() => setActiveSection('documentation')} className={`px-4 py-2 rounded-lg ${activeSection === 'documentation' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                  <FileText className="h-4 w-4 inline mr-2" />
                  Documentation
                </button>
              </div>
            </div>
            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Information Card */}
              {activeSection === 'basic' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4">
                    Informations de base
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Nom du modèle
                      </label>
                      <input type="text" id="name" name="name" value={formData.name || ''} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" required />
                    </div>
                    <div>
                      <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <textarea id="description" name="description" value={formData.description || ''} onChange={handleInputChange} rows={4} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" required />
                    </div>
                    <div>
                      <label htmlFor="version" className="block text-sm font-medium text-gray-700 mb-1">
                        Version
                      </label>
                      <input type="text" id="version" name="version" value={formData.version || ''} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Visibilité
                      </label>
                      <div className="flex space-x-4">
                        <button type="button" className={`flex items-center px-4 py-2 rounded-lg border ${formData.visibility === Visibility.PUBLIC ? 'bg-blue-50 border-blue-300 text-blue-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`} onClick={() => handleVisibilityChange(Visibility.PUBLIC)}>
                          <Globe className="h-4 w-4 mr-2" />
                          Public
                        </button>
                        <button type="button" className={`flex items-center px-4 py-2 rounded-lg border ${formData.visibility === Visibility.PRIVATE ? 'bg-blue-50 border-blue-300 text-blue-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`} onClick={() => handleVisibilityChange(Visibility.PRIVATE)}>
                          <Lock className="h-4 w-4 mr-2" />
                          Privé
                        </button>
                      </div>
                      <p className="mt-1 text-sm text-gray-500">
                        {formData.visibility === Visibility.PUBLIC ? 'Votre modèle sera visible et accessible par tous les utilisateurs' : 'Votre modèle ne sera visible que par vous et les utilisateurs que vous autorisez'}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Tags
                      </label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {formData.tags?.map(tag => <span key={tag} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                            {tag}
                            <button type="button" className="ml-1.5 h-4 w-4 rounded-full bg-blue-200 text-blue-600 flex items-center justify-center hover:bg-blue-300" onClick={() => handleRemoveTag(tag)}>
                              &times;
                            </button>
                          </span>)}
                      </div>
                      <div className="flex">
                        <input type="text" value={newTag} onChange={e => setNewTag(e.target.value)} placeholder="Ajouter un tag" className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg focus:ring-blue-500 focus:border-blue-500" />
                        <button type="button" onClick={handleAddTag} className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700">
                          Ajouter
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Langues prises en charge
                      </label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {formData.languages?.map(language => <span key={language} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                            {language}
                            <button type="button" className="ml-1.5 h-4 w-4 rounded-full bg-green-200 text-green-600 flex items-center justify-center hover:bg-green-300" onClick={() => handleRemoveLanguage(language)}>
                              &times;
                            </button>
                          </span>)}
                      </div>
                      <div className="flex">
                        <input type="text" value={newLanguage} onChange={e => setNewLanguage(e.target.value)} placeholder="Ajouter une langue" className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg focus:ring-blue-500 focus:border-blue-500" />
                        <button type="button" onClick={handleAddLanguage} className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700">
                          Ajouter
                        </button>
                      </div>
                    </div>
                  </div>
                </div>}
              {/* Technical Details Card */}
              {activeSection === 'technical' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <Cpu className="h-5 w-5 mr-2 text-blue-600" />
                    Détails techniques
                  </h2>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Architecture
                        </label>
                        <input type="text" value={formData.technicalDetails?.architecture || ''} onChange={e => handleTechnicalDetailChange('architecture', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: BERT, GPT, ResNet" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Paramètres
                        </label>
                        <input type="text" value={formData.technicalDetails?.parameters || ''} onChange={e => handleTechnicalDetailChange('parameters', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 110M, 1.5B" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Framework
                        </label>
                        <input type="text" value={formData.technicalDetails?.framework || ''} onChange={e => handleTechnicalDetailChange('framework', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: PyTorch, TensorFlow" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Taille du modèle
                        </label>
                        <input type="text" value={formData.technicalDetails?.modelSize || ''} onChange={e => handleTechnicalDetailChange('modelSize', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 440MB, 2.1GB" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Format d'entrée
                        </label>
                        <input type="text" value={formData.technicalDetails?.inputFormat || ''} onChange={e => handleTechnicalDetailChange('inputFormat', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Texte brut, Tokens encodés" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Format de sortie
                        </label>
                        <input type="text" value={formData.technicalDetails?.outputFormat || ''} onChange={e => handleTechnicalDetailChange('outputFormat', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Embeddings, Logits, JSON" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Temps d'inférence
                        </label>
                        <input type="text" value={formData.technicalDetails?.inferenceTime || ''} onChange={e => handleTechnicalDetailChange('inferenceTime', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 50ms, 1.2s" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Prérequis
                        </label>
                        <input type="text" value={formData.technicalDetails?.requirements || ''} onChange={e => handleTechnicalDetailChange('requirements', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: GPU recommandé, 4GB RAM min" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Données d'entraînement
                      </label>
                      <textarea value={formData.technicalDetails?.trainingData || ''} onChange={e => handleTechnicalDetailChange('trainingData', e.target.value)} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 30GB de textes en arabe standard et dialectal tunisien" />
                    </div>
                  </div>
                </div>}
              {/* Performance Metrics Card */}
              {activeSection === 'performance' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <BarChart2 className="h-5 w-5 mr-2 text-blue-600" />
                    Métriques de performance
                  </h2>
                  <div className="space-y-4 mb-6">
                    {formData.performanceMetrics?.map((metric, index) => <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-200 relative">
                        <button type="button" onClick={() => handleRemovePerformanceMetric(index)} className="absolute top-2 right-2 text-red-500 hover:text-red-700">
                          <X className="h-4 w-4" />
                        </button>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Métrique
                            </span>
                            <span className="block mt-1">{metric.metric}</span>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Valeur
                            </span>
                            <span className="block mt-1 font-semibold text-blue-700">
                              {metric.value}
                            </span>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Dataset
                            </span>
                            <span className="block mt-1">{metric.dataset}</span>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Description
                            </span>
                            <span className="block mt-1">
                              {metric.description}
                            </span>
                          </div>
                        </div>
                      </div>)}
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 className="text-md font-medium mb-3">
                      Ajouter une nouvelle métrique
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Nom de la métrique
                        </label>
                        <input type="text" value={newPerformanceMetric.metric} onChange={e => setNewPerformanceMetric({
                      ...newPerformanceMetric,
                      metric: e.target.value
                    })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Précision, F1-Score, BLEU" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Valeur
                        </label>
                        <input type="text" value={newPerformanceMetric.value} onChange={e => setNewPerformanceMetric({
                      ...newPerformanceMetric,
                      value: e.target.value
                    })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 92.5%, 0.88, 36.2" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Dataset de test
                        </label>
                        <input type="text" value={newPerformanceMetric.dataset} onChange={e => setNewPerformanceMetric({
                      ...newPerformanceMetric,
                      dataset: e.target.value
                    })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: TuniBERT Benchmark, ANER Corpus" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <input type="text" value={newPerformanceMetric.description} onChange={e => setNewPerformanceMetric({
                      ...newPerformanceMetric,
                      description: e.target.value
                    })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Précision sur tâches de classification binaire" />
                      </div>
                    </div>
                    <div className="mt-4">
                      <button type="button" onClick={handleAddPerformanceMetric} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                        <Plus className="h-4 w-4 mr-2" />
                        Ajouter la métrique
                      </button>
                    </div>
                  </div>
                </div>}
              {/* API Endpoints Card */}
              {activeSection === 'api' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <Server className="h-5 w-5 mr-2 text-blue-600" />
                    Points d'accès API
                  </h2>
                  <div className="space-y-6 mb-6">
                    {formData.apiEndpoints?.map(endpoint => <div key={endpoint.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-md font-medium">
                            {endpoint.path}
                          </h3>
                          <button type="button" onClick={() => handleRemoveApiEndpoint(endpoint.id)} className="text-red-500 hover:text-red-700">
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                        <div className="space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <span className="block text-sm font-medium text-gray-700">
                                Méthode
                              </span>
                              <span className="inline-flex items-center px-2.5 py-0.5 mt-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                {endpoint.method}
                              </span>
                            </div>
                            <div>
                              <span className="block text-sm font-medium text-gray-700">
                                Endpoint URL
                              </span>
                              <code className="block mt-1 p-2 bg-gray-100 rounded font-mono text-sm">
                                {endpoint.endpoint}
                              </code>
                            </div>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Description
                            </span>
                            <p className="mt-1">{endpoint.description}</p>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Corps de la requête
                            </span>
                            <pre className="mt-1 p-2 bg-gray-100 rounded font-mono text-sm overflow-x-auto">
                              {endpoint.requestBody || 'Aucun corps de requête'}
                            </pre>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Réponse en cas de succès
                            </span>
                            <pre className="mt-1 p-2 bg-gray-100 rounded font-mono text-sm overflow-x-auto">
                              {endpoint.successResponse}
                            </pre>
                          </div>
                          <div>
                            <span className="block text-sm font-medium text-gray-700">
                              Réponse en cas d'erreur
                            </span>
                            <pre className="mt-1 p-2 bg-gray-100 rounded font-mono text-sm overflow-x-auto">
                              {endpoint.errorResponse}
                            </pre>
                          </div>
                        </div>
                      </div>)}
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 className="text-md font-medium mb-4">
                      Ajouter un nouveau point d'accès API
                    </h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Chemin
                          </label>
                          <input type="text" value={newEndpoint.path} onChange={e => setNewEndpoint({
                        ...newEndpoint,
                        path: e.target.value
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: /sentiment" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Méthode
                          </label>
                          <select value={newEndpoint.method} onChange={e => setNewEndpoint({
                        ...newEndpoint,
                        method: e.target.value
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                            <option value="GET">GET</option>
                            <option value="POST">POST</option>
                            <option value="PUT">PUT</option>
                            <option value="DELETE">DELETE</option>
                            <option value="PATCH">PATCH</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          URL de l'endpoint
                        </label>
                        <input type="text" value={newEndpoint.endpoint} onChange={e => setNewEndpoint({
                      ...newEndpoint,
                      endpoint: e.target.value
                    })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: https://api.ai-tunisia.com/v1/models/arabicbert/sentiment" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <textarea value={newEndpoint.description} onChange={e => setNewEndpoint({
                      ...newEndpoint,
                      description: e.target.value
                    })} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Analyse le sentiment d'un texte en arabe" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Corps de la requête (JSON)
                        </label>
                        <textarea value={newEndpoint.requestBody} onChange={e => setNewEndpoint({
                      ...newEndpoint,
                      requestBody: e.target.value
                    })} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 font-mono text-sm" placeholder='ex: {"text": "Exemple de texte à analyser"}' />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Réponse en cas de succès (JSON)
                        </label>
                        <textarea value={newEndpoint.successResponse} onChange={e => setNewEndpoint({
                      ...newEndpoint,
                      successResponse: e.target.value
                    })} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 font-mono text-sm" placeholder='ex: {"sentiment": "positive", "score": 0.92}' />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Réponse en cas d'erreur (JSON)
                        </label>
                        <textarea value={newEndpoint.errorResponse} onChange={e => setNewEndpoint({
                      ...newEndpoint,
                      errorResponse: e.target.value
                    })} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 font-mono text-sm" placeholder='ex: {"error": "Invalid input", "code": 400}' />
                      </div>
                      <div>
                        <button type="button" onClick={handleAddApiEndpoint} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                          <Plus className="h-4 w-4 mr-2" />
                          Ajouter l'endpoint
                        </button>
                      </div>
                    </div>
                  </div>
                </div>}
              {/* Tasks Card */}
              {activeSection === 'tasks' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <List className="h-5 w-5 mr-2 text-blue-600" />
                    Tâches prises en charge
                  </h2>
                  <div className="space-y-4 mb-6">
                    {formData.tasks?.map(task => <div key={task.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200 flex justify-between">
                        <div>
                          <h3 className="font-medium">{task.name}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            {task.description}
                          </p>
                        </div>
                        <button type="button" onClick={() => handleRemoveTask(task.id)} className="text-red-500 hover:text-red-700 self-start">
                          <X className="h-4 w-4" />
                        </button>
                      </div>)}
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 className="text-md font-medium mb-3">
                      Ajouter une nouvelle tâche
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Nom de la tâche
                        </label>
                        <input type="text" value={newTask.name} onChange={e => setNewTask({
                      ...newTask,
                      name: e.target.value
                    })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Analyse de sentiment" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <textarea value={newTask.description} onChange={e => setNewTask({
                      ...newTask,
                      description: e.target.value
                    })} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Détermine si un texte exprime un sentiment positif, négatif ou neutre" />
                      </div>
                      <div>
                        <button type="button" onClick={handleAddTask} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                          <Plus className="h-4 w-4 mr-2" />
                          Ajouter la tâche
                        </button>
                      </div>
                    </div>
                  </div>
                </div>}
              {/* Pricing Card */}
              {activeSection === 'pricing' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <CreditCard className="h-5 w-5 mr-2 text-blue-600" />
                    Plans de tarification
                  </h2>
                  <div className="mb-6">
                    <h3 className="text-md font-medium mb-3">
                      Plans d'abonnement
                    </h3>
                    <div className="space-y-6 mb-6">
                      {formData.pricingPlan?.paidTiers?.map(tier => <div key={tier.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className="font-medium">{tier.name}</h4>
                              <p className="text-sm text-gray-600 mt-1">
                                {tier.description}
                              </p>
                              <div className="mt-1 flex items-baseline">
                                <span className="text-xl font-bold text-gray-900">
                                  {tier.price} {tier.currency}
                                </span>
                                <span className="ml-1 text-sm text-gray-500">
                                  /
                                  {tier.billingPeriod === BillingPeriod.MONTHLY ? 'mois' : 'an'}
                                </span>
                              </div>
                            </div>
                            <button type="button" onClick={() => handleRemovePricingTier(tier.id)} className="text-red-500 hover:text-red-700">
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                          <div className="space-y-3">
                            <div>
                              <span className="block text-sm font-medium text-gray-700 mb-1">
                                Limite d'appels API
                              </span>
                              <span className="block font-medium">
                                {tier.apiCallsLimit ? tier.apiCallsLimit.toLocaleString() : 'Illimité'}
                              </span>
                            </div>
                            {tier.apiCallsPrice && <div>
                                <span className="block text-sm font-medium text-gray-700 mb-1">
                                  Prix par appel API
                                </span>
                                <span className="block font-medium">
                                  {tier.apiCallsPrice} {tier.currency}
                                </span>
                              </div>}
                            <div>
                              <span className="block text-sm font-medium text-gray-700 mb-1">
                                Fonctionnalités incluses
                              </span>
                              <div className="space-y-2">
                                {tier.features.map((feature, index) => <div key={index} className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-gray-200">
                                    <span>{feature}</span>
                                    <button type="button" onClick={() => handleRemoveFeature(tier.id, index)} className="text-red-500 hover:text-red-700">
                                      <X className="h-4 w-4" />
                                    </button>
                                  </div>)}
                              </div>
                              <div className="flex mt-3">
                                <input type="text" value={newFeature} onChange={e => setNewFeature(e.target.value)} placeholder="Ajouter une fonctionnalité..." className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg focus:ring-blue-500 focus:border-blue-500" />
                                <button type="button" onClick={() => handleAddFeature(tier.id)} className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700">
                                  <Plus className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>)}
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                      <h3 className="text-md font-medium mb-3">
                        Ajouter un nouveau plan
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Nom du plan
                          </label>
                          <input type="text" value={newPricingTier.name} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        name: e.target.value
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Standard, Premium, Entreprise" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Description
                          </label>
                          <input type="text" value={newPricingTier.description} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        description: e.target.value
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: Pour les projets de recherche et les tests" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Période de facturation
                          </label>
                          <select value={newPricingTier.billingPeriod} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        billingPeriod: e.target.value as BillingPeriod
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                            <option value={BillingPeriod.MONTHLY}>
                              Mensuel
                            </option>
                            <option value={BillingPeriod.ANNUAL}>Annuel</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Prix
                          </label>
                          <input type="number" step="0.01" value={newPricingTier.price} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        price: parseFloat(e.target.value) || 0
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Devise
                          </label>
                          <select value={newPricingTier.currency} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        currency: e.target.value
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                            <option value="TND">TND - Dinar Tunisien</option>
                            <option value="EUR">EUR - Euro</option>
                            <option value="USD">USD - Dollar US</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Limite d'appels API
                          </label>
                          <input type="number" value={newPricingTier.apiCallsLimit || ''} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        apiCallsLimit: e.target.value ? parseInt(e.target.value) : null
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 10000" required />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Prix par appel API (optionnel)
                          </label>
                          <input type="number" step="0.001" value={newPricingTier.apiCallsPrice || ''} onChange={e => setNewPricingTier({
                        ...newPricingTier,
                        apiCallsPrice: e.target.value ? parseFloat(e.target.value) : null
                      })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="ex: 0.001 par appel" />
                        </div>
                      </div>
                      <div className="mt-4">
                        <button type="button" onClick={handleAddPricingTier} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                          <Plus className="h-4 w-4 mr-2" />
                          Ajouter le plan
                        </button>
                      </div>
                    </div>
                  </div>
                </div>}
              {/* Documentation Card */}
              {activeSection === 'documentation' && <div className="bg-white rounded-xl shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-blue-600" />
                    Documentation
                  </h2>
                  <div>
                    <label htmlFor="documentation" className="block text-sm font-medium text-gray-700 mb-1">
                      Documentation (Markdown)
                    </label>
                    <textarea id="documentation" name="documentation" value={formData.documentation || ''} onChange={handleInputChange} rows={12} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 font-mono text-sm" />
                    <p className="mt-1 text-sm text-gray-500">
                      Vous pouvez utiliser la syntaxe Markdown pour formater
                      votre documentation
                    </p>
                  </div>
                </div>}
              {/* Info Box */}
              <div className="bg-blue-50 rounded-xl shadow-sm p-6">
                <div className="flex items-start">
                  <Info className="h-5 w-5 text-blue-600 mr-3 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-blue-800 mb-1">
                      Mise à jour du modèle
                    </h3>
                    <p className="text-blue-700">
                      La mise à jour des métadonnées de votre modèle n'affecte
                      pas les versions déployées ou les abonnements existants.
                      Pour mettre à jour le modèle lui-même, veuillez utiliser
                      l'interface de déploiement.
                    </p>
                  </div>
                </div>
              </div>
              {/* Submit Button */}
              <div className="flex justify-end">
                <button type="submit" className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center" disabled={isSaving}>
                  {isSaving ? <>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      Enregistrement...
                    </> : <>
                      <Save className="h-5 w-5 mr-2" />
                      Enregistrer les modifications
                    </>}
                </button>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>;
}