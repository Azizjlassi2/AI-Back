import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Save, X, Plus, Trash2, DollarSign, Calendar, Zap, AlertCircle, Info, CheckCircle } from 'lucide-react';
import { DeveloperDashboardHeader } from '../../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../../components/developer-dashboard/DeveloperDashboardSidebar';
enum BillingPeriod {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
  PAY_AS_YOU_GO = 'PAY_AS_YOU_GO',
}
interface SubscriptionPlan {
  id: number;
  name: string;
  description: string;
  price: number;
  currency: string;
  billingPeriod: BillingPeriod;
  features: string[];
  apiCallsLimit?: number;
  apiCallsPrice?: number;
  isActive: boolean;
}
interface Model {
  id: number;
  name: string;
  version: string;
}
export function EditSubscriptionPlanPage() {
  const {
    modelId,
    planId
  } = useParams<{
    modelId: string;
    planId: string;
  }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('models');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [model, setModel] = useState<Model | null>(null);
  const [plan, setPlan] = useState<SubscriptionPlan | null>(null);
  const [newFeature, setNewFeature] = useState('');
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 800));
        // Mock data
        const mockModel: Model = {
          id: parseInt(modelId || '1'),
          name: 'ArabicBERT',
          version: '2.1.0'
        };
        const mockPlan: SubscriptionPlan = {
          id: parseInt(planId || '1'),
          name: 'Plan Standard',
          description: 'Pour les startups et projets en croissance',
          price: 49.99,
          currency: 'TND',
          billingPeriod: BillingPeriod.MONTHLY,
          features: ["Accès à l'API avec limites étendues", '50 000 appels API par mois', 'Support par email', "Tableaux de bord d'analyse"],
          apiCallsLimit: 50000,
          isActive: true
        };
        setModel(mockModel);
        setPlan(mockPlan);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Erreur lors du chargement des données');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [modelId, planId]);
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  const handleInputChange = (field: keyof SubscriptionPlan, value: string | number | boolean) => {
    if (!plan) return;
    setPlan({
      ...plan,
      [field]: value
    });
  };
  const handleAddFeature = () => {
    if (!plan || !newFeature.trim()) return;
    setPlan({
      ...plan,
      features: [...plan.features, newFeature.trim()]
    });
    setNewFeature('');
  };
  const handleRemoveFeature = (index: number) => {
    if (!plan) return;
    setPlan({
      ...plan,
      features: plan.features.filter((_, i) => i !== index)
    });
  };
  const handleSave = async () => {
    if (!plan) return;
    // Validation
    if (!plan.name.trim()) {
      setError('Le nom du plan est requis');
      return;
    }
    if (plan.price < 0) {
      setError('Le prix ne peut pas être négatif');
      return;
    }
    if (plan.billingPeriod !== BillingPeriod.PAY_AS_YOU_GO && (!plan.apiCallsLimit || plan.apiCallsLimit <= 0)) {
      setError("La limite d'appels API doit être supérieure à 0");
      return;
    }
    if (plan.billingPeriod === BillingPeriod.PAY_AS_YOU_GO && (!plan.apiCallsPrice || plan.apiCallsPrice <= 0)) {
      setError('Le prix par appel API doit être supérieur à 0');
      return;
    }
    if (plan.features.length === 0) {
      setError('Veuillez ajouter au moins une fonctionnalité');
      return;
    }
    setIsSaving(true);
    setError(null);
    setSuccessMessage(null);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      setSuccessMessage("Plan d'abonnement mis à jour avec succès");
      // Redirect after 2 seconds
      setTimeout(() => {
        navigate(`/developer/models/${modelId}`);
      }, 2000);
    } catch (err) {
      console.error('Error saving plan:', err);
      setError('Erreur lors de la sauvegarde du plan');
    } finally {
      setIsSaving(false);
    }
  };
  const handleCancel = () => {
    navigate(`/developer/models/${modelId}`);
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  if (!model || !plan) {
    return <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Erreur</h1>
        <p className="text-gray-600 mb-6">
          Impossible de charger les données du plan.
        </p>
        <button onClick={() => navigate(`/developer/models/${modelId}`)} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Retour au modèle
        </button>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-4xl">
            {/* Header */}
            <div className="mb-6">
              <Link to={`/developer/models/${modelId}`} className="inline-flex items-center text-sm text-gray-500 hover:text-blue-600 mb-2">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Retour au modèle
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">
                Modifier le plan d'abonnement
              </h1>
              <p className="text-sm text-gray-500 mt-1">
                {model.name} • Version {model.version}
              </p>
            </div>
            {/* Success Message */}
            {successMessage && <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-start">
                <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-green-800">Succès</h3>
                  <p className="text-sm text-green-700 mt-1">
                    {successMessage}
                  </p>
                </div>
              </div>}
            {/* Error Message */}
            {error && <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
                <AlertCircle className="h-5 w-5 text-red-600 mr-3 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-red-800">Erreur</h3>
                  <p className="text-sm text-red-700 mt-1">{error}</p>
                </div>
              </div>}
            {/* Form */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <h2 className="text-lg font-semibold mb-6">
                Informations générales
              </h2>
              {/* Plan Name */}
              <div className="mb-6">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Nom du plan <span className="text-red-500">*</span>
                </label>
                <input type="text" id="name" value={plan.name} onChange={e => handleInputChange('name', e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Ex: Plan Standard" />
              </div>
              {/* Description */}
              <div className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea id="description" value={plan.description} onChange={e => handleInputChange('description', e.target.value)} rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Décrivez brièvement ce plan..." />
              </div>
              {/* Billing Period */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Période de facturation <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <button type="button" onClick={() => handleInputChange('billingPeriod', BillingPeriod.MONTHLY)} className={`p-4 border-2 rounded-lg text-left transition-colors ${plan.billingPeriod === BillingPeriod.MONTHLY ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <Calendar className="h-5 w-5 text-blue-600 mb-2" />
                    <div className="font-medium text-gray-900">Mensuel</div>
                    <div className="text-sm text-gray-500">
                      Facturation mensuelle
                    </div>
                  </button>
                  <button type="button" onClick={() => handleInputChange('billingPeriod', BillingPeriod.ANNUAL)} className={`p-4 border-2 rounded-lg text-left transition-colors ${plan.billingPeriod === BillingPeriod.ANNUAL ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <Calendar className="h-5 w-5 text-blue-600 mb-2" />
                    <div className="font-medium text-gray-900">Annuel</div>
                    <div className="text-sm text-gray-500">
                      Facturation annuelle
                    </div>
                  </button>
                  <button type="button" onClick={() => handleInputChange('billingPeriod', BillingPeriod.PAY_AS_YOU_GO)} className={`p-4 border-2 rounded-lg text-left transition-colors ${plan.billingPeriod === BillingPeriod.PAY_AS_YOU_GO ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <Zap className="h-5 w-5 text-blue-600 mb-2" />
                    <div className="font-medium text-gray-900">
                      Pay-as-you-go
                    </div>
                    <div className="text-sm text-gray-500">
                      Paiement à l'usage
                    </div>
                  </button>
                </div>
              </div>
              {/* Price */}
              {plan.billingPeriod !== BillingPeriod.PAY_AS_YOU_GO && <div className="mb-6">
                  <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-2">
                    Prix <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-5 w-5 text-gray-400" />
                    </div>
                    <input type="number" id="price" value={plan.price} onChange={e => handleInputChange('price', parseFloat(e.target.value))} min="0" step="0.01" className="w-full pl-10 pr-20 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="0.00" />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">
                        {plan.currency}
                      </span>
                    </div>
                  </div>
                  <p className="mt-1 text-sm text-gray-500">
                    Prix par{' '}
                    {plan.billingPeriod === BillingPeriod.MONTHLY ? 'mois' : 'an'}
                  </p>
                </div>}
              {/* API Calls Limit or Price */}
              {plan.billingPeriod === BillingPeriod.PAY_AS_YOU_GO ? <div className="mb-6">
                  <label htmlFor="apiCallsPrice" className="block text-sm font-medium text-gray-700 mb-2">
                    Prix par appel API <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign className="h-5 w-5 text-gray-400" />
                    </div>
                    <input type="number" id="apiCallsPrice" value={plan.apiCallsPrice || 0} onChange={e => handleInputChange('apiCallsPrice', parseFloat(e.target.value))} min="0" step="0.001" className="w-full pl-10 pr-20 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="0.000" />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">
                        {plan.currency}
                      </span>
                    </div>
                  </div>
                  <p className="mt-1 text-sm text-gray-500">
                    Prix facturé pour chaque appel API
                  </p>
                </div> : <div className="mb-6">
                  <label htmlFor="apiCallsLimit" className="block text-sm font-medium text-gray-700 mb-2">
                    Limite d'appels API <span className="text-red-500">*</span>
                  </label>
                  <input type="number" id="apiCallsLimit" value={plan.apiCallsLimit || 0} onChange={e => handleInputChange('apiCallsLimit', parseInt(e.target.value))} min="0" step="1000" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="50000" />
                  <p className="mt-1 text-sm text-gray-500">
                    Nombre maximum d'appels API par{' '}
                    {plan.billingPeriod === BillingPeriod.MONTHLY ? 'mois' : 'an'}
                  </p>
                </div>}
              {/* Currency */}
              <div className="mb-6">
                <label htmlFor="currency" className="block text-sm font-medium text-gray-700 mb-2">
                  Devise <span className="text-red-500">*</span>
                </label>
                <select id="currency" value={plan.currency} onChange={e => handleInputChange('currency', e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="TND">TND - Dinar Tunisien</option>
                  <option value="USD">USD - Dollar Américain</option>
                  <option value="EUR">EUR - Euro</option>
                </select>
              </div>
              {/* Active Status */}
              <div className="mb-6">
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input id="isActive" name="isActive" type="checkbox" checked={plan.isActive} onChange={e => handleInputChange('isActive', e.target.checked)} className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                  </div>
                  <div className="ml-3 text-sm">
                    <label htmlFor="isActive" className="font-medium text-gray-700">
                      Plan actif
                    </label>
                    <p className="text-gray-500">
                      Les plans inactifs ne sont pas visibles par les
                      utilisateurs et ne peuvent pas être souscrits.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            {/* Features */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">
                Fonctionnalités incluses
              </h2>
              {/* Existing Features */}
              <div className="space-y-2 mb-4">
                {plan.features.map((feature, index) => <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-700">{feature}</span>
                    <button type="button" onClick={() => handleRemoveFeature(index)} className="text-red-600 hover:text-red-700">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>)}
              </div>
              {/* Add New Feature */}
              <div className="flex gap-2">
                <input type="text" value={newFeature} onChange={e => setNewFeature(e.target.value)} onKeyPress={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddFeature();
                }
              }} placeholder="Ajouter une fonctionnalité..." className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
                <button type="button" onClick={handleAddFeature} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                  <Plus className="h-4 w-4 mr-2" />
                  Ajouter
                </button>
              </div>
              <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start">
                <Info className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium mb-1">Conseils</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>
                      Soyez clair et concis dans la description des
                      fonctionnalités
                    </li>
                    <li>
                      Mettez en avant les avantages spécifiques de ce plan
                    </li>
                    <li>
                      Utilisez des termes compréhensibles pour vos utilisateurs
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            {/* Action Buttons */}
            <div className="flex justify-end gap-3">
              <button type="button" onClick={handleCancel} disabled={isSaving} className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center">
                <X className="h-4 w-4 mr-2" />
                Annuler
              </button>
              <button type="button" onClick={handleSave} disabled={isSaving} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center">
                {isSaving ? <>
                    <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                    Enregistrement...
                  </> : <>
                    <Save className="h-4 w-4 mr-2" />
                    Enregistrer les modifications
                  </>}
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>;
}