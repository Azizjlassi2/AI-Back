import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, BarChart2, Download, RefreshCw, TrendingUp, TrendingDown, Users, DollarSign, Activity, AlertCircle, Globe, Clock, Zap, Target, Info } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DeveloperDashboardHeader } from '../../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../../components/developer-dashboard/DeveloperDashboardSidebar';
interface ModelAnalytics {
  model: {
    id: number;
    name: string;
    version: string;
  };
  overview: {
    totalApiCalls: number;
    apiCallsTrend: number;
    uniqueUsers: number;
    usersTrend: number;
    totalRevenue: number;
    revenueTrend: number;
    avgResponseTime: string;
    responseTimeTrend: number;
    errorRate: number;
    errorRateTrend: number;
    successRate: number;
  };
  timeSeriesData: {
    date: string;
    apiCalls: number;
    users: number;
    revenue: number;
    avgResponseTime: number;
    errorRate: number;
  }[];
  geographicData: {
    country: string;
    users: number;
    apiCalls: number;
    revenue: number;
    percentage: number;
  }[];
  endpointData: {
    endpoint: string;
    method: string;
    calls: number;
    avgResponseTime: string;
    errorRate: number;
    revenue: number;
  }[];
  subscriptionData: {
    planName: string;
    subscribers: number;
    revenue: number;
    percentage: number;
  }[];
  performanceMetrics: {
    p50ResponseTime: string;
    p95ResponseTime: string;
    p99ResponseTime: string;
    uptime: string;
    totalRequests: number;
    successfulRequests: number;
    failedRequests: number;
  };
  topUsers: {
    userId: string;
    username: string;
    apiCalls: number;
    revenue: number;
    lastActive: string;
  }[];
}
export function DeveloperModelAnalyticsPage() {
  const {
    id
  } = useParams<{
    id: string;
  }>();
  const [activeTab, setActiveTab] = useState('models');
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [analytics, setAnalytics] = useState<ModelAnalytics | null>(null);
  const [selectedMetric, setSelectedMetric] = useState<'apiCalls' | 'users' | 'revenue' | 'responseTime' | 'errorRate'>('apiCalls');
  useEffect(() => {
    const fetchAnalytics = async () => {
      setIsLoading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 800));
        const mockAnalytics = generateMockAnalytics(dateRange);
        setAnalytics(mockAnalytics);
      } catch (error) {
        console.error('Error fetching analytics:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAnalytics();
  }, [id, dateRange]);
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      const mockAnalytics = generateMockAnalytics(dateRange);
      setAnalytics(mockAnalytics);
    } catch (error) {
      console.error('Error refreshing data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };
  const generateMockAnalytics = (range: '7d' | '30d' | '90d' | 'all'): ModelAnalytics => {
    const daysToGenerate = range === '7d' ? 7 : range === '30d' ? 30 : range === '90d' ? 90 : 180;
    const timeSeriesData = [];
    const now = new Date();
    for (let i = daysToGenerate - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(now.getDate() - i);
      const dateString = date.toISOString().split('T')[0];
      timeSeriesData.push({
        date: dateString,
        apiCalls: Math.round(2000 + Math.random() * 1000),
        users: Math.round(150 + Math.random() * 50),
        revenue: Math.round(400 + Math.random() * 200),
        avgResponseTime: Math.round(120 + Math.random() * 40),
        errorRate: Math.round((Math.random() * 2 + 0.5) * 10) / 10
      });
    }
    const totalApiCalls = timeSeriesData.reduce((sum, day) => sum + day.apiCalls, 0);
    const totalRevenue = timeSeriesData.reduce((sum, day) => sum + day.revenue, 0);
    return {
      model: {
        id: parseInt(id || '1'),
        name: 'ArabicBERT',
        version: '2.1.0'
      },
      overview: {
        totalApiCalls,
        apiCallsTrend: 12.5,
        uniqueUsers: 1250,
        usersTrend: 8.3,
        totalRevenue,
        revenueTrend: 15.7,
        avgResponseTime: '135ms',
        responseTimeTrend: -5.2,
        errorRate: 0.8,
        errorRateTrend: -0.3,
        successRate: 99.2
      },
      timeSeriesData,
      geographicData: [{
        country: 'Tunisie',
        users: 560,
        apiCalls: 35000,
        revenue: 7200,
        percentage: 45
      }, {
        country: 'Algérie',
        users: 280,
        apiCalls: 18000,
        revenue: 3800,
        percentage: 22
      }, {
        country: 'Maroc',
        users: 200,
        apiCalls: 12500,
        revenue: 2600,
        percentage: 16
      }, {
        country: 'France',
        users: 125,
        apiCalls: 8000,
        revenue: 1700,
        percentage: 10
      }, {
        country: 'Égypte',
        users: 85,
        apiCalls: 5000,
        revenue: 950,
        percentage: 7
      }],
      endpointData: [{
        endpoint: '/api/v1/predict',
        method: 'POST',
        calls: 65432,
        avgResponseTime: '135ms',
        errorRate: 0.8,
        revenue: 13500
      }, {
        endpoint: '/api/v1/batch-predict',
        method: 'POST',
        calls: 8900,
        avgResponseTime: '450ms',
        errorRate: 1.2,
        revenue: 1850
      }, {
        endpoint: '/api/v1/info',
        method: 'GET',
        calls: 12345,
        avgResponseTime: '42ms',
        errorRate: 0.2,
        revenue: 0
      }, {
        endpoint: '/api/v1/health',
        method: 'GET',
        calls: 45678,
        avgResponseTime: '15ms',
        errorRate: 0.1,
        revenue: 0
      }],
      subscriptionData: [{
        planName: 'Plan Basique',
        subscribers: 845,
        revenue: 0,
        percentage: 67.6
      }, {
        planName: 'Plan Standard',
        subscribers: 325,
        revenue: 16246.75,
        percentage: 26
      }, {
        planName: 'Plan Pro',
        subscribers: 80,
        revenue: 39999.2,
        percentage: 6.4
      }],
      performanceMetrics: {
        p50ResponseTime: '125ms',
        p95ResponseTime: '280ms',
        p99ResponseTime: '450ms',
        uptime: '99.95%',
        totalRequests: totalApiCalls,
        successfulRequests: Math.round(totalApiCalls * 0.992),
        failedRequests: Math.round(totalApiCalls * 0.008)
      },
      topUsers: [{
        userId: 'usr_001',
        username: 'ahmed_dev',
        apiCalls: 8500,
        revenue: 850,
        lastActive: '2024-01-20'
      }, {
        userId: 'usr_002',
        username: 'sarah_ai',
        apiCalls: 7200,
        revenue: 720,
        lastActive: '2024-01-20'
      }, {
        userId: 'usr_003',
        username: 'tech_startup',
        apiCalls: 6800,
        revenue: 680,
        lastActive: '2024-01-19'
      }, {
        userId: 'usr_004',
        username: 'data_lab',
        apiCalls: 5900,
        revenue: 590,
        lastActive: '2024-01-20'
      }, {
        userId: 'usr_005',
        username: 'ml_research',
        apiCalls: 5400,
        revenue: 540,
        lastActive: '2024-01-18'
      }]
    };
  };
  const formatNumber = (num: number): string => {
    return num.toLocaleString('fr-FR');
  };
  const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('fr-FR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short'
    });
  };
  const CustomTooltip = ({
    active,
    payload,
    label
  }: any) => {
    if (active && payload && payload.length) {
      return <div className="bg-white p-3 border border-gray-200 shadow-sm rounded-md">
          <p className="font-medium text-gray-800">{formatDate(label)}</p>
          {payload.map((entry: any, index: number) => <p key={index} style={{
          color: entry.color
        }} className="text-sm">
              {entry.name}:{' '}
              {entry.dataKey === 'revenue' ? `${formatCurrency(entry.value)} TND` : entry.dataKey === 'avgResponseTime' ? `${entry.value}ms` : entry.dataKey === 'errorRate' ? `${entry.value}%` : formatNumber(entry.value)}
            </p>)}
        </div>;
    }
    return null;
  };
  const COLORS = {
    blue: '#3b82f6',
    green: '#10b981',
    purple: '#8b5cf6',
    yellow: '#f59e0b',
    red: '#ef4444',
    pieColors: ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#6b7280']
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  if (!analytics) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-800 mb-2">
            Erreur de chargement
          </h2>
          <p className="text-gray-600">
            Impossible de charger les données d'analyse.
          </p>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-7xl">
            {/* Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <Link to={`/developer/models/${id}`} className="inline-flex items-center text-sm text-gray-500 hover:text-blue-600 mb-2">
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Retour au modèle
                </Link>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center">
                  <BarChart2 className="h-6 w-6 text-blue-600 mr-2" />
                  Analyses - {analytics.model.name}
                </h1>
                <p className="text-sm text-gray-500 mt-1">
                  Version {analytics.model.version}
                </p>
              </div>
              <div className="flex items-center space-x-2 mt-4 md:mt-0">
                <div className="flex items-center bg-white rounded-md border border-gray-200 shadow-sm">
                  <button className={`px-3 py-1.5 text-sm rounded-md ${dateRange === '7d' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setDateRange('7d')}>
                    7 jours
                  </button>
                  <button className={`px-3 py-1.5 text-sm rounded-md ${dateRange === '30d' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setDateRange('30d')}>
                    30 jours
                  </button>
                  <button className={`px-3 py-1.5 text-sm rounded-md ${dateRange === '90d' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setDateRange('90d')}>
                    90 jours
                  </button>
                  <button className={`px-3 py-1.5 text-sm rounded-md ${dateRange === 'all' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setDateRange('all')}>
                    Tout
                  </button>
                </div>
                <button className="px-3 py-1.5 text-sm bg-white text-gray-700 rounded-md border border-gray-200 shadow-sm hover:bg-gray-100 flex items-center" onClick={handleRefresh} disabled={isRefreshing}>
                  <RefreshCw className={`h-4 w-4 mr-1.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                  Actualiser
                </button>
                <button className="px-3 py-1.5 text-sm bg-white text-gray-700 rounded-md border border-gray-200 shadow-sm hover:bg-gray-100 flex items-center">
                  <Download className="h-4 w-4 mr-1.5" />
                  Exporter
                </button>
              </div>
            </div>
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
              <button className={`bg-white rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow ${selectedMetric === 'apiCalls' ? 'ring-2 ring-blue-500' : ''}`} onClick={() => setSelectedMetric('apiCalls')}>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-blue-100">
                    <Activity className="h-5 w-5 text-blue-600" />
                  </div>
                  {analytics.overview.apiCallsTrend > 0 ? <div className="flex items-center text-green-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>+{analytics.overview.apiCallsTrend}%</span>
                    </div> : <div className="flex items-center text-red-600 text-sm">
                      <TrendingDown className="h-4 w-4 mr-1" />
                      <span>{analytics.overview.apiCallsTrend}%</span>
                    </div>}
                </div>
                <p className="text-sm text-gray-500">Appels API</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatNumber(analytics.overview.totalApiCalls)}
                </p>
              </button>
              <button className={`bg-white rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow ${selectedMetric === 'users' ? 'ring-2 ring-green-500' : ''}`} onClick={() => setSelectedMetric('users')}>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-green-100">
                    <Users className="h-5 w-5 text-green-600" />
                  </div>
                  {analytics.overview.usersTrend > 0 ? <div className="flex items-center text-green-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>+{analytics.overview.usersTrend}%</span>
                    </div> : <div className="flex items-center text-red-600 text-sm">
                      <TrendingDown className="h-4 w-4 mr-1" />
                      <span>{analytics.overview.usersTrend}%</span>
                    </div>}
                </div>
                <p className="text-sm text-gray-500">Utilisateurs</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatNumber(analytics.overview.uniqueUsers)}
                </p>
              </button>
              <button className={`bg-white rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow ${selectedMetric === 'revenue' ? 'ring-2 ring-purple-500' : ''}`} onClick={() => setSelectedMetric('revenue')}>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-purple-100">
                    <DollarSign className="h-5 w-5 text-purple-600" />
                  </div>
                  {analytics.overview.revenueTrend > 0 ? <div className="flex items-center text-green-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>+{analytics.overview.revenueTrend}%</span>
                    </div> : <div className="flex items-center text-red-600 text-sm">
                      <TrendingDown className="h-4 w-4 mr-1" />
                      <span>{analytics.overview.revenueTrend}%</span>
                    </div>}
                </div>
                <p className="text-sm text-gray-500">Revenus</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(analytics.overview.totalRevenue)} TND
                </p>
              </button>
              <button className={`bg-white rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow ${selectedMetric === 'responseTime' ? 'ring-2 ring-yellow-500' : ''}`} onClick={() => setSelectedMetric('responseTime')}>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-yellow-100">
                    <Clock className="h-5 w-5 text-yellow-600" />
                  </div>
                  {analytics.overview.responseTimeTrend < 0 ? <div className="flex items-center text-green-600 text-sm">
                      <TrendingDown className="h-4 w-4 mr-1" />
                      <span>
                        {Math.abs(analytics.overview.responseTimeTrend)}%
                      </span>
                    </div> : <div className="flex items-center text-red-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>+{analytics.overview.responseTimeTrend}%</span>
                    </div>}
                </div>
                <p className="text-sm text-gray-500">Temps de réponse</p>
                <p className="text-2xl font-bold text-gray-900">
                  {analytics.overview.avgResponseTime}
                </p>
              </button>
              <button className={`bg-white rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow ${selectedMetric === 'errorRate' ? 'ring-2 ring-red-500' : ''}`} onClick={() => setSelectedMetric('errorRate')}>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-red-100">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                  </div>
                  {analytics.overview.errorRateTrend < 0 ? <div className="flex items-center text-green-600 text-sm">
                      <TrendingDown className="h-4 w-4 mr-1" />
                      <span>
                        {Math.abs(analytics.overview.errorRateTrend)}%
                      </span>
                    </div> : <div className="flex items-center text-red-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>+{analytics.overview.errorRateTrend}%</span>
                    </div>}
                </div>
                <p className="text-sm text-gray-500">Taux d'erreur</p>
                <p className="text-2xl font-bold text-gray-900">
                  {analytics.overview.errorRate}%
                </p>
              </button>
            </div>
            {/* Main Chart */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">
                  {selectedMetric === 'apiCalls' && 'Appels API'}
                  {selectedMetric === 'users' && 'Utilisateurs actifs'}
                  {selectedMetric === 'revenue' && 'Revenus'}
                  {selectedMetric === 'responseTime' && 'Temps de réponse moyen'}
                  {selectedMetric === 'errorRate' && "Taux d'erreur"}
                </h2>
                <div className="flex items-center text-sm text-gray-500">
                  <Info className="h-4 w-4 mr-1" />
                  <span>Évolution sur la période sélectionnée</span>
                </div>
              </div>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  {selectedMetric === 'apiCalls' ? <AreaChart data={analytics.timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{
                    fontSize: 12
                  }} tickMargin={10} />
                      <YAxis tick={{
                    fontSize: 12
                  }} width={60} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="apiCalls" name="Appels API" stroke={COLORS.blue} fill={COLORS.blue} fillOpacity={0.6} />
                    </AreaChart> : selectedMetric === 'users' ? <LineChart data={analytics.timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{
                    fontSize: 12
                  }} tickMargin={10} />
                      <YAxis tick={{
                    fontSize: 12
                  }} width={40} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="users" name="Utilisateurs" stroke={COLORS.green} strokeWidth={2} dot={false} activeDot={{
                    r: 6
                  }} />
                    </LineChart> : selectedMetric === 'revenue' ? <AreaChart data={analytics.timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{
                    fontSize: 12
                  }} tickMargin={10} />
                      <YAxis tickFormatter={value => `${value} TND`} tick={{
                    fontSize: 12
                  }} width={70} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="revenue" name="Revenus" stroke={COLORS.purple} fill={COLORS.purple} fillOpacity={0.6} />
                    </AreaChart> : selectedMetric === 'responseTime' ? <LineChart data={analytics.timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{
                    fontSize: 12
                  }} tickMargin={10} />
                      <YAxis tickFormatter={value => `${value}ms`} tick={{
                    fontSize: 12
                  }} width={60} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="avgResponseTime" name="Temps de réponse" stroke={COLORS.yellow} strokeWidth={2} dot={false} activeDot={{
                    r: 6
                  }} />
                    </LineChart> : <LineChart data={analytics.timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{
                    fontSize: 12
                  }} tickMargin={10} />
                      <YAxis tickFormatter={value => `${value}%`} tick={{
                    fontSize: 12
                  }} width={50} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="errorRate" name="Taux d'erreur" stroke={COLORS.red} strokeWidth={2} dot={false} activeDot={{
                    r: 6
                  }} />
                    </LineChart>}
                </ResponsiveContainer>
              </div>
            </div>
            {/* Geographic Distribution and Subscription Plans */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Globe className="h-5 w-5 text-blue-600 mr-2" />
                    Répartition géographique
                  </h2>
                </div>
                <div className="space-y-4">
                  {analytics.geographicData.map((country, index) => <div key={index}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-700">
                          {country.country}
                        </span>
                        <div className="text-right">
                          <span className="text-sm font-medium text-gray-900">
                            {formatNumber(country.users)} utilisateurs
                          </span>
                          <span className="text-xs text-gray-500 ml-2">
                            {formatCurrency(country.revenue)} TND
                          </span>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="h-2 rounded-full bg-blue-600" style={{
                      width: `${country.percentage}%`
                    }}></div>
                      </div>
                    </div>)}
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Target className="h-5 w-5 text-purple-600 mr-2" />
                    Répartition par plan
                  </h2>
                </div>
                <div className="h-64 flex items-center justify-center mb-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={analytics.subscriptionData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="subscribers" nameKey="planName" label={({
                      name,
                      percent
                    }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                        {analytics.subscriptionData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS.pieColors[index % COLORS.pieColors.length]} />)}
                      </Pie>
                      <Tooltip formatter={value => formatNumber(Number(value))} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2">
                  {analytics.subscriptionData.map((plan, index) => <div key={index} className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full mr-2" style={{
                      backgroundColor: COLORS.pieColors[index % COLORS.pieColors.length]
                    }}></div>
                        <span className="text-gray-700">{plan.planName}</span>
                      </div>
                      <span className="font-medium text-gray-900">
                        {formatNumber(plan.subscribers)} abonnés
                      </span>
                    </div>)}
                </div>
              </div>
            </div>
            {/* Endpoints Performance */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Zap className="h-5 w-5 text-yellow-600 mr-2" />
                Performance des endpoints
              </h2>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Endpoint
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Appels
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Temps de réponse
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Taux d'erreur
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Revenus
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {analytics.endpointData.map((endpoint, index) => <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className={`px-2 py-1 text-xs font-medium rounded mr-2 ${endpoint.method === 'GET' ? 'bg-green-100 text-green-800' : endpoint.method === 'POST' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                              {endpoint.method}
                            </span>
                            <span className="font-medium text-gray-900">
                              {endpoint.endpoint}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(endpoint.calls)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {endpoint.avgResponseTime}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${endpoint.errorRate < 1 ? 'bg-green-100 text-green-800' : endpoint.errorRate < 2 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                            {endpoint.errorRate}%
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatCurrency(endpoint.revenue)} TND
                        </td>
                      </tr>)}
                  </tbody>
                </table>
              </div>
            </div>
            {/* Performance Metrics and Top Users */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Métriques de performance
                </h2>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">P50 (Médian)</span>
                    <span className="font-semibold text-gray-900">
                      {analytics.performanceMetrics.p50ResponseTime}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">P95</span>
                    <span className="font-semibold text-gray-900">
                      {analytics.performanceMetrics.p95ResponseTime}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">P99</span>
                    <span className="font-semibold text-gray-900">
                      {analytics.performanceMetrics.p99ResponseTime}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">Uptime</span>
                    <span className="font-semibold text-green-600">
                      {analytics.performanceMetrics.uptime}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">
                      Taux de succès
                    </span>
                    <span className="font-semibold text-green-600">
                      {analytics.overview.successRate}%
                    </span>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Top utilisateurs
                </h2>
                <div className="space-y-3">
                  {analytics.topUsers.map((user, index) => <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                          <span className="text-blue-600 font-medium">
                            {index + 1}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {user.username}
                          </p>
                          <p className="text-xs text-gray-500">
                            {formatNumber(user.apiCalls)} appels
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-gray-900">
                          {formatCurrency(user.revenue)} TND
                        </p>
                        <p className="text-xs text-gray-500">
                          Actif le {formatDate(user.lastActive)}
                        </p>
                      </div>
                    </div>)}
                </div>
              </div>
            </div>
            {/* Insights */}
            <div className="bg-blue-50 rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold text-blue-900 mb-4">
                Insights et recommandations
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">
                        Croissance forte
                      </h3>
                      <p className="text-sm text-gray-600">
                        Vos appels API ont augmenté de{' '}
                        {analytics.overview.apiCallsTrend}% ce mois-ci.
                        Excellente performance !
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                      <Clock className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">
                        Performance optimale
                      </h3>
                      <p className="text-sm text-gray-600">
                        Votre temps de réponse moyen de{' '}
                        {analytics.overview.avgResponseTime} est excellent.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                      <Target className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">
                        Opportunité
                      </h3>
                      <p className="text-sm text-gray-600">
                        67% de vos utilisateurs sont sur le plan gratuit.
                        Considérez des offres promotionnelles.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>;
}