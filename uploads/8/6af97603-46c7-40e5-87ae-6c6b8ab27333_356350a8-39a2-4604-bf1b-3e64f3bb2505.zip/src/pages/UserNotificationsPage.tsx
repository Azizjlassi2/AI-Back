import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { UserDashboardHeader } from '../components/user-dashboard/UserDashboardHeader';
import { UserDashboardSidebar } from '../components/user-dashboard/UserDashboardSidebar';
import { Bell, Info, AlertTriangle, CheckCircle, AlertCircle, Check, Trash2, CheckCheck, Filter } from 'lucide-react';
import { Notification } from './UserDashboardPage';
interface GroupedNotifications {
  today: Notification[];
  yesterday: Notification[];
  thisWeek: Notification[];
  older: Notification[];
}
type FilterType = 'all' | 'unread' | 'read';
export function UserNotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    // Fetch notifications from localStorage or API
    const fetchNotifications = async () => {
      setIsLoading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        // Mock notifications data
        const mockNotifications: Notification[] = [{
          id: 1,
          type: 'WARNING',
          title: "Limite d'utilisation proche",
          message: 'Vous avez utilisé 80% de votre quota mensuel pour ArabicBERT.',
          date: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          read: false,
          link: '/usage/models/1'
        }, {
          id: 2,
          type: 'SUCCESS',
          title: 'Paiement réussi',
          message: "Votre paiement pour l'abonnement à TunBERT a été traité avec succès.",
          date: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
          read: false,
          link: '/billing/invoices/INV-2024-0002'
        }, {
          id: 3,
          type: 'INFO',
          title: 'Nouvelle fonctionnalité disponible',
          message: 'ArabicBERT a été mis à jour avec de nouvelles fonctionnalités.',
          date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
          read: true,
          link: '/models/1'
        }, {
          id: 4,
          type: 'ERROR',
          title: 'Erreur API détectée',
          message: 'Des erreurs ont été détectées dans vos appels API récents.',
          date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
          read: false,
          link: '/usage/models/1'
        }, {
          id: 5,
          type: 'SUCCESS',
          title: 'Abonnement renouvelé',
          message: 'Votre abonnement à ArabicBERT a été renouvelé automatiquement.',
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          read: true,
          link: '/user/subscriptions'
        }, {
          id: 6,
          type: 'INFO',
          title: 'Mise à jour de sécurité',
          message: 'Nous avons mis à jour nos politiques de sécurité.',
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          read: true,
          link: '/docs/security'
        }, {
          id: 7,
          type: 'WARNING',
          title: 'Expiration prochaine',
          message: 'Votre abonnement à FrenchNLP expire dans 7 jours.',
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          read: true,
          link: '/user/subscriptions'
        }, {
          id: 8,
          type: 'INFO',
          title: 'Nouveau modèle disponible',
          message: 'Découvrez notre nouveau modèle TunisianDialectBERT.',
          date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
          read: true,
          link: '/models'
        }];
        setNotifications(mockNotifications);
      } catch (error) {
        console.error('Error fetching notifications:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchNotifications();
  }, []);
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'INFO':
        return <Info className="h-5 w-5 text-blue-500" />;
      case 'WARNING':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'SUCCESS':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'ERROR':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays === 0) {
      const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
      if (diffHours === 0) {
        const diffMinutes = Math.floor(diffTime / (1000 * 60));
        return `Il y a ${diffMinutes} minute${diffMinutes > 1 ? 's' : ''}`;
      }
      return `Il y a ${diffHours} heure${diffHours > 1 ? 's' : ''}`;
    } else if (diffDays === 1) {
      return 'Hier';
    } else if (diffDays < 7) {
      return `Il y a ${diffDays} jour${diffDays > 1 ? 's' : ''}`;
    } else {
      return date.toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
    }
  };
  const groupNotificationsByDate = (notifs: Notification[]): GroupedNotifications => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    return notifs.reduce((groups, notification) => {
      const notifDate = new Date(notification.date);
      const notifDay = new Date(notifDate.getFullYear(), notifDate.getMonth(), notifDate.getDate());
      if (notifDay.getTime() === today.getTime()) {
        groups.today.push(notification);
      } else if (notifDay.getTime() === yesterday.getTime()) {
        groups.yesterday.push(notification);
      } else if (notifDate >= weekAgo) {
        groups.thisWeek.push(notification);
      } else {
        groups.older.push(notification);
      }
      return groups;
    }, {
      today: [],
      yesterday: [],
      thisWeek: [],
      older: []
    } as GroupedNotifications);
  };
  const filteredNotifications = notifications.filter(notification => {
    if (activeFilter === 'unread') return !notification.read;
    if (activeFilter === 'read') return notification.read;
    return true;
  });
  const groupedNotifications = groupNotificationsByDate(filteredNotifications);
  const unreadCount = notifications.filter(n => !n.read).length;
  const markAsRead = (notificationId: number) => {
    setNotifications(prev => prev.map(n => n.id === notificationId ? {
      ...n,
      read: true
    } : n));
  };
  const markAsUnread = (notificationId: number) => {
    setNotifications(prev => prev.map(n => n.id === notificationId ? {
      ...n,
      read: false
    } : n));
  };
  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({
      ...n,
      read: true
    })));
  };
  const deleteNotification = (notificationId: number) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
  };
  const deleteReadNotifications = () => {
    setNotifications(prev => prev.filter(n => !n.read));
  };
  const renderNotificationGroup = (title: string, notifs: Notification[]) => {
    if (notifs.length === 0) return null;
    return <div className="mb-8">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
          {title}
        </h3>
        <div className="space-y-2">
          {notifs.map(notification => <div key={notification.id} className={`bg-white rounded-lg border transition-colors ${!notification.read ? 'border-blue-200 bg-blue-50' : 'border-gray-200'}`}>
              <div className="p-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3 mt-0.5">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link to={notification.link || '#'} className="block group" onClick={() => markAsRead(notification.id)}>
                      <p className="text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                        {notification.title}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-400 mt-2">
                        {formatDate(notification.date)}
                      </p>
                    </Link>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    {!notification.read ? <button onClick={() => markAsRead(notification.id)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Marquer comme lu">
                        <Check className="h-4 w-4" />
                      </button> : <button onClick={() => markAsUnread(notification.id)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Marquer comme non lu">
                        <Bell className="h-4 w-4" />
                      </button>}
                    <button onClick={() => deleteNotification(notification.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Supprimer">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>)}
        </div>
      </div>;
  };
  const renderEmptyState = () => {
    const emptyMessages = {
      all: {
        title: 'Aucune notification',
        message: "Vous n'avez aucune notification pour le moment."
      },
      unread: {
        title: 'Aucune notification non lue',
        message: 'Toutes vos notifications ont été lues.'
      },
      read: {
        title: 'Aucune notification lue',
        message: "Vous n'avez pas encore lu de notifications."
      }
    };
    const {
      title,
      message
    } = emptyMessages[activeFilter];
    return <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
        <div className="flex justify-center mb-4">
          <div className="p-3 bg-gray-100 rounded-full">
            <Bell className="h-8 w-8 text-gray-400" />
          </div>
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600">{message}</p>
      </div>;
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50">
      <UserDashboardHeader user={{
      id: 1,
      name: 'Mohamed Ben Salem',
      email: 'mohamed.bensalem@example.com',
      avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=MBS'
    }} notifications={notifications} onMarkAsRead={markAsRead} />
      <div className="flex">
        <UserDashboardSidebar activeTab="notifications" onTabChange={() => {}} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-4xl">
            {/* Header */}
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Notifications
              </h1>
              <p className="text-gray-600">
                Gérez toutes vos notifications en un seul endroit
              </p>
            </div>

            {/* Filters and Actions */}
            <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                {/* Filter Tabs */}
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4 text-gray-400" />
                  <div className="flex bg-gray-100 rounded-lg p-1">
                    <button onClick={() => setActiveFilter('all')} className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${activeFilter === 'all' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}>
                      Toutes ({notifications.length})
                    </button>
                    <button onClick={() => setActiveFilter('unread')} className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${activeFilter === 'unread' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}>
                      Non lues ({unreadCount})
                    </button>
                    <button onClick={() => setActiveFilter('read')} className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${activeFilter === 'read' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}>
                      Lues ({notifications.length - unreadCount})
                    </button>
                  </div>
                </div>

                {/* Bulk Actions */}
                <div className="flex items-center space-x-2">
                  {unreadCount > 0 && <button onClick={markAllAsRead} className="flex items-center px-3 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                      <CheckCheck className="h-4 w-4 mr-2" />
                      Tout marquer comme lu
                    </button>}
                  {notifications.some(n => n.read) && <button onClick={deleteReadNotifications} className="flex items-center px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Supprimer les lues
                    </button>}
                </div>
              </div>
            </div>

            {/* Notifications List */}
            {filteredNotifications.length === 0 ? renderEmptyState() : <div>
                {renderNotificationGroup("Aujourd'hui", groupedNotifications.today)}
                {renderNotificationGroup('Hier', groupedNotifications.yesterday)}
                {renderNotificationGroup('Cette semaine', groupedNotifications.thisWeek)}
                {renderNotificationGroup('Plus anciennes', groupedNotifications.older)}
              </div>}
          </div>
        </main>
      </div>
    </div>;
}