import React, { useState, Children } from 'react';
import { Link } from 'react-router-dom';
import { Shield, Calendar, ArrowRight, FileText } from 'lucide-react';
export function PrivacyPage() {
  const [activeSection, setActiveSection] = useState('introduction');
  const sections = [{
    id: 'introduction',
    title: 'Introduction'
  }, {
    id: 'data-collection',
    title: 'Données collectées'
  }, {
    id: 'data-usage',
    title: 'Utilisation des données'
  }, {
    id: 'data-sharing',
    title: 'Partage des données'
  }, {
    id: 'data-security',
    title: 'Sécurité des données'
  }, {
    id: 'cookies',
    title: 'Cookies et technologies similaires'
  }, {
    id: 'user-rights',
    title: 'Vos droits'
  }, {
    id: 'children',
    title: 'Protection des mineurs'
  }, {
    id: 'international',
    title: 'Transferts internationaux'
  }, {
    id: 'changes',
    title: 'Modifications de la politique'
  }, {
    id: 'contact',
    title: 'Contact'
  }];
  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  };
  return <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
            <div className="flex items-center mb-4">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-4xl font-bold text-gray-900">
                Politique de confidentialité
              </h1>
            </div>
            <div className="flex items-center text-gray-600 mb-6">
              <Calendar className="h-4 w-4 mr-2" />
              <span className="text-sm">
                Dernière mise à jour : 15 janvier 2025
              </span>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Chez AI+, nous prenons la protection de vos données personnelles
              très au sérieux. Cette politique de confidentialité explique
              comment nous collectons, utilisons, partageons et protégeons vos
              informations.
            </p>
            <div className="mt-6 pt-6 border-t border-gray-200">
              <Link to="/terms" className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium">
                <FileText className="h-4 w-4 mr-2" />
                Consulter nos Conditions d'utilisation
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </div>
          </div>
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Table of Contents - Sidebar */}
            <aside className="lg:w-64 flex-shrink-0">
              <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Sommaire
                </h2>
                <nav className="space-y-2">
                  {sections.map(section => <button key={section.id} onClick={() => scrollToSection(section.id)} className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${activeSection === section.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}>
                      {section.title}
                    </button>)}
                </nav>
              </div>
            </aside>
            {/* Main Content */}
            <main className="flex-1 bg-white rounded-xl shadow-sm p-8">
              <div className="prose prose-blue max-w-none">
                {/* Introduction */}
                <section id="introduction" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    1. Introduction
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Cette Politique de confidentialité décrit comment AI+
                    ("nous", "notre" ou "nos") collecte, utilise et protège vos
                    informations personnelles lorsque vous utilisez notre
                    plateforme.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    En utilisant AI+, vous acceptez les pratiques décrites dans
                    cette politique. Si vous n'acceptez pas cette politique,
                    veuillez ne pas utiliser nos services.
                  </p>
                </section>
                {/* Data Collection */}
                <section id="data-collection" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    2. Données collectées
                  </h2>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    2.1 Informations que vous nous fournissez
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Nous collectons les informations que vous nous fournissez
                    directement :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Informations de compte :</strong> Nom, adresse
                      email, mot de passe, type de compte (client ou
                      développeur)
                    </li>
                    <li>
                      <strong>Informations de profil :</strong> Photo de profil,
                      biographie, entreprise, titre du poste
                    </li>
                    <li>
                      <strong>Informations de paiement :</strong> Informations
                      de carte bancaire, adresse de facturation, historique de
                      transactions
                    </li>
                    <li>
                      <strong>Communications :</strong> Messages que vous nous
                      envoyez, commentaires, retours
                    </li>
                  </ul>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    2.2 Informations collectées automatiquement
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Lorsque vous utilisez AI+, nous collectons automatiquement :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Données d'utilisation :</strong> Pages visitées,
                      modèles utilisés, temps passé sur la plateforme
                    </li>
                    <li>
                      <strong>Données techniques :</strong> Adresse IP, type de
                      navigateur, système d'exploitation, identifiants
                      d'appareil
                    </li>
                    <li>
                      <strong>Données d'API :</strong> Appels API effectués,
                      timestamps, réponses
                    </li>
                    <li>
                      <strong>Cookies et technologies similaires :</strong>{' '}
                      Informations stockées via cookies et technologies de suivi
                    </li>
                  </ul>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    2.3 Informations provenant de tiers
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    Nous pouvons recevoir des informations vous concernant de la
                    part de services tiers tels que les processeurs de paiement
                    (Konnect.network) et les services d'authentification.
                  </p>
                </section>
                {/* Data Usage */}
                <section id="data-usage" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    3. Utilisation des données
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Nous utilisons vos informations pour :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Fournir nos services :</strong> Créer et gérer
                      votre compte, traiter les paiements, fournir l'accès aux
                      modèles et API
                    </li>
                    <li>
                      <strong>Améliorer nos services :</strong> Analyser
                      l'utilisation, développer de nouvelles fonctionnalités,
                      corriger les bugs
                    </li>
                    <li>
                      <strong>Communication :</strong> Vous envoyer des
                      notifications importantes, répondre à vos demandes,
                      envoyer des newsletters (avec votre consentement)
                    </li>
                    <li>
                      <strong>Sécurité :</strong> Détecter et prévenir la
                      fraude, protéger nos systèmes, respecter nos obligations
                      légales
                    </li>
                    <li>
                      <strong>Personnalisation :</strong> Personnaliser votre
                      expérience, recommander des modèles pertinents
                    </li>
                    <li>
                      <strong>Marketing :</strong> Vous informer de nos
                      nouvelles fonctionnalités et offres (avec votre
                      consentement)
                    </li>
                  </ul>
                </section>
                {/* Data Sharing */}
                <section id="data-sharing" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    4. Partage des données
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Nous ne vendons jamais vos données personnelles. Nous
                    pouvons partager vos informations dans les cas suivants :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Prestataires de services :</strong> Nous
                      partageons des données avec des prestataires qui nous
                      aident à fournir nos services (hébergement, paiement,
                      analytics)
                    </li>
                    <li>
                      <strong>Développeurs de modèles :</strong> Si vous
                      utilisez un modèle, le développeur peut recevoir des
                      statistiques d'utilisation anonymisées
                    </li>
                    <li>
                      <strong>Conformité légale :</strong> Nous pouvons
                      divulguer des informations si requis par la loi ou pour
                      protéger nos droits
                    </li>
                    <li>
                      <strong>Transfert d'entreprise :</strong> En cas de
                      fusion, acquisition ou vente d'actifs, vos données peuvent
                      être transférées
                    </li>
                    <li>
                      <strong>Avec votre consentement :</strong> Nous pouvons
                      partager vos données avec votre autorisation explicite
                    </li>
                  </ul>
                </section>
                {/* Data Security */}
                <section id="data-security" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    5. Sécurité des données
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Nous mettons en œuvre des mesures de sécurité techniques et
                    organisationnelles pour protéger vos données :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>Chiffrement des données en transit (HTTPS/TLS)</li>
                    <li>Chiffrement des données sensibles au repos</li>
                    <li>
                      Contrôles d'accès stricts et authentification à deux
                      facteurs
                    </li>
                    <li>Surveillance et détection des intrusions</li>
                    <li>Sauvegardes régulières</li>
                    <li>Audits de sécurité périodiques</li>
                  </ul>
                  <p className="text-gray-700 leading-relaxed">
                    Cependant, aucune méthode de transmission sur Internet ou de
                    stockage électronique n'est 100% sécurisée. Nous ne pouvons
                    garantir une sécurité absolue.
                  </p>
                </section>
                {/* Cookies */}
                <section id="cookies" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    6. Cookies et technologies similaires
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Nous utilisons des cookies et technologies similaires pour :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Cookies essentiels :</strong> Nécessaires au
                      fonctionnement de la plateforme (authentification,
                      sécurité)
                    </li>
                    <li>
                      <strong>Cookies de performance :</strong> Nous aident à
                      comprendre comment vous utilisez la plateforme
                    </li>
                    <li>
                      <strong>Cookies de fonctionnalité :</strong> Mémorisent
                      vos préférences et paramètres
                    </li>
                    <li>
                      <strong>Cookies marketing :</strong> Utilisés pour vous
                      montrer des publicités pertinentes (avec votre
                      consentement)
                    </li>
                  </ul>
                  <p className="text-gray-700 leading-relaxed">
                    Vous pouvez gérer vos préférences de cookies dans les
                    paramètres de votre navigateur. Notez que désactiver
                    certains cookies peut affecter le fonctionnement de la
                    plateforme.
                  </p>
                </section>
                {/* User Rights */}
                <section id="user-rights" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    7. Vos droits
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Vous disposez des droits suivants concernant vos données
                    personnelles :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Droit d'accès :</strong> Vous pouvez demander une
                      copie de vos données personnelles
                    </li>
                    <li>
                      <strong>Droit de rectification :</strong> Vous pouvez
                      corriger vos données inexactes ou incomplètes
                    </li>
                    <li>
                      <strong>Droit à l'effacement :</strong> Vous pouvez
                      demander la suppression de vos données dans certaines
                      circonstances
                    </li>
                    <li>
                      <strong>Droit à la portabilité :</strong> Vous pouvez
                      recevoir vos données dans un format structuré
                    </li>
                    <li>
                      <strong>Droit d'opposition :</strong> Vous pouvez vous
                      opposer au traitement de vos données à des fins marketing
                    </li>
                    <li>
                      <strong>Droit de limitation :</strong> Vous pouvez
                      demander la limitation du traitement de vos données
                    </li>
                  </ul>
                  <p className="text-gray-700 leading-relaxed">
                    Pour exercer ces droits, contactez-nous à privacy@aiplus.tn.
                    Nous répondrons à votre demande dans les 30 jours.
                  </p>
                </section>
                {/* Children */}
                <section id="children" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    8. Protection des mineurs
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    AI+ n'est pas destiné aux personnes de moins de 18 ans. Nous
                    ne collectons pas sciemment d'informations personnelles
                    auprès de mineurs.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    Si vous êtes parent ou tuteur et pensez que votre enfant
                    nous a fourni des informations personnelles, veuillez nous
                    contacter immédiatement pour que nous puissions supprimer
                    ces informations.
                  </p>
                </section>
                {/* International Transfers */}
                <section id="international" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    9. Transferts internationaux de données
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Vos données peuvent être transférées et stockées sur des
                    serveurs situés en dehors de la Tunisie, notamment dans
                    l'Union européenne et aux États-Unis.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    Nous nous assurons que ces transferts sont effectués
                    conformément aux lois applicables sur la protection des
                    données et que des garanties appropriées sont en place pour
                    protéger vos informations.
                  </p>
                </section>
                {/* Changes */}
                <section id="changes" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    10. Modifications de la politique
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Nous pouvons modifier cette Politique de confidentialité de
                    temps en temps. Les modifications importantes seront
                    notifiées par email ou via une notification sur la
                    plateforme.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    La date de "Dernière mise à jour" en haut de cette page
                    indique quand la politique a été révisée pour la dernière
                    fois. Votre utilisation continue de AI+ après ces
                    modifications constitue votre acceptation de la politique
                    révisée.
                  </p>
                </section>
                {/* Contact */}
                <section id="contact" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    11. Contact
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Pour toute question concernant cette Politique de
                    confidentialité ou vos données personnelles, veuillez nous
                    contacter :
                  </p>
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                    <p className="text-gray-800 mb-2">
                      <strong>Email :</strong> privacy@aiplus.tn
                    </p>
                    <p className="text-gray-800 mb-2">
                      <strong>
                        Responsable de la protection des données :
                      </strong>{' '}
                      dpo@aiplus.tn
                    </p>
                    <p className="text-gray-800 mb-2">
                      <strong>Téléphone :</strong> +216 71 123 456
                    </p>
                    <p className="text-gray-800">
                      <strong>Adresse :</strong> Tunis, Tunisie
                    </p>
                  </div>
                </section>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>;
}