import React from 'react';
import { motion } from 'framer-motion';
import { DashboardHeader } from '../components/dashboard/DashboardHeader';
import { DashboardSidebar } from '../components/dashboard/DashboardSidebar';
import { StatCards } from '../components/dashboard/StatCards';
import { RevenueChart } from '../components/dashboard/RevenueChart';
import { VisitorsChart } from '../components/dashboard/VisitorsChart';
import { RecentModels } from '../components/dashboard/RecentModels';
import { RecentDatasets } from '../components/dashboard/RecentDatasets';
import { ModerationTable } from '../components/dashboard/ModerationTable';
import { InvoicesTable } from '../components/dashboard/InvoicesTable';
import { TopModelsChart } from '../components/dashboard/TopModelsChart';
import { TopDatasetsChart } from '../components/dashboard/TopDatasetsChart';
import { SystemHealthCard } from '../components/dashboard/SystemHealthCard';
import { QuickActionsCard } from '../components/dashboard/QuickActionsCard';
export function AdminDashboardPage() {
  return <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-gray-100">
      <DashboardHeader />
      <div className="flex">
        <DashboardSidebar />
        <main className="flex-1 p-4 md:p-8 w-full overflow-x-hidden">
          <div className="max-w-8xl mx-auto space-y-6 md:space-y-8">
            {/* Welcome Section */}
            <motion.div initial={{
            opacity: 0,
            y: -20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.5
          }} className="mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-100 mb-2">
                Tableau de Bord
              </h1>
              <p className="text-gray-400">
                Bienvenue sur votre dashboard administrateur
              </p>
            </motion.div>
            {/* Stats Overview */}
            <StatCards />
            {/* System Health and Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
              <div className="lg:col-span-2">
                <SystemHealthCard />
              </div>
              <QuickActionsCard />
            </div>
            {/* Main Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
              <div className="lg:col-span-2 space-y-6 md:space-y-8">
                <RevenueChart />
                <VisitorsChart />
              </div>
              <div className="space-y-6 md:space-y-8">
                <TopModelsChart />
                <TopDatasetsChart />
              </div>
            </div>
            {/* Recent Activity Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
              <RecentModels />
              <RecentDatasets />
            </div>
            {/* Tables Section */}
            <div className="grid grid-cols-1 gap-6 md:gap-8">
              <ModerationTable />
              <InvoicesTable />
            </div>
          </div>
        </main>
      </div>
    </div>;
}