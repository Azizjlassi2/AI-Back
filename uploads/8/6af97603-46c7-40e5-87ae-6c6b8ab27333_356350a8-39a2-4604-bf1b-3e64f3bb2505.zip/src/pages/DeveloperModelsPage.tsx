import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Plus, Download, MoreVertical, Edit, Trash2, Eye, BarChart2, Globe, Lock, AlertTriangle, X, Bot } from 'lucide-react';
import { DeveloperDashboardHeader } from '../components/developer-dashboard/DeveloperDashboardHeader';
import { DeveloperDashboardSidebar } from '../components/developer-dashboard/DeveloperDashboardSidebar';
enum Visibility {
  PUBLIC = 'PUBLIC',
  PRIVATE = 'PRIVATE',
}
interface Model {
  id: number;
  name: string;
  description: string;
  version: string;
  visibility: Visibility;
  status: 'PUBLISHED' | 'DRAFT' | 'UNDER_REVIEW' | 'REJECTED';
  users: number;
  apiCalls: number;
  revenue: number;
  lastUpdated: string;
}
export function DeveloperModelsPage() {
  const [activeTab, setActiveTab] = useState('models');
  const [models, setModels] = useState<Model[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [showDropdown, setShowDropdown] = useState<number | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [modelToDelete, setModelToDelete] = useState<Model | null>(null);
  useEffect(() => {
    const fetchModels = async () => {
      setIsLoading(true);
      try {
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 800));
        // Mock data
        const mockModels: Model[] = [{
          id: 1,
          name: 'ArabicBERT',
          description: "Modèle BERT pré-entraîné pour l'arabe standard et dialectal",
          version: '2.1.0',
          visibility: Visibility.PUBLIC,
          status: 'PUBLISHED',
          users: 1250,
          apiCalls: 78500,
          revenue: 15250.75,
          lastUpdated: '2023-12-01'
        }, {
          id: 2,
          name: 'TunBERT',
          description: 'Modèle spécialisé pour le dialecte tunisien',
          version: '1.5.2',
          visibility: Visibility.PUBLIC,
          status: 'PUBLISHED',
          users: 850,
          apiCalls: 42300,
          revenue: 8750.5,
          lastUpdated: '2023-11-15'
        }, {
          id: 3,
          name: 'MedicalVision AI',
          description: "Analyse d'images médicales pour le diagnostic assisté",
          version: '1.0.0',
          visibility: Visibility.PUBLIC,
          status: 'PUBLISHED',
          users: 320,
          apiCalls: 18200,
          revenue: 4250.25,
          lastUpdated: '2024-01-10'
        }, {
          id: 4,
          name: 'TunisianNER',
          description: "Reconnaissance d'entités nommées pour le dialecte tunisien",
          version: '0.9.5',
          visibility: Visibility.PUBLIC,
          status: 'UNDER_REVIEW',
          users: 180,
          apiCalls: 9800,
          revenue: 2100.0,
          lastUpdated: '2024-01-05'
        }, {
          id: 5,
          name: 'SentimentAI',
          description: "Analyse de sentiment pour l'arabe et le français",
          version: '1.2.0',
          visibility: Visibility.PUBLIC,
          status: 'PUBLISHED',
          users: 145,
          apiCalls: 7200,
          revenue: 1850.5,
          lastUpdated: '2023-12-20'
        }, {
          id: 6,
          name: 'FinBERT-Tunisie',
          description: "Modèle pour l'analyse de textes financiers en contexte tunisien",
          version: '0.8.0',
          visibility: Visibility.PRIVATE,
          status: 'DRAFT',
          users: 0,
          apiCalls: 350,
          revenue: 0,
          lastUpdated: '2024-01-15'
        }, {
          id: 7,
          name: 'LegalAI',
          description: 'Analyse de textes juridiques en arabe et français',
          version: '0.7.0',
          visibility: Visibility.PRIVATE,
          status: 'DRAFT',
          users: 0,
          apiCalls: 120,
          revenue: 0,
          lastUpdated: '2024-01-18'
        }];
        setModels(mockModels);
      } catch (error) {
        console.error('Error fetching models:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchModels();
  }, []);
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  const handleStatusFilterChange = (status: string | null) => {
    setStatusFilter(status);
  };
  const toggleDropdown = (modelId: number | null) => {
    setShowDropdown(showDropdown === modelId ? null : modelId);
  };
  const openDeleteModal = (model: Model) => {
    setModelToDelete(model);
    setIsDeleteModalOpen(true);
    setShowDropdown(null); // Close dropdown when opening modal
  };
  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setModelToDelete(null);
  };
  const confirmDelete = () => {
    if (modelToDelete) {
      // In a real app, this would be an API call to delete the model
      setModels(models.filter(model => model.id !== modelToDelete.id));
      closeDeleteModal();
      // Here you would typically show a success notification
    }
  };
  const formatNumber = (num: number): string => {
    return num.toLocaleString('fr-FR');
  };
  const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('fr-FR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  const filteredModels = models.filter(model => {
    const matchesSearch = model.name.toLowerCase().includes(searchQuery.toLowerCase()) || model.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = !statusFilter || model.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  return <div className="min-h-screen bg-gray-50">
      <DeveloperDashboardHeader />
      <div className="flex">
        <DeveloperDashboardSidebar activeTab={activeTab} onTabChange={handleTabChange} />
        <main className="flex-1 p-6">
          <div className="container mx-auto max-w-7xl">
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-bold text-gray-900 mb-4 md:mb-0">
                Mes modèles
              </h1>
              <Link to="/developer/models/add" className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Ajouter un modèle
              </Link>
            </div>
            {/* Filters and Search */}
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input type="text" placeholder="Rechercher des modèles..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" value={searchQuery} onChange={handleSearchChange} />
                </div>
                <div className="flex gap-2">
                  <div className="relative"></div>
                  <button className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 hover:bg-gray-50">
                    <Download className="h-5 w-5 mr-2" />
                    Exporter
                  </button>
                </div>
              </div>
            </div>
            {/* Models Table */}
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              {isLoading ? <div className="p-8 flex justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-600"></div>
                </div> : filteredModels.length === 0 ? <div className="p-8 text-center">
                  <div className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Aucun modèle trouvé
                  </h3>
                  <p className="text-gray-500 mb-4">
                    {searchQuery ? `Aucun résultat pour "${searchQuery}"` : "Vous n'avez pas encore de modèles ou aucun modèle ne correspond aux filtres sélectionnés."}
                  </p>
                  <Link to="/developer/models/add" className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Ajouter un modèle
                  </Link>
                </div> : <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Modèle
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Version
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Utilisateurs
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Appels API
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Revenus
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Mise à jour
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredModels.map(model => <tr key={model.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center mr-3">
                                <Bot className="h-5 w-5 text-blue-600" />
                              </div>
                              <div>
                                <div className="flex items-center">
                                  <Link to={`/developer/models/${model.id}`} className="text-sm font-medium text-gray-900 hover:text-blue-600">
                                    {model.name}
                                  </Link>
                                  {model.visibility === Visibility.PUBLIC ? <Globe className="h-4 w-4 text-green-600 ml-2" /> : <Lock className="h-4 w-4 text-gray-400 ml-2" />}
                                </div>
                                <p className="text-xs text-gray-500 mt-1">
                                  {model.description}
                                </p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {model.version}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatNumber(model.users)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatNumber(model.apiCalls)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatCurrency(model.revenue)} TND
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatDate(model.lastUpdated)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium relative">
                            <button className="text-gray-400 hover:text-gray-600" onClick={() => toggleDropdown(model.id)}>
                              <MoreVertical className="h-5 w-5" />
                            </button>
                            {showDropdown === model.id && <div className="absolute right-6 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
                                <Link to={`/developer/models/${model.id}`} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                                  <Eye className="h-4 w-4 mr-2" />
                                  Voir les détails
                                </Link>
                                <Link to={`/developer/models/${model.id}/update`} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                                  <Edit className="h-4 w-4 mr-2" />
                                  Modifier
                                </Link>
                                <Link to={`/developer/models/${model.id}/analytics`} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center">
                                  <BarChart2 className="h-4 w-4 mr-2" />
                                  Analyses
                                </Link>
                                <button className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center" onClick={() => openDeleteModal(model)}>
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Supprimer
                                </button>
                              </div>}
                          </td>
                        </tr>)}
                    </tbody>
                  </table>
                </div>}
            </div>
            {/* Help Box */}
            <div className="mt-6 bg-blue-50 rounded-xl shadow-sm p-6">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-blue-800 mb-1">
                    Conseils pour optimiser vos modèles
                  </h3>
                  <p className="text-blue-700 mb-4">
                    Assurez-vous que vos modèles disposent d'une documentation
                    complète, d'exemples d'utilisation et de plans tarifaires
                    adaptés pour maximiser leur adoption.
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <Link to="/developer/documentation/best-practices" className="inline-flex items-center px-4 py-2 bg-white border border-blue-300 rounded-lg text-blue-700 hover:bg-blue-50">
                      Bonnes pratiques
                    </Link>
                    <Link to="/developer/support" className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                      Contacter le support
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && modelToDelete && <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true" onClick={closeDeleteModal}>
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">
              &#8203;
            </span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                    <AlertTriangle className="h-6 w-6 text-red-600" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-headline">
                      Supprimer le modèle
                    </h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Êtes-vous sûr de vouloir supprimer le modèle{' '}
                        <span className="font-semibold">
                          {modelToDelete.name}
                        </span>{' '}
                        ? Cette action est irréversible et supprimera toutes les
                        données associées, y compris les statistiques
                        d'utilisation et les revenus générés.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button type="button" className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm" onClick={confirmDelete}>
                  Supprimer
                </button>
                <button type="button" className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm" onClick={closeDeleteModal}>
                  Annuler
                </button>
              </div>
            </div>
          </div>
        </div>}
    </div>;
}