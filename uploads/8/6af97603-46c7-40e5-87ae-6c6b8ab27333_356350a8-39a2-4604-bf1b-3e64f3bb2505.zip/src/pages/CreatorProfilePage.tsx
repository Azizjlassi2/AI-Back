import React from 'react';
import { MapPin, Calendar, Star, Download, Tag, ExternalLink, Database, Zap, Bot } from 'lucide-react';
import { Link } from 'react-router-dom';
export function CreatorProfilePage() {
  const creator = {
    name: 'AI Lab Tunisia',
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=AI',
    description: 'Laboratory for Arabic Natural Language Processing Research. We specialize in developing state-of-the-art NLP models for Arabic and Tunisian dialect, with a focus on making AI accessible to the local community.',
    location: 'Tunis, Tunisia',
    website: 'https://ailab-tunisia.org',
    joinedDate: 'Janvier 2022',
    stats: {
      models: 12,
      datasets: 8,
      totalDownloads: '45.2K'
    },
    models: [{
      id: 1,
      name: 'ArabicBERT',
      description: "BERT pré-entraîné pour l'arabe standard moderne et dialectal tunisien, optimisé pour les tâches de classification de texte et d'analyse de sentiment.",
      downloads: '15.2K',
      stars: 234,
      tags: ['NLP', 'Text Classification', 'Sentiment Analysis']
    }, {
      id: 2,
      name: 'TunisianNER',
      description: "Reconnaissance d'entités nommées spécialisée pour le dialecte tunisien, capable d'identifier les personnes, lieux, organisations et autres entités spécifiques au contexte tunisien.",
      downloads: '8.7K',
      stars: 156,
      tags: ['NER', 'Tunisian Dialect', 'NLP']
    }, {
      id: 3,
      name: 'MedicalVision AI',
      description: "Analyse d'images médicales pour le diagnostic assisté, spécialisé dans la détection d'anomalies pulmonaires sur radiographies.",
      downloads: '6.4K',
      stars: 127,
      tags: ['Computer Vision', 'Medical', 'Diagnostic']
    }, {
      id: 4,
      name: 'SentimentAI',
      description: "Analyse de sentiment pour l'arabe et le français, optimisé pour les textes des réseaux sociaux et commentaires en ligne.",
      downloads: '5.9K',
      stars: 98,
      tags: ['Sentiment Analysis', 'Multilingual', 'Social Media']
    }],
    datasets: [{
      id: 1,
      name: 'Tunisian Dialect Corpus',
      description: "Large corpus de textes en dialecte tunisien pour l'entraînement de modèles NLP - 50,000 phrases annotées avec sentiment, thématique et entités.",
      downloads: '12.5K',
      size: '2.3GB',
      type: 'Text',
      tags: ['NLP', 'Tunisian Dialect', 'Corpus']
    }, {
      id: 2,
      name: 'Tunisian News Articles',
      description: "Collection d'articles de presse tunisienne (2010-2023) annotés par thème, sentiment et entités nommées.",
      downloads: '8.7K',
      size: '850MB',
      type: 'Text',
      tags: ['News', 'Arabic', 'Media']
    }, {
      id: 3,
      name: 'Medical Images Tunisia',
      description: "Collection de radiographies pulmonaires annotées provenant d'hôpitaux tunisiens, avec annotations de pathologies.",
      downloads: '6.4K',
      size: '15GB',
      type: 'Images',
      tags: ['Medical', 'Computer Vision', 'Healthcare']
    }, {
      id: 4,
      name: 'Tunisian Audio Commands',
      description: "Enregistrements vocaux de commandes en dialecte tunisien pour l'entraînement de systèmes de reconnaissance vocale.",
      downloads: '5.9K',
      size: '8.2GB',
      type: 'Audio',
      tags: ['Speech', 'Voice Recognition', 'Audio']
    }]
  };
  return <div className="min-h-screen bg-gray-50">
      {/* Hero section with creator info */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            <img src={creator.avatar} alt={creator.name} className="h-32 w-32 rounded-full border-4 border-white shadow-lg" />
            <div className="text-center md:text-left">
              <h1 className="text-3xl md:text-4xl font-bold">{creator.name}</h1>
              <div className="flex flex-col sm:flex-row gap-4 mt-4 justify-center md:justify-start">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  {creator.location}
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Membre depuis {creator.joinedDate}
                </div>
                {creator.website && <a href={creator.website} target="_blank" rel="noopener noreferrer" className="flex items-center hover:underline">
                    <ExternalLink className="h-5 w-5 mr-2" />
                    Site web
                  </a>}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Creator description and stats */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <h2 className="text-xl font-semibold mb-4">À propos</h2>
              <p className="text-gray-600">{creator.description}</p>
            </div>
            <div className="lg:col-span-1">
              <h2 className="text-xl font-semibold mb-4">Statistiques</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <span className="block text-2xl font-bold text-blue-700">
                    {creator.stats.models}
                  </span>
                  <span className="text-sm text-gray-600">Modèles</span>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <span className="block text-2xl font-bold text-blue-700">
                    {creator.stats.datasets}
                  </span>
                  <span className="text-sm text-gray-600">Datasets</span>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center col-span-2">
                  <span className="block text-2xl font-bold text-blue-700">
                    {creator.stats.totalDownloads}
                  </span>
                  <span className="text-sm text-gray-600">Téléchargements</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Models section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center">
            <Bot className="h-6 w-6 text-blue-600 mr-2" />
            Modèles publiés
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {creator.models.map(model => <Link key={model.id} to={`/models/${model.id}`} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                        <Bot className="h-5 w-5 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900">
                        {model.name}
                      </h3>
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Star className="h-5 w-5 text-yellow-500 mr-1" />
                      <span>{model.stars}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4">{model.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {model.tags.map(tag => <span key={tag} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <Tag className="h-3 w-3 mr-1" />
                        {tag}
                      </span>)}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-gray-500">
                      <Zap className="h-4 w-4 mr-1" />
                      {model.downloads} utilisations
                    </div>
                    <span className="text-sm text-blue-600 hover:text-blue-800">
                      Voir le modèle →
                    </span>
                  </div>
                </div>
              </Link>)}
          </div>
        </div>
        {/* Datasets section */}
        <div>
          <h2 className="text-2xl font-bold mb-6 flex items-center">
            <Database className="h-6 w-6 text-green-600 mr-2" />
            Datasets publiés
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {creator.datasets.map(dataset => <Link key={dataset.id} to={`/datasets/${dataset.id}`} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                        <Database className="h-5 w-5 text-green-600" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900">
                        {dataset.name}
                      </h3>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4">{dataset.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {dataset.tags.map(tag => <span key={tag} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <Tag className="h-3 w-3 mr-1" />
                        {tag}
                      </span>)}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Download className="h-4 w-4 mr-1" />
                        {dataset.downloads}
                      </div>
                      <div className="flex items-center">
                        <Database className="h-4 w-4 mr-1" />
                        {dataset.size}
                      </div>
                      <div className="flex items-center">
                        <Tag className="h-4 w-4 mr-1" />
                        {dataset.type}
                      </div>
                    </div>
                    <span className="text-sm text-green-600 hover:text-green-800">
                      Voir le dataset →
                    </span>
                  </div>
                </div>
              </Link>)}
          </div>
        </div>
      </div>
    </div>;
}