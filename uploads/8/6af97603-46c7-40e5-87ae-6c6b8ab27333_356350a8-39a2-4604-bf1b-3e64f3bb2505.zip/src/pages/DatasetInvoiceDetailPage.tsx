import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FileText, Download, Printer, ArrowLeft, Database, Calendar, CreditCard, CheckCircle } from 'lucide-react';
interface DatasetInvoice {
  id: string;
  datasetId: number;
  datasetName: string;
  purchaseDate: string;
  amount: number;
  currency: string;
  status: 'PAID' | 'PENDING' | 'FAILED';
  billingDetails: {
    name: string;
    email: string;
    address: string;
  };
  seller: {
    name: string;
    address: string;
    taxId: string;
  };
}
export function DatasetInvoiceDetailPage() {
  const {
    invoiceId
  } = useParams<{
    invoiceId: string;
  }>();
  const [invoice, setInvoice] = useState<DatasetInvoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    const fetchInvoice = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 800));
        // Mock invoice data
        const mockInvoice: DatasetInvoice = {
          id: invoiceId || 'INV-DS-123456',
          datasetId: 1,
          datasetName: 'Tunisian Dialect Corpus',
          purchaseDate: new Date().toISOString(),
          amount: 149.99,
          currency: 'TND',
          status: 'PAID',
          billingDetails: {
            name: 'Mohamed Ben Salem',
            email: 'mohamed.bensalem@example.com',
            address: '15 Rue de Carthage, Tunis 1000, Tunisie'
          },
          seller: {
            name: 'ANLP Lab',
            address: 'Technopole de Sousse, Sousse 4000, Tunisie',
            taxId: 'TN123456789'
          }
        };
        setInvoice(mockInvoice);
      } catch (err) {
        console.error('Error fetching invoice:', err);
        setError('Une erreur est survenue lors du chargement de la facture');
      } finally {
        setLoading(false);
      }
    };
    fetchInvoice();
  }, [invoiceId]);
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  const handleDownloadInvoice = () => {
    // In a real app, this would download the invoice as PDF
    alert(`Téléchargement de la facture ${invoiceId}`);
  };
  const handlePrintInvoice = () => {
    window.print();
  };
  if (loading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  if (error || !invoice) {
    return <div className="min-h-screen bg-gray-50 p-8">
        <div className="container mx-auto max-w-4xl">
          <div className="bg-white rounded-xl shadow-sm p-8">
            <div className="flex flex-col items-center justify-center py-12">
              <FileText className="h-16 w-16 text-red-500 mb-6" />
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Erreur</h1>
              <p className="text-gray-600 mb-6">
                {error || 'Facture non trouvée'}
              </p>
              <Link to="/user/invoices" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Retour aux factures
              </Link>
            </div>
          </div>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="mb-6 flex justify-between items-center">
          <Link to="/user/invoices" className="text-blue-600 hover:text-blue-800 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour aux factures
          </Link>
          <div className="flex space-x-3">
            <button onClick={handlePrintInvoice} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 bg-white hover:bg-gray-50 flex items-center">
              <Printer className="h-4 w-4 mr-2" />
              Imprimer
            </button>
            <button onClick={handleDownloadInvoice} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <Download className="h-4 w-4 mr-2" />
              Télécharger PDF
            </button>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {/* Invoice Header */}
          <div className="p-8 border-b border-gray-200">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-1">
                  Facture
                </h1>
                <p className="text-gray-600">{invoice.id}</p>
              </div>
              <div className="mt-4 sm:mt-0">
                {invoice.status === 'PAID' && <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Payée
                  </div>}
                {invoice.status === 'PENDING' && <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">
                    <Clock className="h-4 w-4 mr-1" />
                    En attente
                  </div>}
                {invoice.status === 'FAILED' && <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                    <XCircle className="h-4 w-4 mr-1" />
                    Échouée
                  </div>}
              </div>
            </div>
          </div>
          {/* Invoice Body */}
          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {/* Seller Info */}
              <div>
                <h2 className="text-sm font-medium text-gray-500 mb-2">
                  Vendeur
                </h2>
                <p className="font-medium">{invoice.seller.name}</p>
                <p className="text-gray-600 whitespace-pre-line">
                  {invoice.seller.address}
                </p>
                <p className="text-gray-600 mt-1">
                  Numéro fiscal: {invoice.seller.taxId}
                </p>
              </div>
              {/* Customer Info */}
              <div>
                <h2 className="text-sm font-medium text-gray-500 mb-2">
                  Client
                </h2>
                <p className="font-medium">{invoice.billingDetails.name}</p>
                <p className="text-gray-600 whitespace-pre-line">
                  {invoice.billingDetails.address}
                </p>
                <p className="text-gray-600 mt-1">
                  {invoice.billingDetails.email}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {/* Invoice Details */}
              <div>
                <h2 className="text-sm font-medium text-gray-500 mb-2">
                  Détails de la facture
                </h2>
                <div className="flex items-center mb-1">
                  <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-gray-600">
                    Date d'achat: {formatDate(invoice.purchaseDate)}
                  </span>
                </div>
                <div className="flex items-center">
                  <CreditCard className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-gray-600">
                    Mode de paiement: Carte bancaire
                  </span>
                </div>
              </div>
              {/* Dataset Info */}
              <div>
                <h2 className="text-sm font-medium text-gray-500 mb-2">
                  Dataset
                </h2>
                <div className="flex items-start">
                  <Database className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                  <div>
                    <p className="font-medium">{invoice.datasetName}</p>
                    <Link to={`/datasets/${invoice.datasetId}`} className="text-sm text-blue-600 hover:text-blue-800">
                      Voir le dataset
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            {/* Invoice Items */}
            <div className="mb-8">
              <h2 className="text-sm font-medium text-gray-500 mb-4">
                Articles
              </h2>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Description
                      </th>
                      <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Montant
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        Achat du dataset: {invoice.datasetName}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                        {invoice.amount} {invoice.currency}
                      </td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                        Total
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">
                        {invoice.amount} {invoice.currency}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
            {/* Notes */}
            <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-600">
              <p className="font-medium mb-2">Notes</p>
              <p>
                Merci pour votre achat. Pour toute question concernant cette
                facture, veuillez contacter notre service client à l'adresse
                support@example.com.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>;
}