import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CreditCard, Plus, Trash2, CheckCircle, AlertCircle, ArrowLeft } from 'lucide-react';
interface PaymentMethod {
  id: string;
  type: 'card' | 'bank';
  last4: string;
  brand: string;
  expiryMonth: number;
  expiryYear: number;
  isDefault: boolean;
}
export function PaymentMethodsPage() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([{
    id: 'pm_1',
    type: 'card',
    last4: '4242',
    brand: 'Visa',
    expiryMonth: 12,
    expiryYear: 2025,
    isDefault: true
  }, {
    id: 'pm_2',
    type: 'card',
    last4: '5555',
    brand: 'Mastercard',
    expiryMonth: 6,
    expiryYear: 2026,
    isDefault: false
  }]);
  const handleSetDefault = (id: string) => {
    setPaymentMethods(paymentMethods.map(pm => ({
      ...pm,
      isDefault: pm.id === id
    })));
  };
  const handleDelete = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce moyen de paiement ?')) {
      setPaymentMethods(paymentMethods.filter(pm => pm.id !== id));
    }
  };
  return <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="mb-6">
          <Link to="/user/dashboard" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour au dashboard
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">
            Moyens de paiement
          </h1>
          <p className="text-gray-600 mt-2">
            Gérez vos cartes bancaires et autres moyens de paiement
          </p>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Vos moyens de paiement</h2>
            <Link to="/user/payment-method/add" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <Plus className="h-4 w-4 mr-2" />
              Ajouter
            </Link>
          </div>
          {paymentMethods.length === 0 ? <div className="text-center py-12">
              <CreditCard className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Aucun moyen de paiement
              </h3>
              <p className="text-gray-600 mb-6">
                Ajoutez un moyen de paiement pour effectuer des achats
              </p>
              <Link to="/user/payment-method/add" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 inline-flex items-center">
                <Plus className="h-4 w-4 mr-2" />
                Ajouter un moyen de paiement
              </Link>
            </div> : <div className="space-y-4">
              {paymentMethods.map(method => <div key={method.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="h-12 w-12 bg-gray-100 rounded-lg flex items-center justify-center">
                        <CreditCard className="h-6 w-6 text-gray-600" />
                      </div>
                      <div>
                        <div className="flex items-center">
                          <p className="font-medium text-gray-900">
                            {method.brand} •••• {method.last4}
                          </p>
                          {method.isDefault && <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Par défaut
                            </span>}
                        </div>
                        <p className="text-sm text-gray-500">
                          Expire {method.expiryMonth}/{method.expiryYear}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {!method.isDefault && <button onClick={() => handleSetDefault(method.id)} className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50">
                          Définir par défaut
                        </button>}
                      <button onClick={() => handleDelete(method.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-md">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>)}
            </div>}
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3" />
            <div>
              <h3 className="font-medium text-blue-900 mb-1">
                Sécurité des paiements
              </h3>
              <p className="text-sm text-blue-800">
                Vos informations de paiement sont sécurisées et cryptées. Nous
                ne stockons jamais vos numéros de carte complets.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>;
}