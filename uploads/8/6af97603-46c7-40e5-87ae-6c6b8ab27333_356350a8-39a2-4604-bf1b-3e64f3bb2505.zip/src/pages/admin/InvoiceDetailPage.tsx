import React from 'react';
import { DashboardHeader } from '../../components/dashboard/DashboardHeader';
import { DashboardSidebar } from '../../components/dashboard/DashboardSidebar';
import { Download, Send, Printer, Clock, CreditCard, Building, Phone, Mail, MapPin, FileText, CheckCircle, Calendar, User } from 'lucide-react';
export function InvoiceDetailPage() {
  const invoice = {
    id: 'INV-001',
    date: '15 Janvier 2024',
    dueDate: '14 Février 2024',
    status: 'Payée',
    amount: '2,500.00',
    tax: '475.00',
    total: '2,975.00',
    client: {
      name: 'TechCorp Tunisie',
      address: '123 Rue de la République',
      city: 'Tunis',
      postal: '1002',
      country: 'Tunisie',
      email: 'contact@techcorp.tn',
      phone: '+216 71 234 567'
    },
    items: [{
      description: 'Abonnement Premium - Plan Entreprise',
      quantity: 1,
      unitPrice: '2,000.00',
      total: '2,000.00'
    }, {
      description: 'API Calls - Pack 100K',
      quantity: 1,
      unitPrice: '500.00',
      total: '500.00'
    }]
  };
  return <div className="min-h-screen bg-gray-950 text-gray-100">
      <DashboardHeader />
      <div className="flex">
        <DashboardSidebar />
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div>
                <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <FileText className="h-6 w-6 text-blue-400" />
                  </div>
                  Facture #{invoice.id}
                </h1>
                <p className="text-gray-400">
                  Détails de la facture et historique des paiements
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all border border-gray-700">
                  <Printer className="h-5 w-5" />
                  Imprimer
                </button>
                <button className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all border border-gray-700">
                  <Download className="h-5 w-5" />
                  Télécharger
                </button>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/20">
                  <Send className="h-5 w-5" />
                  Envoyer
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-6">
                  {/* En-tête de la facture */}
                  <div className="flex justify-between items-start pb-6 border-b border-gray-800">
                    <div>
                      <h3 className="text-2xl font-bold mb-2 text-blue-400">
                        AI+
                      </h3>
                      <p className="text-gray-400">
                        Plateforme tunisienne d'IA
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-gray-400">Facture #{invoice.id}</p>
                      <p className="text-gray-400">Date: {invoice.date}</p>
                    </div>
                  </div>
                  {/* Informations client */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-400 mb-3 flex items-center">
                        <User className="h-4 w-4 mr-1.5" />
                        FACTURÉ À
                      </h4>
                      <div className="space-y-1">
                        <p className="font-medium">{invoice.client.name}</p>
                        <p className="text-gray-400 text-sm">
                          {invoice.client.address}
                        </p>
                        <p className="text-gray-400 text-sm">
                          {invoice.client.city}, {invoice.client.postal}
                        </p>
                        <p className="text-gray-400 text-sm">
                          {invoice.client.country}
                        </p>
                      </div>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-400 mb-3 flex items-center">
                        <CreditCard className="h-4 w-4 mr-1.5" />
                        DÉTAILS DE PAIEMENT
                      </h4>
                      <div className="space-y-2">
                        <p className="text-gray-400 text-sm">
                          Date d'échéance: {invoice.dueDate}
                        </p>
                        <p className="text-gray-400 text-sm">
                          Méthode: Carte bancaire
                        </p>
                        <span className="inline-flex px-3 py-1 rounded-full text-xs font-medium bg-green-500/10 text-green-400 border border-green-500/20">
                          <CheckCircle className="h-3 w-3 mr-1.5" />
                          {invoice.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  {/* Articles */}
                  <div className="mt-6">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="text-left text-gray-400 border-b border-gray-800">
                            <th className="pb-3">Description</th>
                            <th className="pb-3">Qté</th>
                            <th className="pb-3">Prix unitaire</th>
                            <th className="pb-3 text-right">Total</th>
                          </tr>
                        </thead>
                        <tbody className="text-gray-300">
                          {invoice.items.map((item, index) => <tr key={index} className="border-b border-gray-800">
                              <td className="py-4">{item.description}</td>
                              <td className="py-4">{item.quantity}</td>
                              <td className="py-4">{item.unitPrice} DT</td>
                              <td className="py-4 text-right">
                                {item.total} DT
                              </td>
                            </tr>)}
                        </tbody>
                        <tfoot>
                          <tr className="border-t border-gray-800">
                            <td colSpan={3} className="py-3 text-right">
                              Sous-total
                            </td>
                            <td className="py-3 text-right">
                              {invoice.amount} DT
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={3} className="py-3 text-right">
                              TVA (19%)
                            </td>
                            <td className="py-3 text-right">
                              {invoice.tax} DT
                            </td>
                          </tr>
                          <tr className="border-t border-gray-800 font-semibold text-lg">
                            <td colSpan={3} className="py-3 text-right">
                              Total
                            </td>
                            <td className="py-3 text-right text-blue-400">
                              {invoice.total} DT
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                {/* Informations Client */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-4">
                    Informations Client
                  </h2>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <Building className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                      <span className="text-gray-300 text-sm">
                        {invoice.client.name}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                      <span className="text-gray-300 text-sm">
                        {invoice.client.address}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Mail className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                      <span className="text-gray-300 text-sm">
                        {invoice.client.email}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                      <span className="text-gray-300 text-sm">
                        {invoice.client.phone}
                      </span>
                    </div>
                  </div>
                </div>
                {/* Historique */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-4">Historique</h2>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="p-2 bg-green-500/10 rounded-lg mr-3">
                        <CheckCircle className="h-5 w-5 text-green-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Paiement reçu</p>
                        <p className="text-xs text-gray-400">
                          15 Jan 2024, 14:30
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="p-2 bg-blue-500/10 rounded-lg mr-3">
                        <Send className="h-5 w-5 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Facture envoyée</p>
                        <p className="text-xs text-gray-400">
                          15 Jan 2024, 10:00
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="p-2 bg-yellow-500/10 rounded-lg mr-3">
                        <Clock className="h-5 w-5 text-yellow-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Facture créée</p>
                        <p className="text-xs text-gray-400">
                          15 Jan 2024, 09:45
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>;
}