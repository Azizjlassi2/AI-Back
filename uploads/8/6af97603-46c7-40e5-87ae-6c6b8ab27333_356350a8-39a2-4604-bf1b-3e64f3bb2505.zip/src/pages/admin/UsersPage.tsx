import React, { useState } from 'react';
import { AdminCard } from '../../components/admin/shared/AdminCard';
import { DataTable } from '../../components/admin/shared/DataTable';
import { Users, Search, Filter, UserPlus, Download, Mail, Ban, CheckCircle, XCircle } from 'lucide-react';
export function UsersPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const users = [{
    id: 'USR-001',
    name: 'Ahmed Ben Ali',
    email: 'ahmed.benali@example.com',
    role: 'Développeur',
    status: 'Actif',
    joinDate: '2024-01-15',
    models: 12,
    datasets: 5,
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=AB'
  }, {
    id: 'USR-002',
    name: 'Sarah Mejri',
    email: 'sarah.mejri@example.com',
    role: 'Chercheur',
    status: 'Actif',
    joinDate: '2024-01-10',
    models: 8,
    datasets: 3,
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=SM'
  }, {
    id: 'USR-003',
    name: 'Mohamed Karim',
    email: 'mohamed.karim@example.com',
    role: 'Utilisateur',
    status: 'Suspendu',
    joinDate: '2023-12-20',
    models: 2,
    datasets: 1,
    avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=MK'
  }];
  const columns = [{
    header: 'Utilisateur',
    accessor: 'name',
    cell: (value: any, row: any) => <div className="flex items-center gap-3">
          <img src={row.avatar} alt={value} className="h-10 w-10 rounded-full ring-2 ring-gray-800" />
          <div>
            <p className="font-medium text-gray-100">{value}</p>
            <p className="text-sm text-gray-400">{row.email}</p>
          </div>
        </div>
  }, {
    header: 'Rôle',
    accessor: 'role'
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-3 py-1 rounded-full text-xs font-medium ${value === 'Actif' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
          {value}
        </span>
  }, {
    header: 'Modèles',
    accessor: 'models'
  }, {
    header: 'Datasets',
    accessor: 'datasets'
  }, {
    header: "Date d'inscription",
    accessor: 'joinDate'
  }, {
    header: 'Actions',
    accessor: 'id',
    cell: (value: string, row: any) => <div className="flex space-x-2">
          <button className="p-2 hover:bg-blue-500/10 rounded-lg transition-colors group">
            <Mail className="h-4 w-4 text-gray-400 group-hover:text-blue-400" />
          </button>
          {row.status === 'Actif' ? <button className="p-2 hover:bg-red-500/10 rounded-lg transition-colors group">
              <Ban className="h-4 w-4 text-gray-400 group-hover:text-red-400" />
            </button> : <button className="p-2 hover:bg-green-500/10 rounded-lg transition-colors group">
              <CheckCircle className="h-4 w-4 text-gray-400 group-hover:text-green-400" />
            </button>}
        </div>
  }];
  return <div className="min-h-screen bg-gray-950 text-gray-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-500/10 rounded-lg">
                <Users className="h-6 w-6 text-blue-400" />
              </div>
              Gestion des Utilisateurs
            </h1>
            <p className="text-gray-400">
              Gérez et supervisez tous les utilisateurs de la plateforme
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30">
              <UserPlus className="h-5 w-5" />
              Inviter un utilisateur
            </button>
            <button className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all border border-gray-700">
              <Download className="h-5 w-5" />
              Exporter
            </button>
          </div>
        </div>
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
            <p className="text-sm text-gray-400 mb-1">Total Utilisateurs</p>
            <p className="text-3xl font-bold mb-2">1,234</p>
            <p className="text-sm text-green-400 flex items-center gap-1">
              <span className="text-green-400">↗</span> +12% ce mois
            </p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
            <p className="text-sm text-gray-400 mb-1">Utilisateurs Actifs</p>
            <p className="text-3xl font-bold mb-2">892</p>
            <p className="text-sm text-gray-400">72% du total</p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
            <p className="text-sm text-gray-400 mb-1">Nouveaux (7 jours)</p>
            <p className="text-3xl font-bold mb-2">45</p>
            <p className="text-sm text-green-400 flex items-center gap-1">
              <span className="text-green-400">↗</span> +8% vs semaine dernière
            </p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
            <p className="text-sm text-gray-400 mb-1">Suspendus</p>
            <p className="text-3xl font-bold mb-2">23</p>
            <p className="text-sm text-red-400">1.9% du total</p>
          </div>
        </div>
        {/* Filters and Search */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input type="text" placeholder="Rechercher un utilisateur..." className="w-full pl-10 pr-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
              </div>
            </div>
            <div>
              <select className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={filterRole} onChange={e => setFilterRole(e.target.value)}>
                <option value="all">Tous les rôles</option>
                <option value="developer">Développeur</option>
                <option value="researcher">Chercheur</option>
                <option value="user">Utilisateur</option>
              </select>
            </div>
            <div>
              <select className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                <option value="all">Tous les statuts</option>
                <option value="active">Actif</option>
                <option value="suspended">Suspendu</option>
                <option value="pending">En attente</option>
              </select>
            </div>
          </div>
        </div>
        {/* Users Table */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="p-6 border-b border-gray-800">
            <h2 className="text-lg font-semibold">Liste des Utilisateurs</h2>
          </div>
          <DataTable columns={columns} data={users} onRowClick={row => window.location.href = `/admin/users/${row.id}`} />
        </div>
      </div>
    </div>;
}