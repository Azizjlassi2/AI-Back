import React from 'react';
import { DashboardHeader } from '../../components/dashboard/DashboardHeader';
import { DashboardSidebar } from '../../components/dashboard/DashboardSidebar';
import { AdminCard } from '../../components/admin/shared/AdminCard';
import { DataTable } from '../../components/admin/shared/DataTable';
import { Calendar, Download, Star, Users, Activity, Shield, AlertTriangle, Edit, Trash2, TrendingUp, Globe, CheckCircle, XCircle } from 'lucide-react';
export function AdminModelDetailPage() {
  const model = {
    id: 'MDL-001',
    name: 'ArabicBERT v2.1',
    creator: {
      name: 'AI Lab Tunisia',
      avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=AL',
      role: 'Organisation'
    },
    status: 'Published',
    description: 'Un modèle BERT pré-entraîné sur un large corpus de textes arabes, optimisé pour les tâches de traitement du langage naturel en arabe standard moderne et dialectal tunisien.',
    version: '2.1.0',
    license: 'MIT',
    lastUpdate: '2024-01-15',
    framework: 'PyTorch',
    stats: {
      downloads: '15.2K',
      stars: '234',
      forks: '45',
      users: '1.2K',
      apiCalls: '2.5M'
    },
    performance: {
      accuracy: '94.2%',
      f1Score: '0.923',
      precision: '0.918',
      recall: '0.928'
    },
    usage: [{
      date: '2024-01-15',
      calls: 12500
    }, {
      date: '2024-01-14',
      calls: 11200
    }, {
      date: '2024-01-13',
      calls: 13400
    }],
    reports: [{
      id: 'RPT-001',
      type: 'Performance',
      description: 'Latence élevée',
      status: 'En cours',
      date: '2024-01-14',
      reporter: 'Mohamed Karim'
    }, {
      id: 'RPT-002',
      type: 'Sécurité',
      description: 'Vulnérabilité potentielle',
      status: 'Résolu',
      date: '2024-01-10',
      reporter: 'Sarah Mejri'
    }, {
      id: 'RPT-003',
      type: 'Qualité',
      description: 'Résultats incorrects',
      status: 'En attente',
      date: '2024-01-12',
      reporter: 'Ahmed Ben Ali'
    }]
  };
  const reportColumns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Type',
    accessor: 'type'
  }, {
    header: 'Description',
    accessor: 'description'
  }, {
    header: 'Signalé par',
    accessor: 'reporter'
  }, {
    header: 'Status',
    accessor: 'status',
    cell: (value: string) => <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center w-fit ${value === 'Résolu' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : value === 'En cours' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'}`}>
          {value === 'Résolu' && <CheckCircle className="h-3 w-3 mr-1.5" />}
          {value === 'En attente' && <AlertTriangle className="h-3 w-3 mr-1.5" />}
          {value}
        </span>
  }, {
    header: 'Date',
    accessor: 'date'
  }];
  return <div className="min-h-screen bg-gray-950 text-gray-100">
      <DashboardHeader />
      <div className="flex">
        <DashboardSidebar />
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
              <div>
                <div className="flex items-center mb-2">
                  <div className="p-2 bg-blue-500/10 rounded-lg mr-3">
                    <div className="h-6 w-6 text-blue-400" />
                  </div>
                  <h1 className="text-3xl font-bold">{model.name}</h1>
                </div>
                <p className="text-gray-400">ID: {model.id}</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/20">
                  <Edit className="h-4 w-4" />
                  Modifier
                </button>
                <button className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all">
                  <Trash2 className="h-4 w-4" />
                  Supprimer
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Overview */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-6">Vue d'ensemble</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg hover:border-gray-600 transition-all">
                      <div className="flex items-center justify-between mb-2">
                        <Download className="h-5 w-5 text-blue-400" />
                      </div>
                      <p className="text-2xl font-bold mb-1">
                        {model.stats.downloads}
                      </p>
                      <p className="text-sm text-gray-400">Téléchargements</p>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg hover:border-gray-600 transition-all">
                      <div className="flex items-center justify-between mb-2">
                        <Star className="h-5 w-5 text-yellow-400" />
                      </div>
                      <p className="text-2xl font-bold mb-1">
                        {model.stats.stars}
                      </p>
                      <p className="text-sm text-gray-400">Stars</p>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg hover:border-gray-600 transition-all">
                      <div className="flex items-center justify-between mb-2">
                        <Users className="h-5 w-5 text-green-400" />
                      </div>
                      <p className="text-2xl font-bold mb-1">
                        {model.stats.users}
                      </p>
                      <p className="text-sm text-gray-400">Utilisateurs</p>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg hover:border-gray-600 transition-all">
                      <div className="flex items-center justify-between mb-2">
                        <Activity className="h-5 w-5 text-purple-400" />
                      </div>
                      <p className="text-2xl font-bold mb-1">
                        {model.stats.apiCalls}
                      </p>
                      <p className="text-sm text-gray-400">Appels API</p>
                    </div>
                  </div>
                  <div className="space-y-4 pt-4 border-t border-gray-800">
                    <div className="flex items-center">
                      <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-gray-300">
                        Dernière mise à jour: {model.lastUpdate}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-gray-300">
                        Licence: {model.license}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Globe className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-gray-300">
                        Framework: {model.framework}
                      </span>
                    </div>
                  </div>
                </div>
                {/* Performance */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-6">Performance</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg">
                      <p className="text-sm text-gray-400 mb-1">Précision</p>
                      <p className="text-2xl font-bold">
                        {model.performance.accuracy}
                      </p>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg">
                      <p className="text-sm text-gray-400 mb-1">Score F1</p>
                      <p className="text-2xl font-bold">
                        {model.performance.f1Score}
                      </p>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg">
                      <p className="text-sm text-gray-400 mb-1">Précision</p>
                      <p className="text-2xl font-bold">
                        {model.performance.precision}
                      </p>
                    </div>
                    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg">
                      <p className="text-sm text-gray-400 mb-1">Rappel</p>
                      <p className="text-2xl font-bold">
                        {model.performance.recall}
                      </p>
                    </div>
                  </div>
                </div>
                {/* Reports */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
                  <div className="p-6 border-b border-gray-800">
                    <h2 className="text-lg font-semibold">Signalements</h2>
                  </div>
                  <DataTable columns={reportColumns} data={model.reports} />
                </div>
              </div>
              {/* Sidebar */}
              <div className="space-y-6">
                {/* Creator Info */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-4">Créateur</h2>
                  <div className="flex items-center mb-4">
                    <img src={model.creator.avatar} alt={model.creator.name} className="h-12 w-12 rounded-full ring-2 ring-gray-800" />
                    <div className="ml-3">
                      <h3 className="font-semibold">{model.creator.name}</h3>
                      <p className="text-sm text-gray-400">
                        {model.creator.role}
                      </p>
                    </div>
                  </div>
                </div>
                {/* Status */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-4">Statut</h2>
                  <div className="space-y-4">
                    <span className="px-3 py-1 rounded-full text-sm inline-flex bg-green-500/10 text-green-400 border border-green-500/20">
                      {model.status}
                    </span>
                    <p className="text-gray-400 text-sm">{model.description}</p>
                  </div>
                </div>
                {/* Quick Actions */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h2 className="text-lg font-semibold mb-4">
                    Actions Rapides
                  </h2>
                  <div className="space-y-2">
                    <button className="w-full px-4 py-2.5 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 flex items-center transition-all border border-gray-700">
                      <Shield className="h-4 w-4 mr-2" />
                      Audit de sécurité
                    </button>
                    <button className="w-full px-4 py-2.5 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 flex items-center transition-all border border-gray-700">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Rapport de performance
                    </button>
                    <button className="w-full px-4 py-2.5 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 flex items-center transition-all border border-gray-700">
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Signaler un problème
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>;
}