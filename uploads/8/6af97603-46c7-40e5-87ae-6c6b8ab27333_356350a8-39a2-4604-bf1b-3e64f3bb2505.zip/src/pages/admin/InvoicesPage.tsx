import React, { useState } from 'react';
import { DashboardHeader } from '../../components/dashboard/DashboardHeader';
import { DashboardSidebar } from '../../components/dashboard/DashboardSidebar';
import { AdminCard } from '../../components/admin/shared/AdminCard';
import { DataTable } from '../../components/admin/shared/DataTable';
import { Download, FileText, Search, Filter, Plus, Eye, CheckCircle, Clock, XCircle, TrendingUp, TrendingDown } from 'lucide-react';
export function InvoicesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const invoices = [{
    id: 'INV-001',
    client: 'TechCorp Tunisie',
    amount: '2,500 DT',
    status: 'Payée',
    date: '2024-01-15'
  }, {
    id: 'INV-002',
    client: 'AI Solutions SARL',
    amount: '1,800 DT',
    status: 'En attente',
    date: '2024-01-14'
  }, {
    id: 'INV-003',
    client: 'DataTech Tunisia',
    amount: '3,200 DT',
    status: 'Payée',
    date: '2024-01-13'
  }, {
    id: 'INV-004',
    client: 'Smart Systems',
    amount: '950 DT',
    status: 'En retard',
    date: '2024-01-10'
  }, {
    id: 'INV-005',
    client: 'Innovation Labs',
    amount: '4,100 DT',
    status: 'Payée',
    date: '2024-01-08'
  }];
  const columns = [{
    header: 'Numéro',
    accessor: 'id'
  }, {
    header: 'Client',
    accessor: 'client'
  }, {
    header: 'Montant',
    accessor: 'amount'
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center w-fit ${value === 'Payée' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : value === 'En attente' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
          {value === 'Payée' && <CheckCircle className="h-3 w-3 mr-1.5" />}
          {value === 'En attente' && <Clock className="h-3 w-3 mr-1.5" />}
          {value === 'En retard' && <XCircle className="h-3 w-3 mr-1.5" />}
          {value}
        </span>
  }, {
    header: 'Date',
    accessor: 'date'
  }, {
    header: 'Actions',
    accessor: 'id',
    cell: (value: string) => <div className="flex space-x-2">
          <button className="p-2 hover:bg-blue-500/10 rounded-lg transition-colors group">
            <Eye className="h-4 w-4 text-gray-400 group-hover:text-blue-400" />
          </button>
          <button className="p-2 hover:bg-green-500/10 rounded-lg transition-colors group">
            <Download className="h-4 w-4 text-gray-400 group-hover:text-green-400" />
          </button>
        </div>
  }];
  return <div className="min-h-screen bg-gray-950 text-gray-100">
      <DashboardHeader />
      <div className="flex">
        <DashboardSidebar />
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <FileText className="h-6 w-6 text-blue-400" />
                  </div>
                  Gestion des Factures
                </h1>
                <p className="text-gray-400">
                  Gérez et supervisez toutes les factures de la plateforme
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/20">
                  <Plus className="h-5 w-5" />
                  Nouvelle facture
                </button>
                <button className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all border border-gray-700">
                  <Download className="h-5 w-5" />
                  Exporter
                </button>
              </div>
            </div>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">Total ce mois</p>
                <p className="text-3xl font-bold mb-2">12,550 DT</p>
                <p className="text-sm text-green-400 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  +15% vs mois dernier
                </p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">En attente</p>
                <p className="text-3xl font-bold mb-2">3,200 DT</p>
                <p className="text-sm text-yellow-400">2 factures</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">Payées</p>
                <p className="text-3xl font-bold mb-2">9,350 DT</p>
                <p className="text-sm text-gray-400">8 factures</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">En retard</p>
                <p className="text-3xl font-bold mb-2">950 DT</p>
                <p className="text-sm text-red-400">1 facture</p>
              </div>
            </div>
            {/* Filters and Search */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input type="text" placeholder="Rechercher une facture..." className="w-full pl-10 pr-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                  </div>
                </div>
                <div>
                  <select className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                    <option value="all">Tous les statuts</option>
                    <option value="paid">Payée</option>
                    <option value="pending">En attente</option>
                    <option value="overdue">En retard</option>
                  </select>
                </div>
              </div>
            </div>
            {/* Invoices Table */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
              <div className="p-6 border-b border-gray-800">
                <h2 className="text-lg font-semibold">Factures Récentes</h2>
              </div>
              <DataTable columns={columns} data={invoices} onRowClick={row => window.location.href = `/admin/invoices/${row.id}`} />
            </div>
          </div>
        </main>
      </div>
    </div>;
}