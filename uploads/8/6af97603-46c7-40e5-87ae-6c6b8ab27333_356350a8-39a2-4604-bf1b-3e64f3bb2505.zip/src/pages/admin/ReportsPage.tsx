import React, { useState } from 'react';
import { AdminCard } from '../../components/admin/shared/AdminCard';
import { DataTable } from '../../components/admin/shared/DataTable';
import { AlertTriangle, Flag, Search, Filter, CheckCircle, XCircle, Clock, MessageSquare } from 'lucide-react';
export function ReportsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const reports = [{
    id: 'R-001',
    type: 'Modèle',
    item: 'ToxicText Detector',
    reporter: 'Mohamed Karim',
    reason: 'Contenu inapproprié',
    status: 'En attente',
    priority: 'Haute',
    date: '2024-01-15'
  }, {
    id: 'R-002',
    type: 'Dataset',
    item: 'Medical Images v2',
    reporter: 'Leila Ben Salah',
    reason: 'Violation de licence',
    status: 'En cours',
    priority: 'Moyenne',
    date: '2024-01-14'
  }, {
    id: 'R-003',
    type: 'Utilisateur',
    item: 'spam_account_123',
    reporter: 'Admin System',
    reason: 'Activité suspecte',
    status: 'Résolu',
    priority: 'Haute',
    date: '2024-01-13'
  }, {
    id: 'R-004',
    type: 'Modèle',
    item: 'FakeNews Detector',
    reporter: 'Sarah Mejri',
    reason: 'Résultats incorrects',
    status: 'En attente',
    priority: 'Basse',
    date: '2024-01-12'
  }];
  const columns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Type',
    accessor: 'type',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Modèle' ? 'bg-blue-200 text-blue-800' : value === 'Dataset' ? 'bg-purple-200 text-purple-800' : 'bg-gray-200 text-gray-800'}`}>
          {value}
        </span>
  }, {
    header: 'Élément',
    accessor: 'item'
  }, {
    header: 'Signalé par',
    accessor: 'reporter'
  }, {
    header: 'Raison',
    accessor: 'reason'
  }, {
    header: 'Priorité',
    accessor: 'priority',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Haute' ? 'bg-red-200 text-red-800' : value === 'Moyenne' ? 'bg-yellow-200 text-yellow-800' : 'bg-green-200 text-green-800'}`}>
          {value}
        </span>
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs flex items-center w-fit ${value === 'En attente' ? 'bg-yellow-200 text-yellow-800' : value === 'En cours' ? 'bg-blue-200 text-blue-800' : 'bg-green-200 text-green-800'}`}>
          {value === 'En attente' && <Clock className="h-3 w-3 mr-1" />}
          {value === 'En cours' && <MessageSquare className="h-3 w-3 mr-1" />}
          {value === 'Résolu' && <CheckCircle className="h-3 w-3 mr-1" />}
          {value}
        </span>
  }, {
    header: 'Date',
    accessor: 'date'
  }, {
    header: 'Actions',
    accessor: 'id',
    cell: (value: string, row: any) => <div className="flex space-x-2">
          {row.status !== 'Résolu' && <>
              <button className="p-1 hover:text-green-500" title="Approuver">
                <CheckCircle className="h-5 w-5" />
              </button>
              <button className="p-1 hover:text-red-500" title="Rejeter">
                <XCircle className="h-5 w-5" />
              </button>
            </>}
        </div>
  }];
  return <div className="min-h-screen bg-gray-900 text-gray-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Flag className="h-6 w-6 mr-2" />
          Gestion des Signalements
        </h1>
        <div className="flex space-x-4">
          <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            Haute Priorité (
            {reports.filter(r => r.priority === 'Haute' && r.status !== 'Résolu').length}
            )
          </button>
        </div>
      </div>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-gray-800 rounded-lg p-6">
          <p className="text-sm text-gray-400">Signalements en attente</p>
          <p className="text-2xl font-semibold mt-1">
            {reports.filter(r => r.status === 'En attente').length}
          </p>
          <p className="text-sm text-yellow-500 mt-1">Nécessite attention</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <p className="text-sm text-gray-400">En cours de traitement</p>
          <p className="text-2xl font-semibold mt-1">
            {reports.filter(r => r.status === 'En cours').length}
          </p>
          <p className="text-sm text-blue-500 mt-1">En progression</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <p className="text-sm text-gray-400">Résolus aujourd'hui</p>
          <p className="text-2xl font-semibold mt-1">12</p>
          <p className="text-sm text-green-500 mt-1">+3 vs hier</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-6">
          <p className="text-sm text-gray-400">Temps moyen de traitement</p>
          <p className="text-2xl font-semibold mt-1">4h 12m</p>
          <p className="text-sm text-gray-400 mt-1">-15% vs semaine dernière</p>
        </div>
      </div>
      {/* Filters and Search */}
      <div className="bg-gray-800 rounded-lg p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input type="text" placeholder="Rechercher un signalement..." className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-gray-100" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
          </div>
          <div>
            <select className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-gray-100" value={filterType} onChange={e => setFilterType(e.target.value)}>
              <option value="all">Tous les types</option>
              <option value="model">Modèle</option>
              <option value="dataset">Dataset</option>
              <option value="user">Utilisateur</option>
            </select>
          </div>
          <div>
            <select className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-gray-100" value={filterPriority} onChange={e => setFilterPriority(e.target.value)}>
              <option value="all">Toutes les priorités</option>
              <option value="high">Haute</option>
              <option value="medium">Moyenne</option>
              <option value="low">Basse</option>
            </select>
          </div>
          <div>
            <select className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-gray-100" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="all">Tous les statuts</option>
              <option value="pending">En attente</option>
              <option value="processing">En cours</option>
              <option value="resolved">Résolu</option>
            </select>
          </div>
        </div>
      </div>
      {/* Reports Table */}
      <AdminCard title="Signalements Récents">
        <DataTable columns={columns} data={reports} onRowClick={row => console.log('Clicked report:', row)} />
      </AdminCard>
    </div>;
}