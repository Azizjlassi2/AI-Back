import React, { useState } from 'react';
import { DashboardHeader } from '../../components/dashboard/DashboardHeader';
import { DashboardSidebar } from '../../components/dashboard/DashboardSidebar';
import { AdminCard } from '../../components/admin/shared/AdminCard';
import { DataTable } from '../../components/admin/shared/DataTable';
import { Headphones, Search, Filter, MessageSquare, Clock, CheckCircle, AlertCircle, User, Mail, Phone, Calendar, Tag } from 'lucide-react';
export function SupportPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const tickets = [{
    id: 'TK-001',
    user: 'Ahmed Ben Ali',
    email: 'ahmed.benali@example.com',
    subject: "Problème d'accès API",
    status: 'En attente',
    priority: 'Haute',
    created: '2024-01-15',
    category: 'Technique'
  }, {
    id: 'TK-002',
    user: 'Sarah Mejri',
    email: 'sarah.mejri@example.com',
    subject: 'Question sur la facturation',
    status: 'En cours',
    priority: 'Moyenne',
    created: '2024-01-14',
    category: 'Facturation'
  }, {
    id: 'TK-003',
    user: 'Mohamed Karim',
    email: 'mohamed.karim@example.com',
    subject: 'Demande de remboursement',
    status: 'Résolu',
    priority: 'Basse',
    created: '2024-01-13',
    category: 'Facturation'
  }, {
    id: 'TK-004',
    user: 'Leila Ben Salah',
    email: 'leila.bensalah@example.com',
    subject: 'Erreur lors du déploiement',
    status: 'En attente',
    priority: 'Haute',
    created: '2024-01-12',
    category: 'Technique'
  }, {
    id: 'TK-005',
    user: 'Karim Mansour',
    email: 'karim.mansour@example.com',
    subject: 'Aide pour configuration modèle',
    status: 'En cours',
    priority: 'Moyenne',
    created: '2024-01-11',
    category: 'Support'
  }];
  const columns = [{
    header: 'ID',
    accessor: 'id'
  }, {
    header: 'Utilisateur',
    accessor: 'user',
    cell: (value: any, row: any) => <div>
          <p className="font-medium text-gray-100">{value}</p>
          <p className="text-sm text-gray-400">{row.email}</p>
        </div>
  }, {
    header: 'Sujet',
    accessor: 'subject'
  }, {
    header: 'Catégorie',
    accessor: 'category',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Technique' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : value === 'Facturation' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20'}`}>
          {value}
        </span>
  }, {
    header: 'Statut',
    accessor: 'status',
    cell: (value: string) => <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center w-fit ${value === 'En attente' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : value === 'En cours' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20'}`}>
          {value === 'En attente' && <Clock className="h-3 w-3 mr-1.5" />}
          {value === 'En cours' && <MessageSquare className="h-3 w-3 mr-1.5" />}
          {value === 'Résolu' && <CheckCircle className="h-3 w-3 mr-1.5" />}
          {value}
        </span>
  }, {
    header: 'Priorité',
    accessor: 'priority',
    cell: (value: string) => <span className={`px-2 py-1 rounded-full text-xs ${value === 'Haute' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : value === 'Moyenne' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20'}`}>
          {value}
        </span>
  }, {
    header: 'Créé le',
    accessor: 'created'
  }];
  return <div className="min-h-screen bg-gray-950 text-gray-100">
      <DashboardHeader />
      <div className="flex">
        <DashboardSidebar />
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Headphones className="h-6 w-6 text-blue-400" />
                  </div>
                  Support Client
                </h1>
                <p className="text-gray-400">
                  Gérez et répondez aux demandes de support
                </p>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">Tickets en attente</p>
                <p className="text-3xl font-bold mb-2">12</p>
                <p className="text-sm text-yellow-400">Nécessite attention</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">En cours</p>
                <p className="text-3xl font-bold mb-2">8</p>
                <p className="text-sm text-blue-400">En traitement</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">
                  Temps de réponse moyen
                </p>
                <p className="text-3xl font-bold mb-2">2h 34m</p>
                <p className="text-sm text-green-400">-15% vs mois dernier</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all">
                <p className="text-sm text-gray-400 mb-1">
                  Satisfaction client
                </p>
                <p className="text-3xl font-bold mb-2">94%</p>
                <p className="text-sm text-green-400">+3% vs mois dernier</p>
              </div>
            </div>

            {/* Filters and Search */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input type="text" placeholder="Rechercher un ticket..." className="w-full pl-10 pr-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                  </div>
                </div>
                <div>
                  <select className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                    <option value="all">Tous les statuts</option>
                    <option value="pending">En attente</option>
                    <option value="processing">En cours</option>
                    <option value="resolved">Résolu</option>
                  </select>
                </div>
                <div>
                  <select className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" value={filterPriority} onChange={e => setFilterPriority(e.target.value)}>
                    <option value="all">Toutes les priorités</option>
                    <option value="high">Haute</option>
                    <option value="medium">Moyenne</option>
                    <option value="low">Basse</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Tickets Table */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
              <div className="p-6 border-b border-gray-800">
                <h2 className="text-lg font-semibold">Tickets Récents</h2>
              </div>
              <DataTable columns={columns} data={tickets} onRowClick={row => console.log('Clicked ticket:', row)} />
            </div>
          </div>
        </main>
      </div>
    </div>;
}