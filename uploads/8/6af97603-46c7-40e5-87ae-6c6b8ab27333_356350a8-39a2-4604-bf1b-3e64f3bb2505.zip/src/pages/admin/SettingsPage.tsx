import React, { useState } from 'react';
import { AdminCard } from '../../components/admin/shared/AdminCard';
import { Bell, Shield, Database, Server, Mail, Globe, CreditCard, Users, Settings as SettingsIcon, HardDrive, Cpu, Activity, CheckCircle, AlertTriangle } from 'lucide-react';
export function SettingsPage() {
  const [activeTab, setActiveTab] = useState('general');
  const tabs = [{
    id: 'general',
    label: 'Général',
    icon: SettingsIcon
  }, {
    id: 'deployment',
    label: 'Déploiement',
    icon: Server
  }, {
    id: 'monetization',
    label: 'Monétisation',
    icon: CreditCard
  }, {
    id: 'storage',
    label: 'Stockage',
    icon: HardDrive
  }, {
    id: 'security',
    label: 'Sécurité',
    icon: Shield
  }, {
    id: 'notifications',
    label: 'Notifications',
    icon: Bell
  }, {
    id: 'api',
    label: 'API',
    icon: Activity
  }];
  return <div className="min-h-screen bg-gray-900 text-gray-100 p-8">
      <h1 className="text-2xl font-bold mb-6">Configuration du Système</h1>
      <div className="flex space-x-6">
        {/* Sidebar Tabs */}
        <div className="w-64 space-y-2">
          {tabs.map(tab => {
          const Icon = tab.icon;
          return <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`w-full px-4 py-3 rounded-lg flex items-center transition-colors ${activeTab === tab.id ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'}`}>
                <Icon className="h-5 w-5 mr-3" />
                <span>{tab.label}</span>
              </button>;
        })}
        </div>
        {/* Content Area */}
        <div className="flex-1">
          {activeTab === 'general' && <div className="space-y-6">
              <AdminCard title="Paramètres Généraux">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Nom de la Plateforme
                    </label>
                    <input type="text" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="AI+" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Email de Contact
                    </label>
                    <input type="email" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="contact@aiplus.tn" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Langue par Défaut
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="fr">Français</option>
                      <option value="ar">Arabe</option>
                      <option value="en">Anglais</option>
                    </select>
                  </div>
                </div>
              </AdminCard>
            </div>}
          {activeTab === 'deployment' && <div className="space-y-6">
              <AdminCard title="Configuration du Déploiement">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Fournisseur de Cloud
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="aws">Amazon Web Services (AWS)</option>
                      <option value="gcp">Google Cloud Platform (GCP)</option>
                      <option value="azure">Microsoft Azure</option>
                      <option value="local">Serveurs Locaux</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Région par Défaut
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="eu-central-1">
                        EU Central (Frankfurt)
                      </option>
                      <option value="eu-west-1">EU West (Ireland)</option>
                      <option value="us-east-1">US East (N. Virginia)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Type d'Instance par Défaut
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="t3.small">
                        t3.small (2 vCPU, 2GB RAM)
                      </option>
                      <option value="t3.medium">
                        t3.medium (2 vCPU, 4GB RAM)
                      </option>
                      <option value="t3.large">
                        t3.large (2 vCPU, 8GB RAM)
                      </option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Limite d'Instances par Utilisateur
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="5" />
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                    <span className="ml-2 text-sm text-gray-300">
                      Auto-scaling activé
                    </span>
                  </div>
                </div>
              </AdminCard>
              <AdminCard title="Health Checks">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                      <span>API Server</span>
                    </div>
                    <span className="text-sm text-green-500">En ligne</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                      <span>Services de Déploiement</span>
                    </div>
                    <span className="text-sm text-green-500">En ligne</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                    <div className="flex items-center">
                      <AlertTriangle className="h-5 w-5 text-yellow-500 mr-3" />
                      <span>Load Balancer</span>
                    </div>
                    <span className="text-sm text-yellow-500">
                      Latence élevée
                    </span>
                  </div>
                  <button className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">
                    Effectuer un Health Check Complet
                  </button>
                </div>
              </AdminCard>
            </div>}
          {activeTab === 'monetization' && <div className="space-y-6">
              <AdminCard title="Configuration de la Monétisation">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Devise par Défaut
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="tnd">TND - Dinar Tunisien</option>
                      <option value="eur">EUR - Euro</option>
                      <option value="usd">USD - Dollar US</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      TVA (%)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="19" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Commission de la Plateforme (%)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="15" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Délai de Paiement (jours)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="30" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Passerelle de Paiement
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="stripe">Stripe</option>
                      <option value="paypal">PayPal</option>
                      <option value="local">Paiement Local</option>
                    </select>
                  </div>
                </div>
              </AdminCard>
            </div>}
          {activeTab === 'storage' && <div className="space-y-6">
              <AdminCard title="Configuration du Stockage">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Fournisseur de Stockage
                    </label>
                    <select className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100">
                      <option value="local">Stockage Local</option>
                      <option value="s3">Amazon S3</option>
                      <option value="gcs">Google Cloud Storage</option>
                      <option value="azure">Azure Blob Storage</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Limite de Stockage par Utilisateur (GB)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="100" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Politique de Rétention (jours)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="90" />
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                    <span className="ml-2 text-sm text-gray-300">
                      Compression automatique pour fichiers &gt; 100MB
                    </span>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                    <span className="ml-2 text-sm text-gray-300">
                      Sauvegarde automatique quotidienne
                    </span>
                  </div>
                </div>
              </AdminCard>
              <AdminCard title="Utilisation du Stockage">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Espace total</span>
                    <span className="font-semibold">5 TB</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Espace utilisé</span>
                    <span className="font-semibold">3.2 TB (64%)</span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500" style={{
                  width: '64%'
                }}></div>
                  </div>
                </div>
              </AdminCard>
            </div>}
          {activeTab === 'security' && <div className="space-y-6">
              <AdminCard title="Paramètres de Sécurité">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Authentification à Deux Facteurs
                    </label>
                    <div className="flex items-center">
                      <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                      <span className="ml-2 text-sm text-gray-300">
                        Activer pour tous les administrateurs
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Session Timeout (minutes)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="30" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Politique de Mot de Passe
                    </label>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Minimum 8 caractères
                        </span>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Au moins une majuscule
                        </span>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Au moins un chiffre
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </AdminCard>
            </div>}
          {activeTab === 'notifications' && <div className="space-y-6">
              <AdminCard title="Paramètres des Notifications">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Notifications Email
                    </label>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Nouveaux utilisateurs
                        </span>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Nouveaux modèles
                        </span>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Rapports de signalement
                        </span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Notifications Push
                    </label>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Activité suspecte
                        </span>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" className="bg-gray-700 border-gray-600 rounded" defaultChecked />
                        <span className="ml-2 text-sm text-gray-300">
                          Mises à jour système
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </AdminCard>
            </div>}
          {activeTab === 'api' && <div className="space-y-6">
              <AdminCard title="Paramètres API">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Limite de Requêtes (/minute)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="100" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Taille Maximum de Requête (MB)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="10" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Timeout (secondes)
                    </label>
                    <input type="number" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-gray-100" defaultValue="30" />
                  </div>
                </div>
              </AdminCard>
            </div>}
          <div className="mt-8 flex justify-end space-x-4">
            <button className="px-6 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg">
              Annuler
            </button>
            <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">
              Sauvegarder les modifications
            </button>
          </div>
        </div>
      </div>
    </div>;
}