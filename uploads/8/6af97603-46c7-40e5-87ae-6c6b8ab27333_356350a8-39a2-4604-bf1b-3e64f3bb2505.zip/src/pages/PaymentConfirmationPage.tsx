import React, { useEffect, useState } from 'react';
import { useParams, useLocation, useNavigate, Link } from 'react-router-dom';
import { CheckCircle, Calendar, CreditCard, ChevronRight, Download, AlertCircle, Zap, FileText, Clock } from 'lucide-react';
// Define subscription plan types
enum BillingPeriod {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
  PAY_AS_YOU_GO = 'PAY_AS_YOU_GO',
}
interface Subscription {
  id: number;
  modelId: number;
  modelName: string;
  planId: number;
  planName: string;
  startDate: string;
  price: number;
  currency: string;
  billingPeriod: BillingPeriod;
  nextBillingDate: string;
}
interface Model {
  id: number;
  name: string;
  creator: {
    name: string;
  };
}
interface Plan {
  id?: number;
  name: string;
  description: string;
  price: number;
  currency: string;
  billingPeriod: BillingPeriod;
  features: string[];
  apiCallsLimit?: number;
  apiCallsPrice?: number;
}
export function PaymentConfirmationPage() {
  const {
    subscriptionId
  } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [model, setModel] = useState<Model | null>(null);
  const [plan, setPlan] = useState<Plan | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // Format date to readable string
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
  };
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Try to get data from location state first
        if (location.state?.subscription && location.state?.model && location.state?.plan) {
          setSubscription(location.state.subscription);
          setModel(location.state.model);
          setPlan(location.state.plan);
        } else {
          // If not available in location state, try to fetch from localStorage
          const subscriptions = JSON.parse(localStorage.getItem('userSubscriptions') || '[]');
          const foundSubscription = subscriptions.find((sub: Subscription) => sub.id.toString() === subscriptionId);
          if (foundSubscription) {
            setSubscription(foundSubscription);
            // Simulate fetching model and plan data
            // In a real app, you would fetch this from your API
            setModel({
              id: foundSubscription.modelId,
              name: foundSubscription.modelName,
              creator: {
                name: 'AI Lab Tunisia' // Hardcoded for demo
              }
            });
            setPlan({
              id: foundSubscription.planId,
              name: foundSubscription.planName,
              description: 'Pour les startups et projets en croissance',
              price: foundSubscription.price,
              currency: foundSubscription.currency,
              billingPeriod: foundSubscription.billingPeriod,
              features: ["Accès à l'API avec limites étendues", '50 000 appels API par mois', 'Support par email', "Tableaux de bord d'analyse"],
              apiCallsLimit: 50000
            });
          } else {
            setError('Abonnement non trouvé');
          }
        }
      } catch (error) {
        console.error('Error fetching subscription data:', error);
        setError('Une erreur est survenue lors du chargement des données');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [location.state, subscriptionId]);
  // Get billing period text
  const getBillingPeriodText = (billingPeriod: BillingPeriod) => {
    switch (billingPeriod) {
      case BillingPeriod.MONTHLY:
        return 'Mensuel';
      case BillingPeriod.ANNUAL:
        return 'Annuel';
      case BillingPeriod.PAY_AS_YOU_GO:
        return 'Pay-as-you-use';
      default:
        return '';
    }
  };
  // Get appropriate icon for plan
  const getPlanIcon = (billingPeriod: BillingPeriod) => {
    switch (billingPeriod) {
      case BillingPeriod.MONTHLY:
        return <Calendar className="h-5 w-5 text-blue-600" />;
      case BillingPeriod.ANNUAL:
        return <Calendar className="h-5 w-5 text-green-600" />;
      case BillingPeriod.PAY_AS_YOU_GO:
        return <Zap className="h-5 w-5 text-purple-600" />;
      default:
        return <CreditCard className="h-5 w-5 text-blue-600" />;
    }
  };
  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>;
  }
  if (error || !subscription || !model || !plan) {
    return <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Erreur</h1>
        <p className="text-gray-600 mb-6">
          {error || "Données d'abonnement introuvables"}
        </p>
        <button onClick={() => navigate('/models')} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Explorer les modèles
        </button>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {/* Success banner */}
          <div className="bg-green-500 p-6 text-white">
            <div className="flex items-center">
              <div className="bg-white rounded-full p-2 mr-4">
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Paiement confirmé</h1>
                <p className="text-green-100">
                  Votre abonnement est maintenant actif
                </p>
              </div>
            </div>
          </div>
          {/* Confirmation details */}
          <div className="p-6">
            <div className="border-b border-gray-200 pb-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">
                Détails de l'abonnement
              </h2>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium text-gray-900">{model.name}</h3>
                    <p className="text-sm text-gray-600">
                      par {model.creator.name}
                    </p>
                    <div className="mt-2 flex items-center">
                      {getPlanIcon(plan.billingPeriod)}
                      <span className="ml-2 font-medium text-gray-800">
                        {plan.name} ({getBillingPeriodText(plan.billingPeriod)})
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-gray-900">
                      {plan.billingPeriod === BillingPeriod.PAY_AS_YOU_GO ? <>
                          {plan.apiCallsPrice} {plan.currency}
                          <span className="text-sm font-normal text-gray-600">
                            /appel
                          </span>
                        </> : <>
                          {plan.price} {plan.currency}
                          <span className="text-sm font-normal text-gray-600">
                            /
                            {plan.billingPeriod === BillingPeriod.MONTHLY ? 'mois' : 'an'}
                          </span>
                        </>}
                    </div>
                    {plan.billingPeriod !== BillingPeriod.PAY_AS_YOU_GO && plan.apiCallsLimit && <p className="text-sm text-gray-600 mt-1">
                          {plan.apiCallsLimit.toLocaleString()} appels API
                          inclus
                        </p>}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">
                    Informations de paiement
                  </h3>
                  <div className="space-y-1">
                    <p className="flex items-center text-gray-800">
                      <CreditCard className="h-4 w-4 text-gray-400 mr-2" />
                      Carte se terminant par •••• 3456
                    </p>
                    <p className="flex items-center text-gray-800">
                      <FileText className="h-4 w-4 text-gray-400 mr-2" />
                      Facture #{subscription.id}
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">
                    Détails de facturation
                  </h3>
                  <div className="space-y-1">
                    <p className="flex items-center text-gray-800">
                      <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                      Date de début: {formatDate(subscription.startDate)}
                    </p>
                    {subscription.nextBillingDate && plan.billingPeriod !== BillingPeriod.PAY_AS_YOU_GO && <p className="flex items-center text-gray-800">
                          <Clock className="h-4 w-4 text-gray-400 mr-2" />
                          Prochaine facturation:{' '}
                          {formatDate(subscription.nextBillingDate)}
                        </p>}
                  </div>
                </div>
              </div>
            </div>
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Prochaines étapes</h2>
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                  <h3 className="font-medium text-blue-800 mb-2">
                    Accéder à votre modèle
                  </h3>
                  <p className="text-blue-700 mb-3">
                    Vous pouvez maintenant utiliser {model.name} avec les
                    limites et fonctionnalités de votre plan d'abonnement.
                  </p>
                  <Link to={`/models/${model.id}`} className="inline-flex items-center text-blue-600 hover:text-blue-800">
                    Aller au modèle <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <h3 className="font-medium text-gray-800 mb-2">
                    Documentation d'API
                  </h3>
                  <p className="text-gray-700 mb-3">
                    Consultez la documentation pour savoir comment intégrer ce
                    modèle dans vos applications.
                  </p>
                  <Link to={`/docs/models/${model.id}`} className="inline-flex items-center text-blue-600 hover:text-blue-800">
                    Voir la documentation{' '}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <h3 className="font-medium text-gray-800 mb-2">
                    Gérer vos abonnements
                  </h3>
                  <p className="text-gray-700 mb-3">
                    Consultez et gérez tous vos abonnements actifs depuis votre
                    tableau de bord.
                  </p>
                  <Link to="/user/subscriptions" className="inline-flex items-center text-blue-600 hover:text-blue-800">
                    Gérer les abonnements{' '}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
            </div>
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
              <Link to="/models" className="px-6 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 text-center">
                Explorer d'autres modèles
              </Link>
              <button onClick={() => window.print()} className="px-6 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 flex items-center justify-center">
                <Download className="h-4 w-4 mr-2" />
                Télécharger le reçu
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>;
}