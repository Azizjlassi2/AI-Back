import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, Calendar, ArrowRight, Shield } from 'lucide-react';
export function TermsPage() {
  const [activeSection, setActiveSection] = useState('introduction');
  const sections = [{
    id: 'introduction',
    title: 'Introduction'
  }, {
    id: 'acceptance',
    title: 'Acceptation des conditions'
  }, {
    id: 'services',
    title: 'Description des services'
  }, {
    id: 'accounts',
    title: 'Comptes utilisateurs'
  }, {
    id: 'usage',
    title: "Règles d'utilisation"
  }, {
    id: 'content',
    title: 'Contenu et propriété intellectuelle'
  }, {
    id: 'api',
    title: "Utilisation de l'API"
  }, {
    id: 'payments',
    title: 'Paiements et abonnements'
  }, {
    id: 'termination',
    title: 'Résiliation'
  }, {
    id: 'liability',
    title: 'Limitation de responsabilité'
  }, {
    id: 'modifications',
    title: 'Modifications des conditions'
  }, {
    id: 'contact',
    title: 'Contact'
  }];
  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  };
  return <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
            <div className="flex items-center mb-4">
              <FileText className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-4xl font-bold text-gray-900">
                Conditions d'utilisation
              </h1>
            </div>
            <div className="flex items-center text-gray-600 mb-6">
              <Calendar className="h-4 w-4 mr-2" />
              <span className="text-sm">
                Dernière mise à jour : 15 janvier 2025
              </span>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Bienvenue sur AI+. En utilisant notre plateforme, vous acceptez
              d'être lié par les présentes conditions d'utilisation. Veuillez
              les lire attentivement avant d'utiliser nos services.
            </p>
            <div className="mt-6 pt-6 border-t border-gray-200">
              <Link to="/privacy" className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium">
                <Shield className="h-4 w-4 mr-2" />
                Consulter notre Politique de confidentialité
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </div>
          </div>
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Table of Contents - Sidebar */}
            <aside className="lg:w-64 flex-shrink-0">
              <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Sommaire
                </h2>
                <nav className="space-y-2">
                  {sections.map(section => <button key={section.id} onClick={() => scrollToSection(section.id)} className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${activeSection === section.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}>
                      {section.title}
                    </button>)}
                </nav>
              </div>
            </aside>
            {/* Main Content */}
            <main className="flex-1 bg-white rounded-xl shadow-sm p-8">
              <div className="prose prose-blue max-w-none">
                {/* Introduction */}
                <section id="introduction" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    1. Introduction
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    AI+ est une plateforme tunisienne dédiée à l'intelligence
                    artificielle, offrant un accès à des modèles d'IA, des
                    datasets et des API pour les développeurs, chercheurs et
                    entreprises.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    Ces Conditions d'utilisation ("Conditions") régissent votre
                    accès et votre utilisation de la plateforme AI+, y compris
                    tous les services, fonctionnalités et contenus proposés.
                  </p>
                </section>
                {/* Acceptance */}
                <section id="acceptance" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    2. Acceptation des conditions
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    En accédant à ou en utilisant AI+, vous acceptez d'être lié
                    par ces Conditions. Si vous n'acceptez pas ces Conditions,
                    vous ne devez pas utiliser notre plateforme.
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>Vous devez avoir au moins 18 ans pour utiliser AI+</li>
                    <li>
                      Vous devez fournir des informations exactes et à jour lors
                      de votre inscription
                    </li>
                    <li>
                      Vous êtes responsable de maintenir la confidentialité de
                      votre compte
                    </li>
                  </ul>
                </section>
                {/* Services */}
                <section id="services" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    3. Description des services
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    AI+ fournit les services suivants :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>
                      Accès à une bibliothèque de modèles d'intelligence
                      artificielle
                    </li>
                    <li>Accès à des datasets pour l'entraînement de modèles</li>
                    <li>
                      API REST pour l'intégration de modèles dans vos
                      applications
                    </li>
                    <li>Outils de test et d'évaluation de modèles en ligne</li>
                    <li>
                      Plateforme pour les développeurs pour publier leurs
                      propres modèles
                    </li>
                    <li>Documentation technique et support</li>
                  </ul>
                </section>
                {/* Accounts */}
                <section id="accounts" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    4. Comptes utilisateurs
                  </h2>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    4.1 Types de comptes
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    AI+ propose deux types de comptes :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      <strong>Compte Client :</strong> Pour utiliser les modèles
                      et datasets disponibles sur la plateforme
                    </li>
                    <li>
                      <strong>Compte Développeur :</strong> Pour publier et
                      monétiser vos propres modèles et datasets
                    </li>
                  </ul>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    4.2 Responsabilités du compte
                  </h3>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>
                      Vous êtes responsable de toutes les activités effectuées
                      via votre compte
                    </li>
                    <li>
                      Vous devez notifier immédiatement AI+ de toute utilisation
                      non autorisée de votre compte
                    </li>
                    <li>
                      Vous ne devez pas partager vos identifiants de connexion
                    </li>
                    <li>
                      Vous devez maintenir des informations de compte exactes et
                      à jour
                    </li>
                  </ul>
                </section>
                {/* Usage Rules */}
                <section id="usage" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    5. Règles d'utilisation
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    En utilisant AI+, vous acceptez de :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      Respecter toutes les lois et réglementations applicables
                    </li>
                    <li>
                      Ne pas utiliser la plateforme à des fins illégales ou non
                      autorisées
                    </li>
                    <li>
                      Ne pas tenter d'accéder à des parties non autorisées de la
                      plateforme
                    </li>
                    <li>
                      Ne pas interférer avec le fonctionnement de la plateforme
                    </li>
                    <li>Ne pas abuser des ressources de la plateforme</li>
                  </ul>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    5.1 Utilisations interdites
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Il est strictement interdit d'utiliser AI+ pour :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>
                      Créer ou distribuer du contenu illégal, nuisible ou
                      offensant
                    </li>
                    <li>Violer les droits de propriété intellectuelle</li>
                    <li>
                      Harceler, menacer ou porter atteinte à la vie privée
                      d'autrui
                    </li>
                    <li>
                      Diffuser des virus, malwares ou tout code malveillant
                    </li>
                    <li>
                      Effectuer du scraping non autorisé ou de l'extraction de
                      données
                    </li>
                  </ul>
                </section>
                {/* Content and IP */}
                <section id="content" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    6. Contenu et propriété intellectuelle
                  </h2>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    6.1 Propriété de AI+
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-6">
                    Tous les droits de propriété intellectuelle sur la
                    plateforme AI+, y compris le code source, le design,
                    l'interface et les marques, appartiennent à AI+ ou à ses
                    concédants de licence.
                  </p>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    6.2 Contenu des utilisateurs
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    En publiant du contenu sur AI+ (modèles, datasets,
                    commentaires), vous :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>
                      Conservez tous vos droits de propriété sur votre contenu
                    </li>
                    <li>
                      Accordez à AI+ une licence mondiale, non exclusive et
                      gratuite pour héberger, afficher et distribuer votre
                      contenu
                    </li>
                    <li>
                      Garantissez que vous avez tous les droits nécessaires pour
                      publier ce contenu
                    </li>
                  </ul>
                </section>
                {/* API Usage */}
                <section id="api" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    7. Utilisation de l'API
                  </h2>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    7.1 Clés API
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-6">
                    Vous recevrez des clés API pour accéder aux modèles auxquels
                    vous êtes abonné. Ces clés sont personnelles et ne doivent
                    pas être partagées.
                  </p>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    7.2 Limites d'utilisation
                  </h3>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>
                      Les limites d'appels API dépendent de votre plan
                      d'abonnement
                    </li>
                    <li>
                      Le dépassement des limites peut entraîner des frais
                      supplémentaires
                    </li>
                    <li>
                      AI+ se réserve le droit de limiter ou suspendre l'accès en
                      cas d'utilisation abusive
                    </li>
                  </ul>
                </section>
                {/* Payments */}
                <section id="payments" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    8. Paiements et abonnements
                  </h2>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    8.1 Plans d'abonnement
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-6">
                    AI+ propose différents plans d'abonnement avec des
                    fonctionnalités et limites variables. Les prix sont affichés
                    en dinars tunisiens (TND).
                  </p>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    8.2 Paiements
                  </h3>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                    <li>
                      Les paiements sont traités via Konnect.network et d'autres
                      méthodes de paiement sécurisées
                    </li>
                    <li>
                      Les abonnements sont facturés mensuellement ou
                      annuellement selon votre choix
                    </li>
                    <li>
                      Le renouvellement automatique est activé par défaut sauf
                      annulation
                    </li>
                  </ul>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    8.3 Remboursements
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    Les remboursements sont accordés au cas par cas selon notre
                    politique de remboursement. Contactez notre support pour
                    toute demande de remboursement.
                  </p>
                </section>
                {/* Termination */}
                <section id="termination" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    9. Résiliation
                  </h2>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    9.1 Par vous
                  </h3>
                  <p className="text-gray-700 leading-relaxed mb-6">
                    Vous pouvez résilier votre compte à tout moment depuis les
                    paramètres de votre compte. La résiliation prendra effet à
                    la fin de votre période de facturation en cours.
                  </p>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    9.2 Par AI+
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    AI+ se réserve le droit de suspendre ou résilier votre
                    compte en cas de violation de ces Conditions, sans préavis
                    et sans remboursement.
                  </p>
                </section>
                {/* Liability */}
                <section id="liability" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    10. Limitation de responsabilité
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    AI+ est fourni "tel quel" sans garantie d'aucune sorte. Dans
                    la mesure permise par la loi :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-gray-700">
                    <li>
                      AI+ ne garantit pas que le service sera ininterrompu ou
                      exempt d'erreurs
                    </li>
                    <li>
                      AI+ ne sera pas responsable des dommages indirects,
                      accessoires ou consécutifs
                    </li>
                    <li>
                      La responsabilité totale de AI+ ne dépassera pas le
                      montant payé par vous au cours des 12 derniers mois
                    </li>
                    <li>
                      Vous êtes responsable de l'utilisation que vous faites des
                      modèles et des résultats générés
                    </li>
                  </ul>
                </section>
                {/* Modifications */}
                <section id="modifications" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    11. Modifications des conditions
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    AI+ se réserve le droit de modifier ces Conditions à tout
                    moment. Les modifications seront effectives dès leur
                    publication sur la plateforme.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    Nous vous notifierons des changements importants par email
                    ou via une notification sur la plateforme. Votre utilisation
                    continue de AI+ après ces modifications constitue votre
                    acceptation des nouvelles Conditions.
                  </p>
                </section>
                {/* Contact */}
                <section id="contact" className="mb-12 scroll-mt-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    12. Contact
                  </h2>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Pour toute question concernant ces Conditions d'utilisation,
                    veuillez nous contacter :
                  </p>
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                    <p className="text-gray-800 mb-2">
                      <strong>Email :</strong> legal@aiplus.tn
                    </p>
                    <p className="text-gray-800 mb-2">
                      <strong>Téléphone :</strong> +216 71 123 456
                    </p>
                    <p className="text-gray-800">
                      <strong>Adresse :</strong> Tunis, Tunisie
                    </p>
                  </div>
                </section>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>;
}