import React, { Children } from 'react';
import { motion } from 'framer-motion';
import { Rocket, Target, Users, Shield, TrendingUp, Globe, Award, Heart, Zap, Code, Database, ChevronRight, MapPin, Mail, Linkedin, Twitter, Github, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
export function AboutPage() {
  const values = [{
    icon: <Rocket className="h-8 w-8 text-blue-600" />,
    title: 'Innovation',
    description: "Repousser les limites de l'IA pour créer un impact positif et durable en Tunisie et dans la région MENA"
  }, {
    icon: <Target className="h-8 w-8 text-blue-600" />,
    title: 'Excellence',
    description: "Fournir des solutions d'IA de haute qualité, performantes et adaptées aux besoins locaux"
  }, {
    icon: <Users className="h-8 w-8 text-blue-600" />,
    title: 'Communauté',
    description: "Favoriser la collaboration et le partage des connaissances entre passionnés d'IA"
  }, {
    icon: <Shield className="h-8 w-8 text-blue-600" />,
    title: 'Confiance',
    description: 'Garantir la sécurité, la confidentialité des données et la transparence dans nos services'
  }];
  const stats = [{
    number: '500+',
    label: 'Modèles publiés',
    icon: <Code className="h-6 w-6" />
  }, {
    number: '10K+',
    label: 'Utilisateurs actifs',
    icon: <Users className="h-6 w-6" />
  }, {
    number: '250+',
    label: 'Datasets disponibles',
    icon: <Database className="h-6 w-6" />
  }, {
    number: '50+',
    label: 'Développeurs partenaires',
    icon: <Award className="h-6 w-6" />
  }];
  const timeline = [{
    year: '2022',
    title: 'Fondation de AI+',
    description: "Lancement de la plateforme avec une vision claire : démocratiser l'accès à l'IA en Tunisie"
  }, {
    year: '2023',
    title: 'Croissance de la communauté',
    description: "Atteinte de 5000 utilisateurs et lancement de 200+ modèles d'IA"
  }, {
    year: '2024',
    title: "Expansion de l'écosystème",
    description: 'Introduction de nouveaux datasets tunisiens et partenariats avec des universités locales'
  }, {
    year: '2025',
    title: 'Vision future',
    description: "Devenir la référence régionale pour l'IA et l'apprentissage automatique"
  }];
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };
  return <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }} className="max-w-4xl mx-auto text-center">
            <motion.div initial={{
            scale: 0
          }} animate={{
            scale: 1
          }} transition={{
            delay: 0.2,
            type: 'spring',
            stiffness: 200
          }} className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-white/10 backdrop-blur-sm mb-8">
              <Heart className="h-8 w-8 text-white" />
            </motion.div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Construire l'avenir de l'IA en Tunisie
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed">
              AI+ est une plateforme tunisienne qui démocratise l'accès à
              l'intelligence artificielle et crée un écosystème d'innovation
              technologique florissant
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/models" className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
                Explorer les modèles
                <ChevronRight className="h-5 w-5 ml-2" />
              </Link>
              <Link to="/contact" className="inline-flex items-center px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-lg font-semibold hover:bg-white/20 transition-colors border border-white/20">
                Nous contacter
              </Link>
            </div>
          </motion.div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent" />
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{
          once: true
        }} className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => <motion.div key={index} variants={itemVariants} className="text-center">
                <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 text-blue-600 mb-4">
                  {stat.icon}
                </div>
                <div className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600">{stat.label}</div>
              </motion.div>)}
          </motion.div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Notre Mission
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed">
                Démocratiser l'accès à l'intelligence artificielle en Tunisie et
                créer un écosystème d'innovation technologique florissant qui
                permet aux développeurs, chercheurs et entreprises de créer,
                partager et monétiser des solutions d'IA de classe mondiale.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <div className="h-12 w-12 rounded-lg bg-blue-100 flex items-center justify-center mb-6">
                  <Globe className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Accessibilité
                </h3>
                <p className="text-gray-600">
                  Rendre les technologies d'IA accessibles à tous, des étudiants
                  aux entreprises établies
                </p>
              </div>
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <div className="h-12 w-12 rounded-lg bg-green-100 flex items-center justify-center mb-6">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Croissance
                </h3>
                <p className="text-gray-600">
                  Soutenir la croissance de l'écosystème tech tunisien et créer
                  de nouvelles opportunités
                </p>
              </div>
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <div className="h-12 w-12 rounded-lg bg-purple-100 flex items-center justify-center mb-6">
                  <Zap className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Innovation
                </h3>
                <p className="text-gray-600">
                  Encourager l'innovation et la recherche en IA adaptée aux
                  besoins locaux et régionaux
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Values Section */}
      <div className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nos Valeurs
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Les principes qui guident notre travail et nos décisions au
              quotidien
            </p>
          </motion.div>
          <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{
          once: true
        }} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => <motion.div key={index} variants={itemVariants} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-shadow">
                <div className="mb-6">{value.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {value.title}
                </h3>
                <p className="text-gray-600">{value.description}</p>
              </motion.div>)}
          </motion.div>
        </div>
      </div>

      {/* Timeline Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Notre Parcours
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              De la vision initiale à aujourd'hui, découvrez les étapes clés de
              notre évolution
            </p>
          </motion.div>
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-blue-200" />
              {timeline.map((item, index) => <motion.div key={index} initial={{
              opacity: 0,
              x: index % 2 === 0 ? -50 : 50
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: index * 0.1
            }} className={`relative flex items-center mb-12 ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className="w-5/12" />
                  <div className="absolute left-1/2 transform -translate-x-1/2 flex items-center justify-center">
                    <div className="h-4 w-4 rounded-full bg-blue-600 border-4 border-white shadow-md" />
                  </div>
                  <div className="w-5/12">
                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="text-2xl font-bold text-blue-600 mb-2">
                        {item.year}
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {item.title}
                      </h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>)}
            </div>
          </div>
        </div>
      </div>

      {/* Partners/Testimonials Section - Replacing Team Section */}
      <div className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Ils nous font confiance
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Des organisations et développeurs de toute la Tunisie utilisent
              AI+ pour leurs projets d'intelligence artificielle
            </p>
          </motion.div>

          {/* Testimonials Grid */}
          <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{
          once: true
        }} className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {[{
            name: 'Dr. Amira Ben Salem',
            role: 'Directrice de Recherche',
            company: 'Université de Tunis',
            image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amira',
            quote: "AI+ a transformé notre façon de travailler avec les modèles d'IA. La plateforme est intuitive et les modèles sont de haute qualité."
          }, {
            name: 'Karim Mansour',
            role: 'CTO',
            company: 'TechStart Tunisia',
            image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Karim',
            quote: "Grâce à AI+, nous avons pu intégrer des modèles d'IA avancés dans nos applications en quelques jours seulement."
          }, {
            name: 'Salma Trabelsi',
            role: 'Data Scientist',
            company: 'Innovation Labs',
            image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Salma',
            quote: "La qualité des datasets tunisiens disponibles sur AI+ est exceptionnelle. C'est exactement ce dont nous avions besoin."
          }].map((testimonial, index) => <motion.div key={index} variants={itemVariants} whileHover={{
            y: -8,
            transition: {
              duration: 0.2
            }
          }} className="bg-gray-50 rounded-xl p-6 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center mb-4">
                  <img src={testimonial.image} alt={testimonial.name} className="h-12 w-12 rounded-full mr-4" />
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {testimonial.name}
                    </h3>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                    <p className="text-sm text-blue-600 font-medium">
                      {testimonial.company}
                    </p>
                  </div>
                </div>
                <p className="text-gray-600 italic">"{testimonial.quote}"</p>
                <div className="flex mt-4">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />)}
                </div>
              </motion.div>)}
          </motion.div>

          {/* Partners Logos */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.3
        }} className="text-center">
            <p className="text-sm text-gray-500 uppercase tracking-wide mb-8">
              Nos partenaires
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center opacity-50 hover:opacity-100 transition-opacity">
              {['Université de Tunis', 'ANLP Lab', 'Innovation Hub', 'TechStart'].map((partner, index) => <div key={index} className="flex items-center justify-center h-16 text-gray-400 font-semibold">
                  {partner}
                </div>)}
            </div>
          </motion.div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Rejoignez la Révolution de l'IA
            </h2>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              Que vous soyez développeur, chercheur, étudiant ou entrepreneur,
              AI+ vous offre les outils et la communauté pour réussir dans le
              monde de l'intelligence artificielle
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/login" className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
                Créer un compte gratuit
                <ChevronRight className="h-5 w-5 ml-2" />
              </Link>
              <Link to="/contact" className="inline-flex items-center px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-lg font-semibold hover:bg-white/20 transition-colors border border-white/20">
                <Mail className="h-5 w-5 mr-2" />
                Nous contacter
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </div>;
}