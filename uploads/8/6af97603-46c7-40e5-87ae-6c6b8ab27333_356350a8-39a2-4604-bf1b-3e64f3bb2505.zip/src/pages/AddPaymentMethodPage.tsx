import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, Calendar, Check, AlertTriangle, Lock } from 'lucide-react';
export function AddPaymentMethodPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    cardName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  // Format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };
  // Handle card number input
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatCardNumber(e.target.value);
    setFormData({
      ...formData,
      cardNumber: formattedValue
    });
    if (errors.cardNumber) {
      setErrors({
        ...errors,
        cardNumber: ''
      });
    }
  };
  // Handle expiry date input formatting (MM/YY)
  const handleExpiryDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let {
      value
    } = e.target;
    value = value.replace(/\D/g, '');
    if (value.length > 2) {
      value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    setFormData({
      ...formData,
      expiryDate: value
    });
    if (errors.expiryDate) {
      setErrors({
        ...errors,
        expiryDate: ''
      });
    }
  };
  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const {
      name,
      value
    } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  // Validate form
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.cardName.trim()) {
      newErrors.cardName = 'Nom sur la carte requis';
    }
    if (!formData.cardNumber.trim() || formData.cardNumber.replace(/\s/g, '').length < 16) {
      newErrors.cardNumber = 'Numéro de carte invalide';
    }
    if (!formData.expiryDate.trim() || !/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
      newErrors.expiryDate = "Date d'expiration invalide (MM/YY)";
    }
    if (!formData.cvv.trim() || !/^\d{3,4}$/.test(formData.cvv)) {
      newErrors.cvv = 'CVV invalide';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      // In a real app, this would send card data to a payment processor
      // and store the token/reference in your database
      // Mock successful payment method addition
      const newPaymentMethod = {
        id: `pm_${Math.random().toString(36).substring(2, 9)}`,
        type: 'card',
        brand: 'visa',
        last4: formData.cardNumber.slice(-4),
        expMonth: parseInt(formData.expiryDate.split('/')[0]),
        expYear: parseInt(`20${formData.expiryDate.split('/')[1]}`),
        isDefault: false
      };
      // Get existing payment methods from localStorage
      const existingMethods = JSON.parse(localStorage.getItem('paymentMethods') || '[]');
      localStorage.setItem('paymentMethods', JSON.stringify([...existingMethods, newPaymentMethod]));
      // Show success message
      setSuccess(true);
      // Redirect back to settings page after delay
      setTimeout(() => {
        navigate('/user/settings');
      }, 1500);
    } catch (error) {
      console.error('Error adding payment method:', error);
      setErrors({
        ...errors,
        form: "Une erreur est survenue lors de l'ajout de votre méthode de paiement."
      });
    } finally {
      setLoading(false);
    }
  };
  return <div className="min-h-screen bg-gray-50 p-8">
      <div className="container mx-auto max-w-3xl">
        <div className="mb-6">
          <button onClick={() => navigate('/user/settings')} className="text-blue-600 hover:text-blue-800 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour aux paramètres
          </button>
        </div>
        {success ? <div className="bg-white rounded-xl shadow-sm p-8">
            <div className="flex flex-col items-center justify-center py-6">
              <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <Check className="h-8 w-8 text-green-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Méthode de paiement ajoutée
              </h1>
              <p className="text-gray-600 mb-6">
                Votre nouvelle méthode de paiement a été ajoutée avec succès.
              </p>
              <p className="text-gray-500 mb-6">
                Redirection vers les paramètres...
              </p>
            </div>
          </div> : <div className="bg-white rounded-xl shadow-sm p-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <CreditCard className="h-6 w-6 text-blue-600 mr-3" />
              Ajouter une méthode de paiement
            </h1>
            {errors.form && <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />
                <p className="text-red-700">{errors.form}</p>
              </div>}
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="cardName" className="block text-sm font-medium text-gray-700 mb-1">
                  Nom sur la carte *
                </label>
                <input type="text" id="cardName" name="cardName" value={formData.cardName} onChange={handleInputChange} className={`w-full px-4 py-2 border ${errors.cardName ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-blue-500 focus:border-blue-500`} placeholder="Nom complet tel qu'il apparaît sur la carte" />
                {errors.cardName && <p className="mt-1 text-sm text-red-600">{errors.cardName}</p>}
              </div>
              <div>
                <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  Numéro de carte *
                </label>
                <div className={`flex items-center w-full px-4 py-2 border ${errors.cardNumber ? 'border-red-500' : 'border-gray-300'} rounded-lg focus-within:ring-blue-500 focus-within:border-blue-500`}>
                  <input type="text" id="cardNumber" name="cardNumber" value={formData.cardNumber} onChange={handleCardNumberChange} className="flex-grow focus:outline-none" placeholder="1234 5678 9012 3456" maxLength={19} />
                  <div className="flex space-x-1">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png" alt="Visa" className="h-6" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png" alt="Mastercard" className="h-6" />
                  </div>
                </div>
                {errors.cardNumber && <p className="mt-1 text-sm text-red-600">
                    {errors.cardNumber}
                  </p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Date d'expiration *
                  </label>
                  <input type="text" id="expiryDate" name="expiryDate" value={formData.expiryDate} onChange={handleExpiryDateChange} className={`w-full px-4 py-2 border ${errors.expiryDate ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-blue-500 focus:border-blue-500`} placeholder="MM/YY" maxLength={5} />
                  {errors.expiryDate && <p className="mt-1 text-sm text-red-600">
                      {errors.expiryDate}
                    </p>}
                </div>
                <div>
                  <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                    CVV *
                  </label>
                  <input type="text" id="cvv" name="cvv" value={formData.cvv} onChange={e => {
                const value = e.target.value.replace(/\D/g, '');
                setFormData({
                  ...formData,
                  cvv: value
                });
                if (errors.cvv) {
                  setErrors({
                    ...errors,
                    cvv: ''
                  });
                }
              }} className={`w-full px-4 py-2 border ${errors.cvv ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-blue-500 focus:border-blue-500`} placeholder="123" maxLength={4} />
                  {errors.cvv && <p className="mt-1 text-sm text-red-600">{errors.cvv}</p>}
                </div>
              </div>
              <div className="flex items-center pt-4">
                <Lock className="h-4 w-4 text-green-600 mr-2" />
                <span className="text-sm text-gray-600">
                  Vos informations de paiement sont sécurisées
                </span>
              </div>
              <div className="pt-4">
                <button type="submit" className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center" disabled={loading}>
                  {loading ? <>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      Traitement en cours...
                    </> : <>
                      <CreditCard className="h-4 w-4 mr-2" />
                      Ajouter la méthode de paiement
                    </>}
                </button>
              </div>
            </form>
          </div>}
      </div>
    </div>;
}