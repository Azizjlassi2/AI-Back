import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ModelsPage } from './pages/ModelsPage';
import { ModelDetailPage } from './pages/ModelDetailPage';
import { DatasetsPage } from './pages/DatasetsPage';
import { DatasetDetailPage } from './pages/DatasetDetailPage';
import { APIPage } from './pages/APIPage';
import { DocsPage } from './pages/DocsPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { CreatorProfilePage } from './pages/CreatorProfilePage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminModelsPage } from './pages/admin/AdminModelsPage';
import { AdminModelDetailPage } from './pages/admin/AdminModelDetailPage';
import { AdminDatasetsPage } from './pages/admin/AdminDatasetsPage';
import { AdminDatasetDetailPage } from './pages/admin/AdminDatasetDetailPage';
import { UsersPage } from './pages/admin/UsersPage';
import { UserDetailPage } from './pages/admin/UserDetailPage';
import { SettingsPage } from './pages/admin/SettingsPage';
import { AnalyticsPage } from './pages/admin/AnalyticsPage';
import { SupportPage } from './pages/admin/SupportPage';
import { ReportsPage } from './pages/admin/ReportsPage';
import { InvoicesPage } from './pages/admin/InvoicesPage';
import { InvoiceDetailPage as AdminInvoiceDetailPage } from './pages/admin/InvoiceDetailPage';
import { AddModelPage } from './pages/AddModelPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { PaymentConfirmationPage } from './pages/PaymentConfirmationPage';
import { UserSubscriptionsPage } from './pages/UserSubscriptionsPage';
import { FAQSubscriptionsPage } from './pages/FAQSubscriptionsPage';
import { ModelAPIDocPage } from './pages/ModelAPIDocPage';
import { ModelUsageStatsPage } from './pages/ModelUsageStatsPage';
import { InvoiceDetailPage } from './pages/InvoiceDetailPage';
import { PaymentErrorPage } from './pages/PaymentErrorPage';
import { UserDashboardPage } from './pages/UserDashboardPage';
import { ApiKeysManagementPage } from './pages/ApiKeysManagementPage';
import { SubscriptionSettingsPage } from './pages/SubscriptionSettingsPage';
import { UserSettingsPage } from './pages/UserSettingsPage';
import { UserProfilePage } from './pages/UserProfilePage';
import { AllInvoicesPage } from './pages/AllInvoicesPage';
import { ModelTestingPage } from './pages/ModelTestingPage';
import { AddDatasetPage } from './pages/AddDatasetPage';
import { DatasetCheckoutPage } from './pages/DatasetCheckoutPage';
import { DatasetPaymentConfirmationPage } from './pages/DatasetPaymentConfirmationPage';
import { DatasetInvoiceDetailPage } from './pages/DatasetInvoiceDetailPage';
import { UserDatasetsPage } from './pages/UserDatasetsPage';
import { AddPaymentMethodPage } from './pages/AddPaymentMethodPage';
import { DeveloperDashboardPage } from './pages/DeveloperDashboardPage';
import { DeveloperModelsPage } from './pages/DeveloperModelsPage';
import { DeveloperDatasetsPage } from './pages/DeveloperDatasetsPage';
import { DeveloperAnalyticsPage } from './pages/DeveloperAnalyticsPage';
import { DeveloperReviewsPage } from './pages/DeveloperReviewsPage';
import { DeveloperPaymentsPage } from './pages/DeveloperPaymentsPage';
import { DeveloperProfilePage } from './pages/DeveloperProfilePage';
import { DeveloperSettingsPage } from './pages/DeveloperSettingsPage';
import { DeveloperSubscribersPage } from './pages/DeveloperSubscribersPage';
import { UpdateModelPage } from './pages/developer/UpdateModelPage';
import { UpdateDatasetPage } from './pages/developer/UpdateDatasetPage';
import { DeveloperModelDetailPage } from './pages/developer/DeveloperModelDetailPage';
import { DeveloperModelAnalyticsPage } from './pages/developer/DeveloperModelAnalyticsPage';
import { EditSubscriptionPlanPage } from './pages/developer/EditSubscriptionPlanPage';
import { DeveloperAddPaymentMethodPage } from './pages/developer/DeveloperAddPaymentMethodPage';
import { DeveloperPayoutDetailPage } from './pages/developer/DeveloperPayoutDetailPage';
import { DeveloperPaymentDocsPage } from './pages/developer/DeveloperPaymentDocsPage';
import { DeveloperInvoiceDetailPage } from './pages/developer/DeveloperInvoiceDetailPage';
import { DeveloperDatasetDetailPage } from './pages/developer/DeveloperDatasetDetailPage';
import { InstanceDetailPage } from './pages/InstanceDetailPage';
import { PaymentMethodsPage } from './pages/PaymentMethodsPage';
import { UserNotificationsPage } from './pages/UserNotificationsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
export function App() {
  return <ThemeProvider>
      <Router>
        <div className="flex flex-col min-h-screen w-full bg-white text-gray-900 transition-colors duration-200">
          <Routes>
            {/* Routes with Navbar and Footer */}
            <Route path="/" element={<>
                  <Navbar />
                  <main className="flex-grow">
                    <HomePage />
                  </main>
                  <Footer />
                </>} />
            {/* Auth routes without Navbar and Footer */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            {/* User Dashboard without Navbar and Footer */}
            <Route path="/user/dashboard" element={<UserDashboardPage />} />
            <Route path="/user/api-keys" element={<ApiKeysManagementPage />} />
            <Route path="/user/profile" element={<UserProfilePage />} />
            <Route path="/user/settings" element={<UserSettingsPage />} />
            <Route path="/user/notifications" element={<UserNotificationsPage />} />
            <Route path="/user/payment-methods" element={<PaymentMethodsPage />} />
            <Route path="/user/payment-method/add" element={<AddPaymentMethodPage />} />
            <Route path="/user/invoices" element={<AllInvoicesPage />} />
            <Route path="/user/datasets" element={<UserDatasetsPage />} />
            <Route path="/user/subscriptions" element={<UserSubscriptionsPage />} />
            <Route path="/user/instances/:instanceId" element={<InstanceDetailPage />} />
            <Route path="/user/subscription/:subscriptionId/settings" element={<SubscriptionSettingsPage />} />
            {/* Developer Dashboard without Navbar and Footer */}
            <Route path="/developer/dashboard" element={<DeveloperDashboardPage />} />
            <Route path="/developer/models" element={<DeveloperModelsPage />} />
            <Route path="/developer/datasets" element={<DeveloperDatasetsPage />} />
            <Route path="/developer/analytics" element={<DeveloperAnalyticsPage />} />
            <Route path="/developer/reviews" element={<DeveloperReviewsPage />} />
            <Route path="/developer/payments" element={<DeveloperPaymentsPage />} />
            <Route path="/developer/payments/add-method" element={<DeveloperAddPaymentMethodPage />} />
            <Route path="/developer/payouts/:payoutId" element={<DeveloperPayoutDetailPage />} />
            <Route path="/developer/documentation/payments" element={<DeveloperPaymentDocsPage />} />
            <Route path="/developer/invoices/:invoiceId" element={<DeveloperInvoiceDetailPage />} />
            <Route path="/developer/datasets/:datasetId" element={<DeveloperDatasetDetailPage />} />
            <Route path="/developer/profile" element={<DeveloperProfilePage />} />
            <Route path="/developer/settings" element={<DeveloperSettingsPage />} />
            <Route path="/developer/subscribers" element={<DeveloperSubscribersPage />} />
            <Route path="/developer/models/:id" element={<DeveloperModelDetailPage />} />
            <Route path="/developer/models/:id/analytics" element={<DeveloperModelAnalyticsPage />} />
            <Route path="/developer/models/:modelId/plans/:planId/edit" element={<EditSubscriptionPlanPage />} />
            <Route path="/developer/models/:modelId/update" element={<UpdateModelPage />} />
            <Route path="/developer/datasets/:datasetId/update" element={<UpdateDatasetPage />} />
            {/* Admin Dashboard without Navbar and Footer */}
            <Route path="/admin" element={<AdminDashboardPage />} />
            <Route path="/admin/users" element={<UsersPage />} />
            <Route path="/admin/users/:id" element={<UserDetailPage />} />
            <Route path="/admin/models" element={<AdminModelsPage />} />
            <Route path="/admin/models/:id" element={<AdminModelDetailPage />} />
            <Route path="/admin/datasets" element={<AdminDatasetsPage />} />
            <Route path="/admin/datasets/:id" element={<AdminDatasetDetailPage />} />
            <Route path="/admin/analytics" element={<AnalyticsPage />} />
            <Route path="/admin/settings" element={<SettingsPage />} />
            <Route path="/admin/support" element={<SupportPage />} />
            <Route path="/admin/reports" element={<ReportsPage />} />
            <Route path="/admin/invoices" element={<InvoicesPage />} />
            <Route path="/admin/invoices/:id" element={<AdminInvoiceDetailPage />} />
            {/* Other routes with Navbar and Footer */}
            <Route path="*" element={<>
                  <Navbar />
                  <main className="flex-grow">
                    <Routes>
                      <Route path="/models" element={<ModelsPage />} />
                      <Route path="/models/:id" element={<ModelDetailPage />} />
                      <Route path="/models/test/:modelId" element={<ModelTestingPage />} />
                      <Route path="/models/add" element={<AddModelPage />} />
                      <Route path="/datasets" element={<DatasetsPage />} />
                      <Route path="/datasets/add" element={<AddDatasetPage />} />
                      <Route path="/datasets/:id" element={<DatasetDetailPage />} />
                      <Route path="/api" element={<APIPage />} />
                      <Route path="/docs" element={<DocsPage />} />
                      <Route path="/about" element={<AboutPage />} />
                      <Route path="/contact" element={<ContactPage />} />
                      <Route path="/terms" element={<TermsPage />} />
                      <Route path="/privacy" element={<PrivacyPage />} />
                      <Route path="/creators/:name" element={<CreatorProfilePage />} />
                      <Route path="/checkout/:modelId" element={<CheckoutPage />} />
                      <Route path="/dataset-checkout/:datasetId" element={<DatasetCheckoutPage />} />
                      <Route path="/payment-error" element={<PaymentErrorPage />} />
                      <Route path="/payment-confirmation/:subscriptionId" element={<PaymentConfirmationPage />} />
                      <Route path="/dataset-payment-confirmation/:datasetId" element={<DatasetPaymentConfirmationPage />} />
                      <Route path="/faq/subscriptions" element={<FAQSubscriptionsPage />} />
                      <Route path="/docs/models/:modelId" element={<ModelAPIDocPage />} />
                      <Route path="/usage/models/:modelId" element={<ModelUsageStatsPage />} />
                      <Route path="/billing/invoices/:invoiceId" element={<InvoiceDetailPage />} />
                      <Route path="/user/invoices/dataset/:invoiceId" element={<DatasetInvoiceDetailPage />} />
                    </Routes>
                  </main>
                  <Footer />
                </>} />
          </Routes>
        </div>
      </Router>
    </ThemeProvider>;
}